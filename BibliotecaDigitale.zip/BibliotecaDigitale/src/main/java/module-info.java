module com.biblioteca.bibliotecadigitale {
    requires javafx.controls;
    requires javafx.fxml;

    requires java.sql;
    requires org.postgresql.jdbc;
    requires annotations;

    opens com.biblioteca.bibliotecadigitale to javafx.fxml;
    exports com.biblioteca.bibliotecadigitale;
    exports com.biblioteca.controllers.controllersPaginaTesti;
    opens com.biblioteca.controllers.controllersPaginaTesti to javafx.fxml;
    exports com.biblioteca.controllers.controllersModifica;
    opens com.biblioteca.controllers.controllersModifica to javafx.fxml;
    exports com.biblioteca.controllers.controllersAggiungi;
    opens com.biblioteca.controllers.controllersAggiungi to javafx.fxml;
    exports com.biblioteca.controllers.controllersPagine;
    opens com.biblioteca.controllers.controllersPagine to javafx.fxml;
    exports com.biblioteca.database;
    opens com.biblioteca.database to javafx.fxml;
}