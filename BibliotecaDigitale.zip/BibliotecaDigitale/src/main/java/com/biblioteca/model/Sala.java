package com.biblioteca.model;

import java.util.ArrayList;

public class Sala {
    public ArrayList<Esposizione> esposizioni;
    private int idsala;
    private String nome;
    private String indirizzo;
    private int capienza;

    public Sala(int idsala, String nome, String indirizzo, int capienza) {
        this.idsala = idsala;
        this.nome = nome;
        this.indirizzo = indirizzo;
        this.capienza = capienza;
        this.esposizioni = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }

    public int getCapienza() {
        return capienza;
    }

    public void setCapienza(int capienza) {
        this.capienza = capienza;
    }

    public ArrayList<Esposizione> getEsposizioni() {
        return esposizioni;
    }

    public void setEsposizioni(ArrayList<Esposizione> esposizioni) {
        this.esposizioni = esposizioni;
    }

    public int getIdsala() {
        return idsala;
    }

    public void setIdsala(int idsala) {
        this.idsala = idsala;
    }

}
