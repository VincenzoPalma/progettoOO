package com.biblioteca.model;

import java.util.ArrayList;

public class Rivista {
    public ArrayList<ArticoloScientifico> articoli;
    private String issn;
    private String nome;
    private String tema;
    private int anno;
    private String responsabile;
    private int numero;

    public Rivista(String issn, String nome, String tema, int anno, String responsabile, int numero) {
        this.issn = issn;
        this.nome = nome;
        this.tema = tema;
        this.anno = anno;
        this.responsabile = responsabile;
        this.numero = numero;
        this.articoli = new ArrayList<>();
    }

    public String getIssn() {
        return issn;
    }

    public void setIssn(String issn) {
        this.issn = issn;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }

    public int getAnno() {
        return anno;
    }

    public void setAnno(int anno) {
        this.anno = anno;
    }

    public String getResponsabile() {
        return responsabile;
    }

    public void setResponsabile(String responsabile) {
        this.responsabile = responsabile;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public ArrayList<ArticoloScientifico> getArticoli() {
        return articoli;
    }

    public void setArticoli(ArrayList<ArticoloScientifico> articoli) {
        this.articoli = articoli;
    }

}
