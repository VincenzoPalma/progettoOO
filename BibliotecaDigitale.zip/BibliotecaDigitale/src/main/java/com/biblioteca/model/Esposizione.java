package com.biblioteca.model;

import java.time.LocalDate;

public class Esposizione {
    public Libro libro;
    public Sala sala;
    private LocalDate data;

    public Esposizione(LocalDate data, Libro libro, Sala sala) {
        this.data = data;
        this.libro = libro;
        this.sala = sala;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public Libro getLibro() {
        return libro;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }

    public Sala getSala() {
        return sala;
    }

    public void setSala(Sala sala) {
        this.sala = sala;
    }

}
