package com.biblioteca.model;

import org.jetbrains.annotations.Nullable;

public class ArticoloScientifico extends Testo {
    public Rivista rivista;
    public Conferenza conferenza;
    protected int idarticolo;
    protected String tema;
    protected String argomento;

    public ArticoloScientifico(String titolo, String editore, Boolean cartaceo, Boolean digitale, Boolean audiolibro, int annopubblicazione, String tema, String argomento, Rivista rivista, Conferenza conferenza) {
        super(titolo, editore, cartaceo, digitale, audiolibro, annopubblicazione);
        this.tema = tema;
        this.argomento = argomento;
        this.rivista = rivista;
        this.conferenza = conferenza;
    }

    public ArticoloScientifico(int idarticolo, String titolo, String editore, Boolean cartaceo, Boolean digitale, Boolean audiolibro, int annopubblicazione, String tema, String argomento, @Nullable Rivista rivista, @Nullable Conferenza conferenza) {
        super(titolo, editore, cartaceo, digitale, audiolibro, annopubblicazione);
        this.idarticolo = idarticolo;
        this.tema = tema;
        this.argomento = argomento;
        this.rivista = rivista;
        if (rivista != null)
            rivista.articoli.add(this);
        this.conferenza = conferenza;
        if (conferenza != null)
            conferenza.articoli.add(this);
    }

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }

    public String getArgomento() {
        return argomento;
    }

    public void setArgomento(String argomento) {
        this.argomento = argomento;
    }

    public Rivista getRivista() {
        return rivista;
    }

    public void setRivista(Rivista rivista) {
        this.rivista = rivista;
    }

    public Conferenza getConferenza() {
        return conferenza;
    }

    public void setConferenza(Conferenza conferenza) {
        this.conferenza = conferenza;
    }

    public int getIdarticolo() {
        return idarticolo;
    }

    public void setIdarticolo(int idarticolo) {
        this.idarticolo = idarticolo;
    }
}
