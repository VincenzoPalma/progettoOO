package com.biblioteca.model;

import org.jetbrains.annotations.Nullable;

import java.time.LocalDate;
import java.util.ArrayList;

public class Autore {
    public ArrayList<Testo> testi;
    private int idautore;
    private String nominativo;
    private String istituto;
    private LocalDate datanascita;

    public Autore(int idautore, String nominativo, @Nullable String istituto, @Nullable LocalDate datanascita) {
        this.idautore = idautore;
        this.nominativo = nominativo;
        this.istituto = istituto;
        this.datanascita = datanascita;
        this.testi = new ArrayList<>();
    }

    public ArrayList<Testo> getTesti() {
        return testi;
    }

    public void setTesti(ArrayList<Testo> testi) {
        this.testi = testi;
    }

    public int getIdautore() {
        return idautore;
    }

    public void setIdautore(int idautore) {
        this.idautore = idautore;
    }

    public String getNominativo() {
        return nominativo;
    }

    public void setNominativo(String nominativo) {
        this.nominativo = nominativo;
    }

    public String getIstituto() {
        return istituto;
    }

    public void setIstituto(String istituto) {
        this.istituto = istituto;
    }

    public LocalDate getDatanascita() {
        return datanascita;
    }

    public void setDatanascita(LocalDate datanascita) {
        this.datanascita = datanascita;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj.getClass() != this.getClass()) {
            return false;
        }
        final Autore other = (Autore) obj;
        return other.getIdautore() == this.getIdautore();
    }
}
