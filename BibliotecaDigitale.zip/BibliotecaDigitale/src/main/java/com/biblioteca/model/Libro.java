package com.biblioteca.model;

import java.time.LocalDate;
import java.util.ArrayList;

public class Libro extends Testo {
    public ArrayList<Esposizione> esposizioni;
    public ArrayList<Partecipazione> partecipazioni;
    public ArrayList<Disponibilita> disponibili;
    private String isbn;
    private int mesepubblicazione;
    private int giornopubblicazione;

    public Libro(String titolo, String editore, Boolean cartaceo, Boolean digitale, Boolean audiolibro, int annopubblicazione, String isbn, int giornopubblicazione, int mesepubblicazione) {
        super(titolo, editore, cartaceo, digitale, audiolibro, annopubblicazione);
        this.isbn = isbn;
        this.giornopubblicazione = giornopubblicazione;
        this.mesepubblicazione = mesepubblicazione;
        this.esposizioni = new ArrayList<>();
        this.partecipazioni = new ArrayList<>();
        this.disponibili = new ArrayList<>();
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public ArrayList<Esposizione> getEsposizioni() {
        return esposizioni;
    }

    public void setEsposizioni(ArrayList<Esposizione> esposizioni) {
        this.esposizioni = esposizioni;
    }

    public int getMesepubblicazione() {
        return mesepubblicazione;
    }

    public void setMesepubblicazione(int mesepubblicazione) {
        this.mesepubblicazione = mesepubblicazione;
    }

    public int getGiornopubblicazione() {
        return giornopubblicazione;
    }

    public void setGiornopubblicazione(int giornopubblicazione) {
        this.giornopubblicazione = giornopubblicazione;
    }

    public ArrayList<Partecipazione> getPartecipazioni() {
        return partecipazioni;
    }

    public void setPartecipazioni(ArrayList<Partecipazione> partecipazioni) {
        this.partecipazioni = partecipazioni;
    }

    public ArrayList<Disponibilita> getDisponibili() {
        return disponibili;
    }

    public void setDisponibili(ArrayList<Disponibilita> disponibili) {
        this.disponibili = disponibili;
    }

    public void setData(LocalDate data) {
        setGiornopubblicazione(data.getDayOfMonth());
        setMesepubblicazione(data.getMonthValue());
        setAnnopubblicazione(data.getYear());
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj.getClass() != this.getClass()) {
            return false;
        }
        final Libro other = (Libro) obj;
        return other.getIsbn().equals(this.getIsbn());
    }

}
