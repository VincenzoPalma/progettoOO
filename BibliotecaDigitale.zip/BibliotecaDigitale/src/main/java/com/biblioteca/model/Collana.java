package com.biblioteca.model;

import org.jetbrains.annotations.Nullable;

import java.time.LocalDate;
import java.util.ArrayList;

public class Collana {
    public ArrayList<Partecipazione> partecipazioni;
    private String issn;
    private String nome;
    private String caratteristica;
    private String descrizione;
    private LocalDate datapubblicazione;
    private String direttore;
    private String editore;

    public Collana(String issn, String nome, String caratteristica, @Nullable String descrizione, LocalDate datapubblicazione, String direttore, String editore) {
        this.issn = issn;
        this.nome = nome;
        this.caratteristica = caratteristica;
        this.descrizione = descrizione;
        this.datapubblicazione = datapubblicazione;
        this.direttore = direttore;
        this.editore = editore;
        this.partecipazioni = new ArrayList<>();
    }

    public String getIssn() {
        return issn;
    }

    public void setIssn(String issn) {
        this.issn = issn;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCaratteristica() {
        return caratteristica;
    }

    public void setCaratteristica(String caratteristica) {
        this.caratteristica = caratteristica;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public LocalDate getDatapubblicazione() {
        return datapubblicazione;
    }

    public void setDatapubblicazione(LocalDate datapubblicazione) {
        this.datapubblicazione = datapubblicazione;
    }

    public String getDirettore() {
        return direttore;
    }

    public void setDirettore(String direttore) {
        this.direttore = direttore;
    }

    public String getEditore() {
        return editore;
    }

    public void setEditore(String editore) {
        this.editore = editore;
    }

    public ArrayList<Partecipazione> getPartecipazioni() {
        return partecipazioni;
    }

    public void setPartecipazioni(ArrayList<Partecipazione> partecipazioni) {
        this.partecipazioni = partecipazioni;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj.getClass() != this.getClass()) {
            return false;
        }
        final Collana other = (Collana) obj;
        return other.getIssn().equals(this.getIssn());
    }
}
