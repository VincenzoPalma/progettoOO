package com.biblioteca.model;

import java.util.ArrayList;

public class Testo {
    public ArrayList<Autore> autori;
    protected String titolo;
    protected String editore;
    protected Boolean cartaceo;
    protected Boolean digitale;
    protected Boolean audiolibro;
    protected int annopubblicazione;

    public Testo(String titolo, String editore, Boolean cartaceo, Boolean digitale, Boolean audiolibro, int annopubblicazione) {
        this.titolo = titolo;
        this.editore = editore;
        this.cartaceo = cartaceo;
        this.digitale = digitale;
        this.audiolibro = audiolibro;
        this.annopubblicazione = annopubblicazione;
        this.autori = new ArrayList<>();
    }

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public String getEditore() {
        return editore;
    }

    public void setEditore(String editore) {
        this.editore = editore;
    }

    public ArrayList<Autore> getAutori() {
        return autori;
    }

    public void setAutori(ArrayList<Autore> autori) {
        this.autori = autori;
    }

    public Boolean getCartaceo() {
        return cartaceo;
    }

    public void setCartaceo(Boolean cartaceo) {
        this.cartaceo = cartaceo;
    }

    public Boolean getDigitale() {
        return digitale;
    }

    public void setDigitale(Boolean digitale) {
        this.digitale = digitale;
    }

    public Boolean getAudiolibro() {
        return audiolibro;
    }

    public void setAudiolibro(Boolean audiolibro) {
        this.audiolibro = audiolibro;
    }

    public int getAnnopubblicazione() {
        return annopubblicazione;
    }

    public void setAnnopubblicazione(int annopubblicazione) {
        this.annopubblicazione = annopubblicazione;
    }
}
