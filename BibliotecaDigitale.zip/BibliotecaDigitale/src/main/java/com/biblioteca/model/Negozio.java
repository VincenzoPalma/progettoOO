package com.biblioteca.model;

import java.util.ArrayList;

public class Negozio {
    public ArrayList<PuntoVendita> puntivendita;
    public ArrayList<Disponibilita> disponibili;
    private int idnegozio;
    private String nome;
    private String sito;

    public Negozio(int idnegozio, String nome, String sito) {
        this.idnegozio = idnegozio;
        this.nome = nome;
        this.sito = sito;
        this.disponibili = new ArrayList<>();
        this.puntivendita = new ArrayList<>();
    }

    public int getIdnegozio() {
        return idnegozio;
    }

    public void setIdnegozio(int idnegozio) {
        this.idnegozio = idnegozio;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSito() {
        return sito;
    }

    public void setSito(String sito) {
        this.sito = sito;
    }

    public ArrayList<PuntoVendita> getPuntivendita() {
        return puntivendita;
    }

    public void setPuntivendita(ArrayList<PuntoVendita> puntivendita) {
        this.puntivendita = puntivendita;
    }

    public ArrayList<Disponibilita> getDisponibili() {
        return disponibili;
    }

    public void setDisponibili(ArrayList<Disponibilita> disponibili) {
        this.disponibili = disponibili;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj.getClass() != this.getClass()) {
            return false;
        }
        final Negozio other = (Negozio) obj;
        return other.getIdnegozio() == this.getIdnegozio();
    }
}
