package com.biblioteca.model;

import org.jetbrains.annotations.Nullable;

public class Romanzo extends Libro {
    public Romanzo seguito;
    public Serie serie;
    protected String genere;

    public Romanzo(String titolo, String editore, Boolean cartaceo, Boolean digitale, Boolean audiolibro, int annopubblicazione, String isbn, int giornopubblicazione, int mesepubblicazione, String genere, @Nullable Romanzo seguito, @Nullable Serie serie) {
        super(titolo, editore, cartaceo, digitale, audiolibro, annopubblicazione, isbn, giornopubblicazione, mesepubblicazione);
        this.genere = genere;
        this.seguito = seguito;
        this.serie = serie;
    }

    public String getGenere() {
        return genere;
    }

    public void setGenere(String genere) {
        this.genere = genere;
    }

    public Romanzo getSeguito() {
        return seguito;
    }

    public void setSeguito(Romanzo seguito) {
        this.seguito = seguito;
    }

    public Serie getSerie() {
        return serie;
    }

    public void setSerie(Serie serie) {
        this.serie = serie;
        if (serie != null) {
            serie.libri.add(this);
        }
    }

}
