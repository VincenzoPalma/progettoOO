package com.biblioteca.model;

public class PuntoVendita {
    public Negozio negozio;
    private int idpuntovendita;
    private String nome;
    private String citta;

    public PuntoVendita(int idpuntovendita, String nome, String citta, Negozio negozio) {
        this.idpuntovendita = idpuntovendita;
        this.nome = nome;
        this.citta = citta;
        this.negozio = negozio;
        negozio.puntivendita.add(this);
    }

    public int getIdpuntovendita() {
        return idpuntovendita;
    }

    public void setIdpuntovendita(int idpuntovendita) {
        this.idpuntovendita = idpuntovendita;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCitta() {
        return citta;
    }

    public void setCitta(String citta) {
        this.citta = citta;
    }

    public Negozio getNegozio() {
        return negozio;
    }

    public void setNegozio(Negozio negozio) {
        this.negozio = negozio;
    }
}
