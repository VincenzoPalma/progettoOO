package com.biblioteca.model;

import java.util.ArrayList;

public class Utente {
    public ArrayList<Serie> serie;
    public ArrayList<Notifica> notifiche;
    private String username;
    private String password;
    private String tipo;

    public Utente(String username, String password, String tipo) {
        this.username = username;
        this.password = password;
        this.tipo = tipo;
        this.serie = new ArrayList<>();
        this.notifiche = new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public ArrayList<Serie> getSerie() {
        return serie;
    }

    public void setSerie(ArrayList<Serie> serie) {
        this.serie = serie;
    }

    public ArrayList<Notifica> getNotifiche() {
        return notifiche;
    }

    public void setNotifiche(ArrayList<Notifica> notifiche) {
        this.notifiche = notifiche;
    }

}
