package com.biblioteca.model;

public class LibroDidattico extends Libro {
    protected String ambito;

    public LibroDidattico(String titolo, String editore, Boolean cartaceo, Boolean digitale, Boolean audiolibro, int annopubblicazione, String isbn, int giornopubblicazione, int mesepubblicazione, String ambito) {
        super(titolo, editore, cartaceo, digitale, audiolibro, annopubblicazione, isbn, giornopubblicazione, mesepubblicazione);
        this.ambito = ambito;
    }

    public String getAmbito() {
        return ambito;
    }

    public void setAmbito(String ambito) {
        this.ambito = ambito;
    }
}
