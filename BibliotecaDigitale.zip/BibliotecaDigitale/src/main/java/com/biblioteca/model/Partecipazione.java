package com.biblioteca.model;

import java.time.LocalDate;

public class Partecipazione {
    public Libro libro;
    public Collana collana;
    private LocalDate data;

    public Partecipazione(LocalDate data, Libro libro, Collana collana) {
        this.data = data;
        this.libro = libro;
        this.collana = collana;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public Libro getLibro() {
        return libro;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }

    public Collana getCollana() {
        return collana;
    }

    public void setCollana(Collana collana) {
        this.collana = collana;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj.getClass() != this.getClass()) {
            return false;
        }
        final Partecipazione other = (Partecipazione) obj;
        return this.getLibro().equals(other.getLibro()) && this.getCollana().equals(other.getCollana());
    }
}
