package com.biblioteca.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Notifica {
    public Utente utente;
    public Serie serie;
    private LocalDate data;
    private LocalTime orario;

    public Notifica(Utente utente, Serie serie, LocalDate data, LocalTime orario) {
        this.data = data;
        this.orario = orario;
        this.serie = serie;
        this.utente = utente;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public LocalTime getOrario() {
        return orario;
    }

    public void setOrario(LocalTime orario) {
        this.orario = orario;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    public Serie getSerie() {
        return serie;
    }

    public void setSerie(Serie serie) {
        this.serie = serie;
    }
}
