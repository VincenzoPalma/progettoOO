package com.biblioteca.model;

import java.util.ArrayList;

public class Serie {
    public ArrayList<Romanzo> libri;
    public ArrayList<Utente> utenti;
    public ArrayList<Notifica> notifiche;
    private int idserie;
    private String titolo;

    public Serie(String titolo, int idserie) {
        this.titolo = titolo;
        this.idserie = idserie;
        this.libri = new ArrayList<>();
        this.utenti = new ArrayList<>();
        this.notifiche = new ArrayList<>();
    }

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public ArrayList<Romanzo> getLibri() {
        return libri;
    }

    public void setLibri(ArrayList<Romanzo> libri) {
        this.libri = libri;
    }

    public ArrayList<Utente> getUtenti() {
        return utenti;
    }

    public void setUtenti(ArrayList<Utente> utenti) {
        this.utenti = utenti;
    }

    public ArrayList<Notifica> getNotifiche() {
        return notifiche;
    }

    public void setNotifiche(ArrayList<Notifica> notifiche) {
        this.notifiche = notifiche;
    }

    public int getIdserie() {
        return idserie;
    }

    public void setIdserie(int idserie) {
        this.idserie = idserie;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj.getClass() != this.getClass()) {
            return false;
        }
        final Serie other = (Serie) obj;
        return other.getIdserie() == this.getIdserie();
    }

}
