package com.biblioteca.model;

import java.math.BigDecimal;

public class Disponibilita {
    public Libro libro;
    public Negozio negozio;
    private BigDecimal prezzo;

    public Disponibilita(BigDecimal prezzo, Libro libro, Negozio negozio) {
        this.prezzo = prezzo;
        this.libro = libro;
        this.negozio = negozio;
    }

    public BigDecimal getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(BigDecimal prezzo) {
        this.prezzo = prezzo;
    }

    public Libro getLibro() {
        return libro;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }

    public Negozio getNegozio() {
        return negozio;
    }

    public void setNegozio(Negozio negozio) {
        this.negozio = negozio;
    }
}
