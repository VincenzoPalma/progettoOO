package com.biblioteca.model;

import org.jetbrains.annotations.Nullable;

import java.time.LocalDate;
import java.util.ArrayList;

public class Conferenza {

    public ArrayList<ArticoloScientifico> articoli;
    private int idconferenza;
    private String citta;
    private String struttura;
    private LocalDate datainizio;
    private LocalDate datafine;
    private String responsabile;

    public Conferenza(int idconferenza, String citta, String struttura, LocalDate datainizio, @Nullable LocalDate datafine, String responsabile) {
        this.idconferenza = idconferenza;
        this.citta = citta;
        this.struttura = struttura;
        this.datainizio = datainizio;
        this.datafine = datafine;
        this.responsabile = responsabile;
        this.articoli = new ArrayList<>();
    }

    public String getCitta() {
        return citta;
    }

    public void setCitta(String citta) {
        this.citta = citta;
    }

    public String getStruttura() {
        return struttura;
    }

    public void setStruttura(String struttura) {
        this.struttura = struttura;
    }

    public LocalDate getDatainizio() {
        return datainizio;
    }

    public void setDatainizio(LocalDate datainizio) {
        this.datainizio = datainizio;
    }

    public LocalDate getDatafine() {
        return datafine;
    }

    public void setDatafine(LocalDate datafine) {
        this.datafine = datafine;
    }

    public String getResponsabile() {
        return responsabile;
    }

    public void setResponsabile(String responsabile) {
        this.responsabile = responsabile;
    }

    public ArrayList<ArticoloScientifico> getArticoli() {
        return articoli;
    }

    public void setArticoli(ArrayList<ArticoloScientifico> articoli) {
        this.articoli = articoli;
    }

    public int getIdconferenza() {
        return idconferenza;
    }

    public void setIdconferenza(int idconferenza) {
        this.idconferenza = idconferenza;
    }

}
