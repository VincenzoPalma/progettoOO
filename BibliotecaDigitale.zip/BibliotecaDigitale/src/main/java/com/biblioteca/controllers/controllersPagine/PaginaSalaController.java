package com.biblioteca.controllers.controllersPagine;

import com.biblioteca.DAO.EsposizioneDAO;
import com.biblioteca.DAO.LibroDAO;
import com.biblioteca.DAO.SalaDAO;
import com.biblioteca.ImplementazioneDAO.EsposizioneImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.LibroImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.SalaImplementazionePostgresDAO;
import com.biblioteca.bibliotecadigitale.Main;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaDidatticoController;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaRomanzoController;
import com.biblioteca.model.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Controller dedicato alla gestione della pagina per le sale.
 */
public class PaginaSalaController implements Initializable {
    @FXML
    private Label nomeSalaLabel;
    @FXML
    private Label indirizzoLabel;
    @FXML
    private Label capienzaLabel;
    @FXML
    private ListView<String> listaPresentazioni;
    @FXML
    private Button confermaModifiche;
    @FXML
    private Button modificaSalaButton;
    @FXML
    private Button annullaModifiche;
    @FXML
    private TextField modificaCapienza;
    @FXML
    private TextField modificaIndirizzo;
    @FXML
    private Label messaggioLabel;
    @FXML
    private TextField modificaNomeSala;
    @FXML
    private Button eliminaButton;
    @FXML
    private ImageView sfondo;
    /**
     * Oggetto sala di cui si vogliono mostrare
     * le informazioni.
     */
    private Sala sala;

    /**
     * Utente che ha aperto la pagina, utilizzato per
     * decidere se l'utente in questione può o meno modificare i
     * dati della pagina.
     */
    private Utente utente;

    public Sala getSala() {
        return sala;
    }

    public void setSala(Sala sala) {
        this.sala = sala;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        File sfondoFile = new File("src/Images/paginaSala.png");
        Image sfondoImmagine = new Image(sfondoFile.toURI().toString());
        sfondo.setImage(sfondoImmagine);

    }

    /**
     * Imposta le informazioni della sala nella pagina.
     * Utilizza le informazioni presenti nell'oggetto "sala".
     * Per i libri presentati nella sala, viene effettuata una ricerca nel database tramite {@link EsposizioneImplementazionePostgresDAO}.
     *
     * @param sala   Oggetto di tipo Sala di cui si vogliono mostrare le informazioni
     * @param utente Tipo di utente che accede alla pagina
     */
    public void preparaPagina(Sala sala, Utente utente) {
        //assegna la sala e il tipo utente agli attributi del controller
        setSala(sala);
        setUtente(utente);
        //imposta i label che compongono la pagina in base al contenuto dell'oggetto sala
        nomeSalaLabel.setText(sala.getNome());
        indirizzoLabel.setText("Indirizzo : " + sala.getIndirizzo());
        capienzaLabel.setText("Capienza : " + sala.getCapienza());
        //dichiarazione degli arraylist che conterranno le informazioni dei risultati
        ArrayList<String> isbnLibriEsposti = new ArrayList<>();
        ArrayList<LocalDate> dateEsposizioni = new ArrayList<>();
        ArrayList<Esposizione> esposizioniSala = new ArrayList<>();
        EsposizioneDAO cercaEsposizioni = new EsposizioneImplementazionePostgresDAO(); //connessione al database
        try {
            cercaEsposizioni.cercaEsposizioniPerIdSala(sala.getIdsala(), isbnLibriEsposti, dateEsposizioni); //cerca nel database le esposizioni della sala
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaEsposizioni.close(); //chiude la connessione
        }
        ArrayList<Libro> libriEsposti = cercaLibriSala(sala.getIdsala()); //ottenimento dei libri esposti nella sala
        //per ogni libro trovato, crea il relativo oggetto Esposizione
        for (int i = 0; i < isbnLibriEsposti.size(); i++) {
            Esposizione esposizione = new Esposizione(dateEsposizioni.get(i), libriEsposti.get(i), sala);
            esposizioniSala.add(esposizione);
        }
        sala.setEsposizioni(esposizioniSala); //imposta le esposizioni della sala
        //visualizza tutti i libri presentati nella sala
        for (Esposizione esposizione : sala.getEsposizioni()) {
            if (esposizione.getLibro() instanceof Romanzo) {
                listaPresentazioni.getItems().add(esposizione.getLibro().getTitolo() + " | Romanzo" + " | " + esposizione.getData());
            } else {
                listaPresentazioni.getItems().add(esposizione.getLibro().getTitolo() + " | Didattico" + " | " + esposizione.getData());
            }
        }
        //se l'utente è un amministratore, visualizza il bottone di modifica
        if (utente.getTipo().equals("Amministratore")) {
            modificaSalaButton.setVisible(true);
            modificaSalaButton.setDisable(false);
        }
    }

    /**
     * Cerca i libri della sala con id uguale a quello passato
     * come parametro nel database. Ritorna un arraylist di libri trovati, sia didattici che romanzi.
     *
     * @param idSala Id della sala di cui si vogliono ottenere i libri.
     * @return Un arraylist di oggetti di tipo Libro.
     */
    public ArrayList<Libro> cercaLibriSala(int idSala) {
        LibroDAO cercaLibri = new LibroImplementazionePostgresDAO(); //connessione al database
        ArrayList<Libro> libriSala = new ArrayList<>(); //arraylist dei libri della sala
        //dichiarazione degli arraylist che conterranno le informazioni dei risultati della ricerca
        ArrayList<String> isbn = new ArrayList<>();
        ArrayList<String> titoli = new ArrayList<>();
        ArrayList<String> generi = new ArrayList<>();
        ArrayList<LocalDate> dateUscita = new ArrayList<>();
        ArrayList<String> tipoLibri = new ArrayList<>();
        ArrayList<String> editori = new ArrayList<>();
        ArrayList<Boolean> cartaceo = new ArrayList<>();
        ArrayList<Boolean> digitale = new ArrayList<>();
        ArrayList<Boolean> audiolibro = new ArrayList<>();
        try {
            cercaLibri.cercaLibroPerSala(idSala, isbn, titoli, generi, dateUscita, tipoLibri, editori, cartaceo, digitale, audiolibro);//ricerca dei libri della sala
        } catch (SQLException ex) {
            ex.printStackTrace();
            return new ArrayList<>(); //ritorna un arraylist vuoto in caso di eccezione
        }
        //per ogni libro trovato, viene creato un oggetto in base al tipo di libro e viene inserito nell'arraylist
        for (int i = 0; i < isbn.size(); i++) {
            if (tipoLibri.get(i).equals("Romanzo")) {
                Romanzo romanzo = new Romanzo(titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), dateUscita.get(i).getYear(), isbn.get(i), dateUscita.get(i).getDayOfMonth(), dateUscita.get(i).getMonthValue(), generi.get(i), null, null);
                libriSala.add(romanzo);
            } else {
                LibroDidattico libroDidattico = new LibroDidattico(titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), dateUscita.get(i).getYear(), isbn.get(i), dateUscita.get(i).getDayOfMonth(), dateUscita.get(i).getMonthValue(), generi.get(i));
                libriSala.add(libroDidattico);
            }
        }
        return libriSala;
    }

    /**
     * Sul click di un libro, chiama una nuova finestra che
     * conterrà le informazioni di quel libro, le informazioni mostrate dalla finestra
     * dipenderanno dal tipo di libro.
     * <p>
     * Passa l'oggetto del libro selezionato e il tipo di utente al controller della schermata che chiama.
     *
     * @see PaginaRomanzoController
     * @see PaginaDidatticoController
     */
    public void visualizzaTesto() throws IOException {
        try {
            int indiceTesto = listaPresentazioni.getSelectionModel().getSelectedIndex(); //ottiene l'indice del libro selezionato nella lista di libri visualizzati
            Libro libroSelezionato = sala.getEsposizioni().get(indiceTesto).getLibro(); //ottiene il libro selezionato dalla sala tramite l'indice ottenuto in precedenza
            Stage stage = new Stage();
            FXMLLoader fxmlLoader;
            Scene scene;
            if (libroSelezionato instanceof Romanzo) {
                //se il libro selezionato è un romanzo, prepara e apre la pagina per i romanzi
                fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaRomanzo.fxml"));
                Parent root = fxmlLoader.load();
                PaginaRomanzoController paginaRomanzo = fxmlLoader.getController();
                paginaRomanzo.preparaPagina((Romanzo) libroSelezionato, utente);
                scene = new Scene(root, 1300, 900);
            } else {
                //se il libro selezionato è un libro didattico, prepara e apre la pagina per i libri didattici
                fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaLibroDidattico.fxml"));
                Parent root = fxmlLoader.load();
                PaginaDidatticoController paginaRomanzo = fxmlLoader.getController();
                paginaRomanzo.preparaPagina((LibroDidattico) libroSelezionato, utente);
                scene = new Scene(root, 1300, 900);
            }
            stage.setTitle(libroSelezionato.getTitolo());
            stage.setScene(scene);
            stage.show();
            stage.setResizable(false);
        } catch (IndexOutOfBoundsException ignored) {
        }
        //se viene cliccato uno spazio vuoto, ignora l'eccezione lanciata

    }

    /**
     * Sul click del tasto "Modifica", visualizza i campi per modificare le informazioni.
     */
    public void modificaSalaOnAction() {
        modificaSalaButton.setVisible(false);
        confermaModifiche.setVisible(true);
        annullaModifiche.setVisible(true);
        modificaCapienza.setVisible(true);
        modificaIndirizzo.setVisible(true);
        modificaNomeSala.setVisible(true);
        indirizzoLabel.setText("");
        capienzaLabel.setText("");
        nomeSalaLabel.setText("");
        modificaNomeSala.setText(sala.getNome());
        modificaCapienza.setText(String.valueOf(sala.getCapienza()));
        modificaIndirizzo.setText(sala.getIndirizzo());
        eliminaButton.setVisible(true);
    }

    /**
     * Sul click del tasto "Conferma", controlla la validità dei dati inseriti e modifica la sala nel database.
     */
    public void confermaModificheOnAction() {
        //prende il contenuto dei campi
        String nuovoNome = modificaNomeSala.getText();
        String nuovoIndirizzo = modificaIndirizzo.getText();
        //controlla che sia stato inserito un valore valido per la capienza
        if (modificaCapienza.getText().isBlank() || Integer.parseInt(modificaCapienza.getText()) <= 0) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("INSERIRE UNA CAPIENZA VALIDA");
            return;
        }
        int nuovaCapienza = Integer.parseInt(modificaCapienza.getText());
        //controlla che il nome inserito sia valido
        if (nuovoNome.isBlank()) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("INSERIRE UN NOME VALIDO");
            return;
        }
        //controlla che l'indirizzo inserito sia valido
        if (nuovoIndirizzo.isBlank()) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("INSERIRE UN INDIRIZZO VALIDO");
            return;
        }
        SalaDAO modificaSala = new SalaImplementazionePostgresDAO(); //connessione al database
        try {
            modificaSala.modificaSalaDB(sala.getIdsala(), nuovoNome, nuovoIndirizzo, nuovaCapienza);
        } catch (SQLException ex) {
            ex.printStackTrace();
            return;
        } finally {
            modificaSala.close(); //chiusura della connessione
        }
        //imposta i nuovi valori della sala
        sala.setCapienza(nuovaCapienza);
        sala.setNome(nuovoNome);
        sala.setIndirizzo(nuovoIndirizzo);
        resetModificheOnAction(); //reimposta i dati nella pagina
    }

    /**
     * Sul click del tasto "Annulla", nasconde i campi relativi alla modifica.
     */
    public void resetModificheOnAction() {
        modificaSalaButton.setVisible(true);
        confermaModifiche.setVisible(false);
        annullaModifiche.setVisible(false);
        modificaCapienza.setVisible(false);
        modificaIndirizzo.setVisible(false);
        modificaNomeSala.setVisible(false);
        eliminaButton.setVisible(false);
        indirizzoLabel.setText(sala.getIndirizzo());
        capienzaLabel.setText(String.valueOf(sala.getCapienza()));
        nomeSalaLabel.setText(sala.getNome());
        messaggioLabel.setText("");
    }

    /**
     * Sul click del tasto "Elimina", cancella la sala della pagina.
     */
    public void eliminaOnAction() {
        SalaDAO eliminaSala = new SalaImplementazionePostgresDAO() {
        };
        try {
            eliminaSala.eliminaSalaDB(sala.getIdsala());
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            eliminaSala.close();
        }
        for (Esposizione esposizione : sala.getEsposizioni()) {
            esposizione.setLibro(null);
        }
        Stage stage = (Stage) eliminaButton.getScene().getWindow(); //chiude la pagina
        stage.close();
    }

}

