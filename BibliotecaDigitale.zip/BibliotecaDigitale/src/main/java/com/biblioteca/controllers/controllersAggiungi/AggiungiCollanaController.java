package com.biblioteca.controllers.controllersAggiungi;

import com.biblioteca.DAO.CollanaDAO;
import com.biblioteca.ImplementazioneDAO.CollanaImplementazionePostgresDAO;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

import java.sql.SQLException;
import java.time.LocalDate;

/**
 * Controller dedicato alla gestione della pagina per l'inserimento di collane.
 */
public class AggiungiCollanaController {
    @FXML
    private TextField issnField;
    @FXML
    private TextField nomeField;
    @FXML
    private TextField caratteristicaField;
    @FXML
    private TextArea descrizioneField;
    @FXML
    private TextField editoreField;
    @FXML
    private TextField direttoreField;
    @FXML
    private Label messaggioLabel;
    @FXML
    private DatePicker dataAggiuntaField;

    /**
     * Sul click del tasto "Conferma", ottiene il contenuto dei campi, ne verifica la validità, e inserisce una collana
     * con quei valori nel database.
     */
    public void confermaOnAction() {
        //prende il contenuto dei campi
        String issn = issnField.getText();
        String nome = nomeField.getText();
        String caratteristica = caratteristicaField.getText();
        String editore = editoreField.getText();
        String direttore = direttoreField.getText();
        String descrizione = descrizioneField.getText();
        LocalDate dataPubblicazione = dataAggiuntaField.getValue();
        //controlla la validità della descrizione inserita, se non viene inserito un valore, viene posto a null
        if (descrizione.isBlank()) {
            descrizione = null;
        }
        //controlla la validità delle informazioni inserite
        try {
            checkDati(issn, nome, caratteristica, editore, direttore, dataPubblicazione);
        } catch (IllegalArgumentException ex) {
            return;
        }
        CollanaDAO inserimentoCollana = new CollanaImplementazionePostgresDAO(); //apertura della connessione col database
        try {
            inserimentoCollana.aggiungiCollanaDB(issn, nome, editore, direttore, caratteristica, descrizione, dataPubblicazione); //inserimento della collana nel database
        } catch (SQLException ex) {
            messaggioLabel.setText("ERRORE: ISSN NON VALIDO O GIA' IN USO"); //errore dato quando viene inserito una collana con issn già in uso
            return;
        } finally {
            inserimentoCollana.close(); //chiusura della connessione col database
        }
        //messaggio di avvenuto inserimento in verde
        messaggioLabel.setTextFill(Color.web("#00A300"));
        messaggioLabel.setText("COLLANA INSERITA");
        resetCampi(); //pulisce i campi
    }

    /**
     * Controlla la validità dei campi inseriti.
     *
     * @param issn              L'issn della collana che si vuole inserire
     * @param nome              Il nome della collana che si vuole inserire
     * @param caratteristica    La caratteristica della collana che si vuole inserire
     * @param editore           L'editore della collana che si vuole inserire
     * @param direttore         Il direttore della collana che si vuole inserire
     * @param dataPubblicazione La data di pubblicazione della collana che si vuole inserire
     * @throws IllegalArgumentException Eccezione lanciata quando una delle informazioni inserite non è valida
     */
    public void checkDati(String issn, String nome, String caratteristica, String editore, String direttore, LocalDate dataPubblicazione) throws IllegalArgumentException {
        messaggioLabel.setTextFill(Color.web("#FF2E2E")); //imposta il messaggio in rosso, nell'eventualità di un errore
        //controlla che l'issn inserito sia nel formato dell'espressione regolare nella condizione, in caso negativo visualizza un apposito messaggio di errore
        if (!issn.matches("[0-9]{4}-[0-9]{4}") || issn.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERIRE UN ISSN VALIDO");
            throw new IllegalArgumentException();
        }
        //controlla che il nome inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (nome.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERIRE UN NOME");
            throw new IllegalArgumentException();
        }
        //controlla che la caratteristica inserita sia valida, in caso negativo visualizza un apposito messaggio di errore
        if (caratteristica.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERIRE UNA CARATTERISTICA");
            throw new IllegalArgumentException();
        }
        //controlla che l'editore inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (editore.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERIRE UN EDITORE");
            throw new IllegalArgumentException();
        }
        //controlla che il direttore inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (direttore.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERIRE UN DIRETTORE");
            throw new IllegalArgumentException();
        }
        //controlla che la data di pubblicazione inserita sia valida e non successiva alla data odierna, in caso negativo visualizza un apposito messaggio di errore
        if (dataPubblicazione == null) {
            messaggioLabel.setText("ERRORE: INSERIRE UNA DATA DI PUBBLICAZIONE");
            throw new IllegalArgumentException();
        }
        if (dataPubblicazione.isAfter(LocalDate.now())) {
            messaggioLabel.setText("ERRORE: LA DATA DI PUBBLICAZIONE E' SUCCESSIVA ALLA DATA ODIERNA");
            throw new IllegalArgumentException();
        }
    }

    /**
     * Pulisce i campi dopo l'inserimento di una collana
     */
    public void resetCampi() {
        issnField.clear();
        direttoreField.clear();
        caratteristicaField.clear();
        editoreField.clear();
        descrizioneField.clear();
        dataAggiuntaField.setValue(null);
        nomeField.clear();
    }
}
