package com.biblioteca.controllers.controllersAggiungi;

import com.biblioteca.DAO.AutoreDAO;
import com.biblioteca.ImplementazioneDAO.AutoreImplementazionePostgresDAO;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

import java.sql.SQLException;
import java.time.LocalDate;

/**
 * Controller dedicato alla gestione della pagina per l'inserimento di autori.
 */
public class AggiungiAutoreController {
    @FXML
    private TextField nomeAutoreField;
    @FXML
    private TextField istitutoAutoreField;
    @FXML
    private DatePicker dataNascitaAutoreField;
    @FXML
    private Label messaggioLabel;

    /**
     * Sul click del tasto "Conferma", ottiene il contenuto dei campi, ne verifica la validità, e inserisce un autore
     * con quei valori nel database.
     */
    public void confermaOnAction() {
        //ottiene il contenuto dei campi
        String nominativo = nomeAutoreField.getText();
        String istituto = istitutoAutoreField.getText();
        LocalDate dataNascita = dataNascitaAutoreField.getValue();
        //controlla la validità dell'istituto inserito, se non viene inserito un valore, viene posto a null
        if (istituto.isBlank()) {
            istituto = null;
        }
        //controlla la validità del nominativo e della data di nascita inserita
        try {
            checkDati(nominativo, dataNascita);
        } catch (IllegalArgumentException ex) {
            return;
        }
        AutoreDAO inserimentoAutore = new AutoreImplementazionePostgresDAO(); //apertura della connessione col database
        try {
            inserimentoAutore.aggiungiAutoreDB(nominativo, istituto, dataNascita); //inserimento del nuovo autore nel database
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            inserimentoAutore.close(); //chiusura della connessione col database
        }
        //messaggio di avvenuto inserimento in verde
        messaggioLabel.setTextFill(Color.web("#00A300"));
        messaggioLabel.setText("AUTORE INSERITO");
        resetCampi(); //pulisce i campi
    }

    /**
     * Controlla i dati inseriti per il nuovo autore.
     *
     * @param nominativo  Il nominativo del nuovo autore.
     * @param dataNascita La data di nascita del nuovo autore.
     * @throws IllegalArgumentException Eccezione lanciata quando una delle informazioni inserite non è valida
     */
    public void checkDati(String nominativo, LocalDate dataNascita) throws IllegalArgumentException {
        messaggioLabel.setTextFill(Color.web("#FF2E2E")); //imposta il messaggio in rosso, nell'eventualità di un errore
        //controlla che il nominativo inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (nominativo.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERIRE UN NOME");
            throw new IllegalArgumentException();
        }
        //controlla che la data di nascita sia valida e che non sia successiva alla data odierna, in caso negativo visualizza un apposito messaggio di errore
        if (dataNascita != null && dataNascita.isAfter(LocalDate.now())) {
            messaggioLabel.setText("ERRORE: LA DATA DI NASCITA E' SUCCESSIVA ALLA DATA ODIERNA");
            throw new IllegalArgumentException();
        }
    }

    /**
     * Pulisce i campi dopo l'inserimento di un autore
     */
    public void resetCampi() {
        istitutoAutoreField.clear();
        nomeAutoreField.clear();
        dataNascitaAutoreField.setValue(null);
    }
}
