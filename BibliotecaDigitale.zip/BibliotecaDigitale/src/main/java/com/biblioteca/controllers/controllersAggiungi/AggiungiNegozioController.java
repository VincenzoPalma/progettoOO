package com.biblioteca.controllers.controllersAggiungi;

import com.biblioteca.DAO.NegozioDAO;
import com.biblioteca.ImplementazioneDAO.NegozioImplementazionePostgresDAO;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

import java.sql.SQLException;

/**
 * Controller dedicato alla gestione della pagina per l'inserimento di negozi.
 */
public class AggiungiNegozioController {
    @FXML
    private TextField nomeNegozioField;
    @FXML
    private TextField nomeSitoField;
    @FXML
    private Label messaggioLabel;

    /**
     * Sul click del tasto "Conferma", ottiene il contenuto dei campi, ne verifica la validità, e inserisce un negozio
     * con quei valori nel database.
     */
    public void confermaOnAction() {
        messaggioLabel.setTextFill(Color.web("#FF2E2E")); //imposta il messaggio in rosso, nell'eventualità di un errore
        //prende il contenuto dei campi
        String nomeNegozio = nomeNegozioField.getText();
        String sito = nomeSitoField.getText();
        //controlla se è stato inserito un sito, in caso negativo lo imposta a null
        if (sito.isBlank()) {
            sito = null;
        } else if (!sito.endsWith(".it") && !sito.endsWith(".com")) { //controlla che il sito inserito finisca con ".it" o ".com", in caso negativo visualizza un apposito messaggio di errore
            messaggioLabel.setText("ERRORE: IL SITO DEVE FINIRE CON '.it' O '.com'");
            return;
        }
        //controlla che il nome inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (nomeNegozio.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERIRE UN NOME VALIDO");
            return;
        }
        NegozioDAO aggiungiNegozio = new NegozioImplementazionePostgresDAO(); //apre la connessione col database
        try {
            aggiungiNegozio.aggiungiNegozioDB(nomeNegozio, sito); //inserimento del negozio nel database
        } catch (SQLException ex) {
            ex.printStackTrace();
            return;
        } finally {
            aggiungiNegozio.close(); //chiude la connessione col database
        }
        //messaggio di avvenuto inserimento in verde
        messaggioLabel.setTextFill(Color.web("#00A300"));
        messaggioLabel.setText("NEGOZIO AGGIUNTO");
        //pulisce i campi dopo l'inserimento
        nomeNegozioField.clear();
        nomeSitoField.clear();
    }


}
