package com.biblioteca.controllers.controllersAggiungi;

import com.biblioteca.DAO.SalaDAO;
import com.biblioteca.ImplementazioneDAO.SalaImplementazionePostgresDAO;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

import java.sql.SQLException;

/**
 * Controller dedicato alla gestione della pagina per l'inserimento di sale.
 */
public class AggiungiSalaController {
    @FXML
    private TextField nomeSalaField;
    @FXML
    private TextField capienzaField;
    @FXML
    private TextField indirizzoField;
    @FXML
    private Label messaggioLabel;

    /**
     * Sul click del tasto "Conferma", ottiene il contenuto dei campi, ne verifica la validità, e inserisce una sala
     * con quei valori nel database.
     */
    public void confermaOnAction() {
        //prende il contenuto dei campi
        String nomeSala = nomeSalaField.getText();
        String indirizzo = indirizzoField.getText();
        int capienza;
        //controlla la validità della capienza inserita
        try {
            capienza = Integer.parseInt(capienzaField.getText());
        } catch (NumberFormatException ex) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("ERRORE: INSERIRE UNA CAPIENZA VALIDA");
            return;
        }
        //controlla la validità delle informazioni inserite
        try {
            checkDati(nomeSala, indirizzo, capienza);
        } catch (IllegalArgumentException ex) {
            return;
        }
        SalaDAO inserimentoSala = new SalaImplementazionePostgresDAO(); //apertura della connessione col database
        try {
            inserimentoSala.aggiungiSalaDB(nomeSala, indirizzo, capienza); //inserimento della sala nel database
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            inserimentoSala.close(); //chiusura della connessione col database
        }
        //messaggio di avvenuto inserimento in verde
        messaggioLabel.setTextFill(Color.web("#00A300"));
        messaggioLabel.setText("Sala Inserita");
        resetCampi();
    }

    /**
     * Controlla la validità dei dati inseriti
     *
     * @param nomeSala  Il nome della sala da inserire
     * @param indirizzo L'indirizzo della sala da inserire
     * @param capienza  La capienza della sala da inserire
     * @throws IllegalArgumentException Eccezione lanciata quando una delle informazioni inserite non è valida
     */
    public void checkDati(String nomeSala, String indirizzo, int capienza) throws IllegalArgumentException {
        messaggioLabel.setTextFill(Color.web("#FF2E2E")); //imposta il messaggio in rosso, nell'eventualità di un errore
        //controlla che la capienza inserita sia valida, in caso negativo visualizza un apposito messaggio di errore
        if (capienza <= 0) {
            messaggioLabel.setText("ERRORE: CAPIENZA INSERITA NON VALIDA");
            throw new IllegalArgumentException();
        }
        //controlla che il nome inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (nomeSala.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERIRE IL NOME DELLA SALA");
            throw new IllegalArgumentException();
        }
        //controlla che l'indirizzo inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (indirizzo.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERIRE UN INDIRIZZO");
            throw new IllegalArgumentException();
        }
    }

    /**
     * Pulisce i campi dopo l'inserimento di una collana
     */
    public void resetCampi() {
        nomeSalaField.clear();
        indirizzoField.clear();
        capienzaField.clear();
    }
}
