package com.biblioteca.controllers.controllersModifica;

import com.biblioteca.DAO.ArticoloScientificoDAO;
import com.biblioteca.DAO.ConferenzaDAO;
import com.biblioteca.ImplementazioneDAO.ArticoloScientificoImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.ConferenzaImplementazionePostgresDAO;
import com.biblioteca.model.ArticoloScientifico;
import com.biblioteca.model.Conferenza;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Controller dedicato alla gestione della pagina per aggiungere conferenze ad articoli.
 */

public class ModificaConferenzaController {

    @FXML
    private ListView<String> listaConferenzeDisponibili;

    /**
     * L'articolo a cui si vuole associare la conferenza.
     */
    private ArticoloScientifico articoloScientifico;

    /**
     * ArrayList che contiene le conferenze disponibili.
     */
    private ArrayList<Conferenza> conferenzeDisponibili = new ArrayList<>();

    public ArticoloScientifico getArticoloScientifico() {
        return articoloScientifico;
    }

    public void setArticoloScientifico(ArticoloScientifico articoloScientifico) {
        this.articoloScientifico = articoloScientifico;
    }

    public ArrayList<Conferenza> getConferenzeDisponibili() {
        return conferenzeDisponibili;
    }

    public void setConferenzeDisponibili(ArrayList<Conferenza> conferenzeDisponibili) {
        this.conferenzeDisponibili = conferenzeDisponibili;
    }

    public void preparaPagina(ArticoloScientifico articoloScientifico) {
        //imposta l'articolo
        setArticoloScientifico(articoloScientifico);
        //ricerca di tutte le conferenze
        //creazione degli arraylist che conterranno le informazioni delle conferenze trovate
        ArrayList<Integer> idConferenze = new ArrayList<>();
        ArrayList<String> cittaConferenze = new ArrayList<>();
        ArrayList<String> struttureConferenze = new ArrayList<>();
        ArrayList<LocalDate> dateInizioConferenze = new ArrayList<>();
        ArrayList<LocalDate> dateFineConferenze = new ArrayList<>();
        ArrayList<String> responsabileConferenza = new ArrayList<>();
        ArrayList<Conferenza> conferenze = new ArrayList<>();
        ConferenzaDAO cercaConferenze = new ConferenzaImplementazionePostgresDAO(); //connessione al database
        try {
            cercaConferenze.getAllConferenzeDB(idConferenze, cittaConferenze, struttureConferenze, dateInizioConferenze, dateFineConferenze, responsabileConferenza); //cerca tutte le conferenze
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaConferenze.close(); //chiusura della connessione
        }
        //per ogni conferenza trovata, crea un oggetto e lo aggiunge all'arraylist delle conferenze
        for (int i = 0; i < idConferenze.size(); i++) {
            Conferenza conferenza = new Conferenza(idConferenze.get(i), cittaConferenze.get(i), struttureConferenze.get(i), dateInizioConferenze.get(i), dateFineConferenze.get(i), responsabileConferenza.get(i));
            conferenze.add(conferenza);
        }
        //scarta tutte le conferenze che hanno l'anno diverso da quello dell'articolo scientifico
        for (Conferenza conferenza : conferenze) {
            if (conferenza.getDatainizio().getYear() == articoloScientifico.getAnnopubblicazione()) {
                conferenzeDisponibili.add(conferenza);
            }
        }
        //visualizza nella lista, ogni conferenza trovata idonea
        for (Conferenza conferenza : conferenzeDisponibili) {
            listaConferenzeDisponibili.getItems().add(conferenza.getStruttura() + " | " + conferenza.getCitta());
        }
    }

    /**
     * Aggiunge l'articolo alla conferenza selezionata.
     */
    public void aggiungiConferenza() {
        if (!listaConferenzeDisponibili.getSelectionModel().isEmpty()) { //se viene selezionato un elemento valido
            int indiceConferenzaSelezionata = listaConferenzeDisponibili.getSelectionModel().getSelectedIndex(); //ottenimento dell'indice della conferenza selezionata nella lista
            ArticoloScientificoDAO aggiungiArticoloConferenza = new ArticoloScientificoImplementazionePostgresDAO(); //apertura della connessione con il database
            Conferenza conferenzaAggiunta = conferenzeDisponibili.get(indiceConferenzaSelezionata); //ottenimento della conferenza selezionata
            try {
                //aggiunta dell'articolo alla conferenza
                aggiungiArticoloConferenza.modificaArticoloScientificoDB(articoloScientifico.getIdarticolo(), articoloScientifico.getTitolo(), articoloScientifico.getTema(), articoloScientifico.getArgomento(), articoloScientifico.getAnnopubblicazione(), articoloScientifico.getEditore(), articoloScientifico.getCartaceo(), articoloScientifico.getDigitale(), articoloScientifico.getAudiolibro(), conferenzaAggiunta.getIdconferenza(), articoloScientifico.getRivista().getIssn(), articoloScientifico.getRivista().getNumero());
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                aggiungiArticoloConferenza.close(); //chiusura della connessione
            }
            conferenzaAggiunta.getArticoli().add(articoloScientifico); //aggiunge l'articolo alla conferenza
            articoloScientifico.setConferenza(conferenzaAggiunta); //imposta la conferenza dell'articolo
            Stage stage = (Stage) listaConferenzeDisponibili.getScene().getWindow();
            stage.close(); //chiude la pagina
        }
    }
}
