package com.biblioteca.controllers.controllersPagine;

import com.biblioteca.DAO.CollanaDAO;
import com.biblioteca.DAO.LibroDAO;
import com.biblioteca.DAO.PartecipazioneDAO;
import com.biblioteca.ImplementazioneDAO.CollanaImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.LibroImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.PartecipazioneImplementazionePostgresDAO;
import com.biblioteca.bibliotecadigitale.Main;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaDidatticoController;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaRomanzoController;
import com.biblioteca.model.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Controller dedicato alla gestione della pagina per le collane.
 */
public class PaginaCollanaController implements Initializable {
    @FXML
    private Label nomeCollanaLabel;
    @FXML
    private Label issnLabel;
    @FXML
    private Label editoreLabel;
    @FXML
    private Label caratteristicaLabel;
    @FXML
    private Label descrizioneLabel;
    @FXML
    private Label direttoreLabel;
    @FXML
    private Label dataPubblicazioneLabel;
    @FXML
    private ListView<String> listaLibriCollana;
    @FXML
    private Button modificaCollanaButton;
    @FXML
    private Button confermaModifiche;
    @FXML
    private Button annullaModifiche;
    @FXML
    private TextField modificaISSN;
    @FXML
    private TextField modificaCaratteristica;
    @FXML
    private TextField modificaDirettore;
    @FXML
    private TextField modificaDescrizione;
    @FXML
    private DatePicker modificaDataPubblicazione;
    @FXML
    private Label messaggioLabel;
    @FXML
    private Button eliminaButton;

    @FXML
    private ImageView sfondo;

    /**
     * Collana di cui si visualizzano le informazioni nella pagina.
     */
    private Collana collana;

    /**
     * Utente che ha aperto la pagina, utilizzato per
     * decidere se l'utente in questione può o meno modificare i
     * dati della pagina.
     */
    private Utente utente;

    public Collana getCollana() {
        return collana;
    }

    public void setCollana(Collana collana) {
        this.collana = collana;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        File sfondoFile = new File("src/Images/paginaCollana.png");
        Image sfondoImmagine = new Image(sfondoFile.toURI().toString());
        sfondo.setImage(sfondoImmagine);

    }

    /**
     * Imposta le informazioni della collana nella pagina.
     * Utilizza le informazioni presenti nell'oggetto "collana".
     * Per i libri contenuti nella collana, viene effettuata una ricerca nel database tramite {@link PartecipazioneImplementazionePostgresDAO}.
     *
     * @param collana Oggetto di tipo Collana di cui si vogliono mostrare le informazioni
     * @param utente  Tipo di utente che accede alla pagina
     */
    public void preparaPagina(Collana collana, Utente utente) {
        //assegna la sala e il tipo utente agli attributi del controller
        setCollana(collana);
        setUtente(utente);
        //imposta i label che compongono la pagina in base al contenuto dell'oggetto collana
        setInformazioniCollana();
        ArrayList<Partecipazione> partecipazioniCollana = new ArrayList<>();
        //dichiarazione degli arraylist che conterranno le informazioni dei risultati della ricerca
        ArrayList<String> isbnLibri = new ArrayList<>();
        ArrayList<LocalDate> dataPartecipazioni = new ArrayList<>();
        PartecipazioneDAO cercaPartecipazioni = new PartecipazioneImplementazionePostgresDAO(); //connessione col database
        try {
            cercaPartecipazioni.cercaPartecipazionePerIssnCollana(collana.getIssn(), isbnLibri, dataPartecipazioni); //cerca nel database le partecipazioni della collana
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaPartecipazioni.close(); //chiude la connessione
        }
        ArrayList<Libro> libriCollana = cercaLibriCollana(collana.getIssn()); //ottiene i libri della collana
        //per ogni libro che partecipa alla collana, crea un oggetto Partecipazione e lo aggiunge all'arraylist
        for (int i = 0; i < isbnLibri.size(); i++) {
            Partecipazione partecipazione = new Partecipazione(dataPartecipazioni.get(i), libriCollana.get(i), collana);
            partecipazioniCollana.add(partecipazione);
        }
        collana.setPartecipazioni(partecipazioniCollana);
        //visualizza tutti i libri contenuti nella collana
        for (Partecipazione partecipazione : collana.getPartecipazioni()) {
            if (partecipazione.getLibro() instanceof Romanzo) {
                listaLibriCollana.getItems().add(partecipazione.getLibro().getTitolo() + " | Romanzo");
            } else {
                listaLibriCollana.getItems().add(partecipazione.getLibro().getTitolo() + " | Didattico");
            }
        }
        //se l'utente è un amministratore, visualizza il bottone per la modifica
        if (utente.getTipo().equals("Amministratore")) {
            modificaCollanaButton.setDisable(false);
            modificaCollanaButton.setVisible(true);
        }
    }

    /**
     * Cerca i libri della collana con issn uguale a quello passato
     * come parametro nel database. Ritorna un arraylist di libri trovati, sia didattici che romanzi.
     *
     * @param issnCollana L'issn della collana di cui si vogliono ottenere i libri.
     * @return Un arraylist di oggetti di tipo Libro.
     */
    public ArrayList<Libro> cercaLibriCollana(String issnCollana) {
        LibroDAO cercaLibri = new LibroImplementazionePostgresDAO(); //connessione al database
        ArrayList<Libro> libriCollana = new ArrayList<>(); //arraylist dei libri della collana
        //dichiarazione degli arraylist che conterranno le informazioni dei risultati della ricerca
        ArrayList<String> isbn = new ArrayList<>();
        ArrayList<String> titoli = new ArrayList<>();
        ArrayList<String> generi = new ArrayList<>();
        ArrayList<LocalDate> dateUscita = new ArrayList<>();
        ArrayList<String> tipoLibri = new ArrayList<>();
        ArrayList<String> editori = new ArrayList<>();
        ArrayList<Boolean> cartaceo = new ArrayList<>();
        ArrayList<Boolean> digitale = new ArrayList<>();
        ArrayList<Boolean> audiolibro = new ArrayList<>();
        try {
            cercaLibri.cercaLibroPerCollana(issnCollana, isbn, titoli, generi, dateUscita, tipoLibri, editori, cartaceo, digitale, audiolibro);//ricerca dei libri della collana
        } catch (SQLException ex) {
            ex.printStackTrace();
            return new ArrayList<>(); //ritorna un arraylist vuoto in caso di eccezione
        }
        //per ogni libro trovato, viene creato un oggetto in base al tipo di libro e viene inserito nell'arraylist
        for (int i = 0; i < isbn.size(); i++) {
            if (tipoLibri.get(i).equals("Romanzo")) {
                Romanzo romanzo = new Romanzo(titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), dateUscita.get(i).getYear(), isbn.get(i), dateUscita.get(i).getDayOfMonth(), dateUscita.get(i).getMonthValue(), generi.get(i), null, null);
                libriCollana.add(romanzo);
            } else {
                LibroDidattico libroDidattico = new LibroDidattico(titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), dateUscita.get(i).getYear(), isbn.get(i), dateUscita.get(i).getDayOfMonth(), dateUscita.get(i).getMonthValue(), generi.get(i));
                libriCollana.add(libroDidattico);
            }
        }
        return libriCollana;
    }

    /**
     * Sul click di un libro, chiama una nuova finestra che
     * conterrà le informazioni di quel libro, le informazioni mostrate dalla finestra
     * dipenderanno dal tipo di libro.
     * <p>
     * Passa l'oggetto del libro selezionato e il tipo di utente al controller della schermata che chiama.
     *
     * @see PaginaRomanzoController
     * @see PaginaDidatticoController
     */
    public void visualizzaTesto() throws IOException {
        try {
            int indiceTesto = listaLibriCollana.getSelectionModel().getSelectedIndex(); //ottiene l'indice del libro selezionato nella lista di libri visualizzati
            Libro libroSelezionato = collana.getPartecipazioni().get(indiceTesto).getLibro(); //ottiene il libro selezionato dalla collana tramite l'indice ottenuto in precedenza
            Stage stage = new Stage();
            FXMLLoader fxmlLoader;
            Scene scene;
            if (libroSelezionato instanceof Romanzo) {
                //se il libro selezionato è un romanzo, prepara e apre la pagina per i romanzi
                fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaRomanzo.fxml"));
                Parent root = fxmlLoader.load();
                PaginaRomanzoController paginaRomanzo = fxmlLoader.getController();
                paginaRomanzo.preparaPagina((Romanzo) libroSelezionato, utente);
                scene = new Scene(root, 1300, 900);
            } else {
                //se il libro selezionato è un libro didattico, prepara e apre la pagina per i libri didattici
                fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaDidattico.fxml"));
                Parent root = fxmlLoader.load();
                PaginaDidatticoController paginaRomanzo = fxmlLoader.getController();
                paginaRomanzo.preparaPagina((LibroDidattico) libroSelezionato, utente);
                scene = new Scene(root, 1300, 900);
            }
            stage.setTitle(libroSelezionato.getTitolo());
            stage.setScene(scene);
            stage.show();
            stage.setResizable(false);
        } catch (IndexOutOfBoundsException ignored) {
        } //se viene cliccato uno spazio vuoto, ignora l'eccezione lanciata
    }

    /**
     * Sul click del tasto di modifica, imposta tutti i campi per modificare le informazioni.
     */
    public void modificaCollanaOnAction() {
        modificaCollanaButton.setVisible(false);
        annullaModifiche.setVisible(true);
        confermaModifiche.setVisible(true);
        modificaCaratteristica.setVisible(true);
        caratteristicaLabel.setText("");
        modificaCaratteristica.setText(collana.getCaratteristica());
        modificaDescrizione.setVisible(true);
        modificaDescrizione.setText(collana.getDescrizione());
        descrizioneLabel.setText("");
        modificaDirettore.setVisible(true);
        modificaDirettore.setText(collana.getDirettore());
        direttoreLabel.setText("");
        modificaISSN.setText(collana.getIssn());
        modificaDataPubblicazione.setVisible(true);
        modificaDataPubblicazione.setValue(collana.getDatapubblicazione());
        modificaISSN.setVisible(true);
        modificaISSN.setText(collana.getIssn());
        issnLabel.setText("");
        eliminaButton.setVisible(true);
    }

    /**
     * Imposta le informazioni della collana nella pagina.
     */
    public void setInformazioniCollana() {
        issnLabel.setText(collana.getIssn());
        nomeCollanaLabel.setText(collana.getNome());
        issnLabel.setText(collana.getIssn());
        editoreLabel.setText(collana.getEditore());
        caratteristicaLabel.setText(collana.getCaratteristica());
        direttoreLabel.setText(collana.getDirettore());
        dataPubblicazioneLabel.setText(String.valueOf(collana.getDatapubblicazione()));
        //se la collana non ha descrizione, viene indicato
        if (collana.getDescrizione() != null) {
            descrizioneLabel.setText(collana.getDescrizione());
        } else {
            descrizioneLabel.setText("nessuna");
        }
    }


    /**
     * Sul click del tasto "annulla", rimuove tutti i campi per la modifica, e reimposta le informazioni nella pagina.
     */
    public void resetModificheOnAction() {
        setInformazioniCollana();
        modificaCollanaButton.setVisible(true);
        annullaModifiche.setVisible(false);
        confermaModifiche.setVisible(false);
        modificaCaratteristica.setVisible(false);
        modificaDescrizione.setVisible(false);
        modificaDirettore.setVisible(false);
        modificaDataPubblicazione.setVisible(false);
        modificaISSN.setVisible(false);
        eliminaButton.setVisible(false);
        messaggioLabel.setText("");
    }

    /**
     * Sul click del tasto "conferma" in modalità di modifica, esegue le modifiche sul database,
     * reimposta la pagina ed esce dalla modalità modifica.
     */
    public void confermaModificheOnAction() {
        //prende il contenuto dei campi
        String nuovoISSN = modificaISSN.getText();
        String nuovoDirettore = modificaDirettore.getText();
        String nuovaDescrizione = modificaDescrizione.getText();
        String nuovaCaratteristica = modificaCaratteristica.getText();
        LocalDate nuovaDataDiPubblicazione = modificaDataPubblicazione.getValue();
        //verifica che sia stata inserita una data di pubblicazione
        if (nuovaDataDiPubblicazione == null) {
            messaggioLabel.setText("INSERIRE UNA DATA DI PUBBLICAZIONE");
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            return;
        }
        //controlla che la nuova data di pubblicazione sia antecedente alle date di partecipazione dei libri alla collana
        for (Partecipazione partecipazione : collana.getPartecipazioni()) {
            if (partecipazione.getData().isBefore(nuovaDataDiPubblicazione)) {
                messaggioLabel.setText("LA DATA INSERITA E' ANTECEDENTE ALLA PARTECIPAZIONE DI UN LIBRO");
                messaggioLabel.setTextFill(Color.web("#FF2E2E"));
                return;
            }
        }
        //controlla che l'issn inserito sia valido
        if (!nuovoISSN.matches(("[0-9]{4}-[0-9]{4}")) || nuovoISSN.isBlank()) {
            messaggioLabel.setText("INSERIRE UN ISSN VALIDO");
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            return;
        }
        //controlla la validità dei dati inseriti, se non sono validi, rimarranno uguali all'informazione originale
        if (nuovaDescrizione == null || nuovaDescrizione.isBlank()) {
            nuovaDescrizione = null;
        }
        if (nuovaCaratteristica.isBlank()) {
            nuovaCaratteristica = collana.getCaratteristica();
        }
        if (nuovoDirettore.isBlank()) {
            nuovoDirettore = collana.getDirettore();
        }
        CollanaDAO modificaCollana = new CollanaImplementazionePostgresDAO(); //connessione col database
        try {
            modificaCollana.modificaCollanaDB(collana.getIssn(), nuovoISSN, nuovaCaratteristica, nuovaDataDiPubblicazione, nuovoDirettore, nuovaDescrizione); //update della collana nel database
        } catch (SQLException ex) {
            ex.printStackTrace();
            return;
        } finally {
            modificaCollana.close(); //chiusura della connessione
        }
        //imposta i nuovi valori alla collana
        collana.setIssn(nuovoISSN);
        collana.setCaratteristica(nuovaCaratteristica);
        collana.setDirettore(nuovoDirettore);
        collana.setDatapubblicazione(nuovaDataDiPubblicazione);
        collana.setDescrizione(nuovaDescrizione);
        resetModificheOnAction(); //reimpostazione dei dati nella pagina
    }


    /**
     * Sul click del tasto "elimina", elimina la collana.
     */
    public void eliminaOnAction() {
        CollanaDAO eliminaCollana = new CollanaImplementazionePostgresDAO();
        try {
            eliminaCollana.eliminaCollanaDB(collana.getIssn());
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            eliminaCollana.close();
        }
        for (Partecipazione partecipazione : collana.getPartecipazioni()) {
            partecipazione.setLibro(null);
        }
        Stage stage = (Stage) eliminaButton.getScene().getWindow(); //chiude la pagina
        stage.close();
    }
}
