package com.biblioteca.controllers.controllersModifica;

import com.biblioteca.DAO.ArticoloScientificoDAO;
import com.biblioteca.DAO.RivistaDAO;
import com.biblioteca.ImplementazioneDAO.ArticoloScientificoImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.RivistaImplementazionePostgresDAO;
import com.biblioteca.model.ArticoloScientifico;
import com.biblioteca.model.Rivista;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Controller dedicato alla gestione della pagina per l'aggiunta di riviste.
 */
public class ModificaRivistaController {
    @FXML
    private ListView<String> listaRivisteDisponibili;

    /**
     * L'articolo a cui si vuole associare la rivista.
     */
    private ArticoloScientifico articoloScientifico;

    /**
     * ArrayList che contiene le riviste disponibili.
     */
    private ArrayList<Rivista> rivisteDisponibili = new ArrayList<>();

    public ArticoloScientifico getArticoloScientifico() {
        return articoloScientifico;
    }

    public void setArticoloScientifico(ArticoloScientifico articoloScientifico) {
        this.articoloScientifico = articoloScientifico;
    }

    public ArrayList<Rivista> getRivisteDisponibili() {
        return rivisteDisponibili;
    }

    public void setRivisteDisponibili(ArrayList<Rivista> rivisteDisponibili) {
        this.rivisteDisponibili = rivisteDisponibili;
    }

    /**
     * Visualizza nella lista, tutte le riviste che possono essere associate
     * all'articolo scientifico, in base al tema dell'articolo e alla data di pubblicazione.
     */
    public void preparaPagina(ArticoloScientifico articoloScientifico) {
        //impostazione dell'articolo
        setArticoloScientifico(articoloScientifico);
        //ricerca di tutte le riviste
        //creazione degli arraylist che conterranno le informazioni delle riviste trovate
        ArrayList<String> issnRiviste = new ArrayList<>();
        ArrayList<String> nomiRiviste = new ArrayList<>();
        ArrayList<Integer> numeriRiviste = new ArrayList<>();
        ArrayList<String> temiRiviste = new ArrayList<>();
        ArrayList<Integer> anniRiviste = new ArrayList<>();
        ArrayList<String> responsabiliRiviste = new ArrayList<>();
        ArrayList<Rivista> riviste = new ArrayList<>();
        RivistaDAO cercaRiviste = new RivistaImplementazionePostgresDAO(); //connessione al database
        try {
            cercaRiviste.getAllRivisteDB(issnRiviste, nomiRiviste, numeriRiviste, temiRiviste, anniRiviste, responsabiliRiviste); //cerca tutte le riviste
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaRiviste.close(); //chiusura della connessione
        }
        //per ogni rivista trovata, crea un oggetto e lo aggiunge all'arraylist delle riviste
        for (int i = 0; i < issnRiviste.size(); i++) {
            Rivista rivista = new Rivista(issnRiviste.get(i), nomiRiviste.get(i), temiRiviste.get(i), anniRiviste.get(i), responsabiliRiviste.get(i), numeriRiviste.get(i));
            riviste.add(rivista);
        }
        //scarta tutte le riviste che hanno tema o anno diverso da quello dell'articolo scientifico
        for (Rivista rivista : riviste) {
            if (rivista.getTema().equals(articoloScientifico.getTema()) && rivista.getAnno() == articoloScientifico.getAnnopubblicazione()) {
                rivisteDisponibili.add(rivista);
            }
        }
        //visualizza nella lista, ogni rivista trovata idonea
        for (Rivista rivista : rivisteDisponibili) {
            listaRivisteDisponibili.getItems().add(rivista.getNome() + " | n°" + rivista.getNumero());
        }
    }

    /**
     * Aggiunge l'articolo alla rivista selezionata.
     */
    public void aggiungiRivista() {
        if (!listaRivisteDisponibili.getSelectionModel().isEmpty()) { //se viene selezionato un elemento valido
            int indiceRivistaSelezionata = listaRivisteDisponibili.getSelectionModel().getSelectedIndex(); //ottenimento dell'indice della rivista selezionata nella lista
            ArticoloScientificoDAO aggiungiArticoloRivista = new ArticoloScientificoImplementazionePostgresDAO(); //apertura della connessione con il database
            Rivista rivistaAggiunta = rivisteDisponibili.get(indiceRivistaSelezionata); //ottenimento della rivista selezionata
            try {
                aggiungiArticoloRivista.modificaArticoloScientificoDB(articoloScientifico.getIdarticolo(), articoloScientifico.getTitolo(), articoloScientifico.getTema(), articoloScientifico.getArgomento(), articoloScientifico.getAnnopubblicazione(), articoloScientifico.getEditore(), articoloScientifico.getCartaceo(), articoloScientifico.getDigitale(), articoloScientifico.getAudiolibro(), articoloScientifico.getConferenza().getIdconferenza(), rivistaAggiunta.getIssn(), rivistaAggiunta.getNumero()); //aggiunta dell'articolo alla rivista
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                aggiungiArticoloRivista.close(); //chiusura della connessione
            }
            rivistaAggiunta.getArticoli().add(articoloScientifico); //aggiunge l'articolo alla rivista
            articoloScientifico.setRivista(rivistaAggiunta); //imposta la rivista dell'articolo
            Stage stage = (Stage) listaRivisteDisponibili.getScene().getWindow();
            stage.close(); //chiude la pagina
        }
    }
}
