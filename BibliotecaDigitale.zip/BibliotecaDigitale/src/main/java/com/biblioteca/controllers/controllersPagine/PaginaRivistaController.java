package com.biblioteca.controllers.controllersPagine;

import com.biblioteca.DAO.ArticoloScientificoDAO;
import com.biblioteca.DAO.RivistaDAO;
import com.biblioteca.ImplementazioneDAO.ArticoloScientificoImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.RivistaImplementazionePostgresDAO;
import com.biblioteca.bibliotecadigitale.Main;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaArticoloController;
import com.biblioteca.model.ArticoloScientifico;
import com.biblioteca.model.Rivista;
import com.biblioteca.model.Utente;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Controller dedicato alla gestione della pagina delle riviste.
 */
public class PaginaRivistaController implements Initializable {
    @FXML
    private Label nomeRivistaLabel;
    @FXML
    private Label issnLabel;
    @FXML
    private Label temaLabel;
    @FXML
    private Label annoLabel;
    @FXML
    private Label responsabileLabel;
    @FXML
    private ListView<String> listaArticoli;
    @FXML
    private Button modificaRivistaButton;
    @FXML
    private Button confermaModifiche;
    @FXML
    private Button annullaModifiche;
    @FXML
    private Button eliminaButton;
    @FXML
    private TextField modificaIssn;
    @FXML
    private TextField modificaResponsabile;
    @FXML
    private Label messaggioLabel;
    @FXML
    private ImageView sfondo;

    /**
     * L'utente che ha aperto la pagina.
     */
    private Utente utente;

    /**
     * La rivista di cui si vogliono mostrare le informazioni.
     */
    private Rivista rivista;

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    public Rivista getRivista() {
        return rivista;
    }

    public void setRivista(Rivista rivista) {
        this.rivista = rivista;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        File sfondoFile = new File("src/Images/paginaRivista.png");
        Image sfondoImmagine = new Image(sfondoFile.toURI().toString());
        sfondo.setImage(sfondoImmagine);

    }

    /**
     * Imposta le informazione della rivista nella pagina.
     *
     * @param rivista La rivista di cui si mostrano le informazioni.
     * @param utente  L'utente che ha aperto la pagina.
     */
    public void preparaPagina(Rivista rivista, Utente utente) {
        //imposta la rivista e l'utente
        setRivista(rivista);
        setUtente(utente);
        setInformazioniBase(); //imposta le informazioni della rivista nella pagina
        //cerca gli articoli contenuti nella rivista
        //creazione degli arraylist che conterranno le informazioni dei risultati dell'interrogazione
        ArrayList<String> titoli = new ArrayList<>();
        ArrayList<String> argomenti = new ArrayList<>();
        ArrayList<String> temi = new ArrayList<>();
        ArrayList<Integer> annoPubblicazione = new ArrayList<>();
        ArrayList<Integer> idArticoli = new ArrayList<>();
        ArrayList<String> editori = new ArrayList<>();
        ArrayList<Boolean> cartaceo = new ArrayList<>();
        ArrayList<Boolean> digitale = new ArrayList<>();
        ArrayList<Boolean> audiolibro = new ArrayList<>();
        //apre la connessione col database
        ArticoloScientificoDAO cercaArticoliRivista = new ArticoloScientificoImplementazionePostgresDAO();
        ArrayList<ArticoloScientifico> risultatiArticoli = new ArrayList<>();
        try {
            cercaArticoliRivista.cercaArticoloPerRivista(rivista.getIssn(), rivista.getNumero(), idArticoli, titoli, temi, argomenti, annoPubblicazione, editori, cartaceo, digitale, audiolibro); //esegue la ricerca per gli articoli nel database
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaArticoliRivista.close(); //chiusura della connessione al database
        }
        for (int i = 0; i < idArticoli.size(); i++) {
            //per ogni articolo trovato, crea il relativo oggetto di tipo ArticoloScientifico, lo aggiunge all'arraylist e lo visualizza nella lista degli articoli
            ArticoloScientifico articoloScientificoTrovato = new ArticoloScientifico(idArticoli.get(i), titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), annoPubblicazione.get(i), temi.get(i), argomenti.get(i), null, null);
            listaArticoli.getItems().add(articoloScientificoTrovato.getTitolo());
            risultatiArticoli.add(articoloScientificoTrovato);
        }
        rivista.setArticoli(risultatiArticoli); //imposta gli articoli della rivista
        //se l'utente è un amministratore, mostra il bottone per modificare la pagina
        if (utente.getTipo().equals("Amministratore")) {
            modificaRivistaButton.setVisible(true);
        }
    }

    /**
     * Imposta le informazioni base della rivista.
     */
    public void setInformazioniBase() {
        //imposta le informazioni della rivista nella pagina
        issnLabel.setText(rivista.getIssn());
        nomeRivistaLabel.setText(rivista.getNome() + " | " + rivista.getNumero());
        responsabileLabel.setText(rivista.getResponsabile());
        temaLabel.setText(rivista.getTema());
        annoLabel.setText(String.valueOf(rivista.getAnno()));
    }

    /**
     * Visualizza l'articolo selezionato.
     */
    public void visualizzaArticolo() throws IOException {
        try {
            int indiceArticoloSelezionato = listaArticoli.getSelectionModel().getSelectedIndex(); //ottiene l'indice dell'elemento selezionato nella lista degli articoli
            Stage stage = new Stage();
            FXMLLoader fxmlLoader;
            fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaArticolo.fxml"));
            Parent root = fxmlLoader.load();
            PaginaArticoloController paginaArticolo = fxmlLoader.getController();
            paginaArticolo.preparaPagina(rivista.getArticoli().get(indiceArticoloSelezionato), utente); //passa l'oggetto dell'articolo selezionato e il tipo di utente al controller della pagina dell'articolo
            Scene scene = new Scene(root, 1300, 900);
            stage.setTitle(rivista.getArticoli().get(indiceArticoloSelezionato).getTitolo());
            stage.setScene(scene);
            stage.show();
            stage.setResizable(false);
        } catch (IndexOutOfBoundsException ignored) {
        } //se viene cliccato uno spazio vuoto, ignora l'eccezione lanciata
    }

    /**
     * Sul click del tasto "modifica", visualizza i campi per la modifica della pagina.
     */
    public void modificaRivistaOnAction() {
        //visualizza i campi
        modificaRivistaButton.setVisible(false);
        annullaModifiche.setVisible(true);
        confermaModifiche.setVisible(true);
        eliminaButton.setVisible(true);
        modificaIssn.setVisible(true);
        modificaIssn.setText(rivista.getIssn());
        issnLabel.setText("");
        modificaResponsabile.setVisible(true);
        modificaResponsabile.setText(rivista.getResponsabile());
        responsabileLabel.setText("");
    }

    /**
     * Sul click del tasto "conferma" nella modalità di modifica, esegue l'update della
     * relativa rivista, con i nuovi dati inseriti, dopo averli controllati.
     */
    public void confermaModificheOnAction() {
        //ottenimento del contenuto dei campi
        String nuovoResponsabile = modificaResponsabile.getText();
        String nuovoIssn = modificaIssn.getText();
        if (nuovoResponsabile.isBlank()) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("INSERIRE UN RESPONSABILE VALIDO.");
            return;
        }
        if (!nuovoIssn.matches("[0-9]{4}-[0-9]{4}") || nuovoIssn.isBlank()) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("INSERIRE UN ISSN VALIDO.");
            return;
        }
        RivistaDAO modificaRivista = new RivistaImplementazionePostgresDAO(); //connessione al database
        try {
            modificaRivista.modificaRivista(rivista.getIssn(), rivista.getNumero(), rivista.getNome(), rivista.getTema(), nuovoResponsabile, rivista.getAnno(), nuovoIssn, rivista.getNumero()); //modifica della rivista nel database
            modificaRivista.modificaIssnRiviste(nuovoIssn, rivista.getIssn()); //modifica l'issn a tutte le riviste col vecchio issn della rivista
        } catch (SQLException ex) { //quando viene inserito un issn già in uso
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("ISSN E NUMERO GIA' IN USO.");
            return;
        } finally {
            modificaRivista.close(); //chiusura della connessione
        }
        //impostazione dei nuovi valore
        rivista.setIssn(nuovoIssn);
        rivista.setResponsabile(nuovoResponsabile);
        resetModificheOnAction(); //reimposta la pagina
    }

    /**
     * Sul click del tasto "annulla", chiude tutti i campi per la modifica della pagina
     */
    public void resetModificheOnAction() {
        //nasconde i campi
        modificaRivistaButton.setVisible(true);
        annullaModifiche.setVisible(false);
        confermaModifiche.setVisible(false);
        eliminaButton.setVisible(false);
        modificaResponsabile.setVisible(false);
        modificaIssn.setVisible(false);
        messaggioLabel.setText("");
        setInformazioniBase(); //reimposta le informazioni
    }

    /**
     * Sul click del tasto "elimina", elimina la rivista dal database.
     */
    public void eliminaOnAction() {
        RivistaDAO eliminaRivista = new RivistaImplementazionePostgresDAO(); //connessione al database
        try {
            eliminaRivista.eliminaRivista(rivista.getIssn(), rivista.getNumero()); //elimina la rivista
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            eliminaRivista.close(); //chiude la connessione
        }
        Stage stage = ((Stage) eliminaButton.getScene().getWindow());
        stage.close(); //chiusura della pagina
    }
}
