package com.biblioteca.controllers.controllersPaginaTesti;

import com.biblioteca.DAO.ArticoloScientificoDAO;
import com.biblioteca.DAO.AutoreDAO;
import com.biblioteca.DAO.ConferenzaDAO;
import com.biblioteca.DAO.RivistaDAO;
import com.biblioteca.ImplementazioneDAO.ArticoloScientificoImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.AutoreImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.ConferenzaImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.RivistaImplementazionePostgresDAO;
import com.biblioteca.bibliotecadigitale.Main;
import com.biblioteca.controllers.controllersModifica.ModificaConferenzaController;
import com.biblioteca.controllers.controllersModifica.ModificaRivistaController;
import com.biblioteca.controllers.controllersPagine.PaginaConferenzaController;
import com.biblioteca.controllers.controllersPagine.PaginaRivistaController;
import com.biblioteca.model.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Controller dedicato alla gestione della pagina degli articoli scientifici.
 */
public class PaginaArticoloController implements Initializable {
    @FXML
    private Label titoloLabel;
    @FXML
    private Label editoreLabel;
    @FXML
    private Label cartaceoLabel;
    @FXML
    private Label digitaleLabel;
    @FXML
    private Label audioLibroLabel;
    @FXML
    private Label annoLabel;
    @FXML
    private Label temaLabel;
    @FXML
    private Label argomentoLabel;
    @FXML
    private TextField modificaEditore;
    @FXML
    private TextField modificaTema;
    @FXML
    private TextField modificaAnno;
    @FXML
    private TextField modificaArgomento;
    @FXML
    private Button modificaArticoloButton;
    @FXML
    private Button confermaModifiche;
    @FXML
    private Button eliminaButton;
    @FXML
    private RadioButton checkDigitale;
    @FXML
    private RadioButton checkAudiolibro;
    @FXML
    private RadioButton checkCartaceo;
    @FXML
    private ListView<String> listaAutori;
    @FXML
    private Hyperlink nomeConferenza;
    @FXML
    private Hyperlink nomeAutore;
    @FXML
    private Hyperlink nomeRivista;
    @FXML
    private Label messaggioLabel;
    @FXML
    private ImageView sfondo;
    /**
     * Articolo che viene mostrato nella pagina.
     */
    private ArticoloScientifico articoloScientifico;

    private Utente utente;

    public ArticoloScientifico getArticoloScientifico() {
        return articoloScientifico;
    }

    public void setArticoloScientifico(ArticoloScientifico articoloScientifico) {
        this.articoloScientifico = articoloScientifico;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        File sfondoFile = new File("src/Images/PaginaArticolo.png");
        Image sfondoImmagine = new Image(sfondoFile.toURI().toString());
        sfondo.setImage(sfondoImmagine);

    }

    /**
     * Imposta le informazioni dell'articolo nella pagina.
     * Utilizza le informazioni già presenti nell'oggetto "articoloScientifico".
     * Per la rivista, la conferenza e gli autori effettua delle ricerche
     * nel database tramite diverse classi DAO.
     *
     * @param articoloScientifico L'oggetto che si riferisce all'articolo
     *                            di cui deve mostrare le informazioni.
     * @param utente              Oggetto contenente i dati dell'utente che ha aperto la pagina.
     *                            In base suo tipo verranno visualizzati o meno determinati
     *                            pulsanti per la modifica delle informazioni nella pagina.
     */
    public void preparaPagina(ArticoloScientifico articoloScientifico, Utente utente) {
        //imposta l'articolo e l'utente
        setArticoloScientifico(articoloScientifico);
        setUtente(utente);
        setInformazioniBase(); //imposta le informazioni nella pagina
        articoloScientifico.setAutori(cercaAutoriArticolo(articoloScientifico.getIdarticolo())); //cerca gli autori dell'articolo
        articoloScientifico.setRivista(cercaRivistaArticolo(articoloScientifico.getIdarticolo())); //cerca la rivista a cui appartiene l'articolo, se esiste
        if (articoloScientifico.getRivista() != null) { // se esiste, imposta l'hyperlink
            nomeRivista.setText(articoloScientifico.getRivista().getNome() + " | n°" + articoloScientifico.getRivista().getNumero());
        } else { //se non esiste, lo indica e disabilita l'hyperlink
            nomeRivista.setText("Nessuna rivista.");
            nomeRivista.setDisable(true);
            nomeRivista.setUnderline(false);
        }
        articoloScientifico.setConferenza(cercaConferenzaArticolo(articoloScientifico.getIdarticolo())); //cerca la conferenza in cui è stato pubblicato l'articolo, se esiste, e la imposta
        if (articoloScientifico.getConferenza() != null) { // se esiste, imposta l'hyperlink
            nomeConferenza.setText(articoloScientifico.getConferenza().getStruttura() + " | " + articoloScientifico.getConferenza().getCitta());
        } else { //se non esiste, lo indica e disabilita l'hyperlink
            nomeConferenza.setText("Nessuna conferenza.");
            nomeConferenza.setDisable(true);
            nomeConferenza.setUnderline(false);
        }
        visualizzaAutoriArticolo(); //visualizza l'autore o gli autori dell'articolo
        //se l'utente che ha aperto la pagina è un amministratore, visualizza il bottone per modificare l'articolo
        if (utente.getTipo().equals("Amministratore")) {
            modificaArticoloButton.setVisible(true);
        }
    }

    /**
     * Imposta nella pagina le informazioni di base sempre presenti in un libro.
     */
    public void setInformazioniBase() {
        titoloLabel.setText(articoloScientifico.getTitolo());
        temaLabel.setText(articoloScientifico.getTema());
        argomentoLabel.setText(articoloScientifico.getArgomento());
        editoreLabel.setText(articoloScientifico.getEditore());
        annoLabel.setText(String.valueOf(articoloScientifico.getAnnopubblicazione()));
        UtilControllerTesti.setFormati(articoloScientifico.getCartaceo(), articoloScientifico.getDigitale(), articoloScientifico.getAudiolibro(), cartaceoLabel, digitaleLabel, audioLibroLabel); //imposta i formati dell'articolo nella pagina
    }

    /**
     * Cerca gli autori dell'articolo della pagina nel database, se esiste crea un oggetto
     * per ognuno e li dà come valore di ritorno tramite un
     * arraylist, altrimenti ritorna un arraylist vuoto.
     *
     * @param idArticolo L'id dell'articolo libro di cui si vogliono cercare gli autori.
     */
    public ArrayList<Autore> cercaAutoriArticolo(int idArticolo) {
        //dichiarazione degli arraylist che conterranno i dati del risultato
        ArrayList<Integer> idAutori = new ArrayList<>();
        ArrayList<String> nominativoAutori = new ArrayList<>();
        ArrayList<LocalDate> dataNascitaAutori = new ArrayList<>();
        ArrayList<String> istitutoAutori = new ArrayList<>();
        AutoreDAO cercaAutori = new AutoreImplementazionePostgresDAO(); //connessione al database
        try {
            cercaAutori.cercaAutorePerArticoloDB(idArticolo, idAutori, nominativoAutori, dataNascitaAutori, istitutoAutori); //ricerca degli autori
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaAutori.close(); //chiusura della connessione al database
        }
        if (idAutori.isEmpty()) { //ritorna un arraylist vuoto se non ci sono risultati
            return new ArrayList<>();
        } else { //altrimenti riempie e ritorna un arraylist di oggetti Autore contenente le informazioni degli autori trovati
            ArrayList<Autore> autoriArticolo = new ArrayList<>();
            for (int i = 0; i < idAutori.size(); i++) {
                Autore autore = new Autore(idAutori.get(i), nominativoAutori.get(i), istitutoAutori.get(i), dataNascitaAutori.get(i));
                autoriArticolo.add(autore);
            }
            return autoriArticolo;
        }
    }

    /**
     * Cerca la rivista di cui fa parte l'articolo.
     *
     * @param idArticolo Id dell'articolo di cui si cerca la rivista.
     * @return La rivista dell'articolo, può essere null.
     */
    public Rivista cercaRivistaArticolo(int idArticolo) {
        //dichiarazione degli arraylist che conterranno i dati del risultato
        ArrayList<String> issnRivista = new ArrayList<>();
        ArrayList<String> titoloRivista = new ArrayList<>();
        ArrayList<Integer> numeroRivista = new ArrayList<>();
        ArrayList<String> temaRivista = new ArrayList<>();
        ArrayList<Integer> annoRivista = new ArrayList<>();
        ArrayList<String> responsabileRivista = new ArrayList<>();
        RivistaDAO cercaRivista = new RivistaImplementazionePostgresDAO(); //connessione al database
        try {
            cercaRivista.cercaRivistaPerArticolo(idArticolo, issnRivista, titoloRivista, numeroRivista, temaRivista, annoRivista, responsabileRivista); //ricerca della rivista
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaRivista.close(); //chiusura della connessione
        }
        //se viene trovata una rivista, viene creato e dato come ritorno il relativo oggetto
        if (!issnRivista.isEmpty()) {
            return new Rivista(issnRivista.get(0), titoloRivista.get(0), temaRivista.get(0), annoRivista.get(0), responsabileRivista.get(0), numeroRivista.get(0));
        } else { //altrimenti ritorna null
            return null;
        }
    }

    /**
     * Cerca la conferenza di cui fa parte l'articolo.
     *
     * @param idArticolo Id dell'articolo di cui si cerca la conferenza.
     * @return La conferenza dell'articolo, può essere null.
     */
    public Conferenza cercaConferenzaArticolo(int idArticolo) {
        //dichiarazione degli arraylist che conterranno i dati del risultato
        ArrayList<Integer> idConferenza = new ArrayList<>();
        ArrayList<String> strutturaConferenza = new ArrayList<>();
        ArrayList<String> cittaConferenza = new ArrayList<>();
        ArrayList<LocalDate> dataInizioConferenza = new ArrayList<>();
        ArrayList<LocalDate> dataFineConferenza = new ArrayList<>();
        ArrayList<String> responsabileConferenza = new ArrayList<>();
        ConferenzaDAO cercaConferenza = new ConferenzaImplementazionePostgresDAO(); //connessione al database
        try {
            cercaConferenza.cercaConferenzaPerArticoloDB(idArticolo, idConferenza, cittaConferenza, strutturaConferenza, dataInizioConferenza, dataFineConferenza, responsabileConferenza); //ricerca della conferenza
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaConferenza.close(); //chiusura della connessione
        }
        //se viene trovata una conferenza, viene creato e dato come ritorno il relativo oggetto
        if (!idConferenza.isEmpty()) {
            return new Conferenza(idConferenza.get(0), cittaConferenza.get(0), strutturaConferenza.get(0), dataInizioConferenza.get(0), dataFineConferenza.get(0), responsabileConferenza.get(0));
        } else { //altrimenti ritorna null
            return null;
        }
    }

    /**
     * Imposta il label per l'autore o autori in base al numero di autori
     * dell'articolo.
     */
    public void visualizzaAutoriArticolo() {
        if (articoloScientifico.getAutori().isEmpty()) {
            nomeAutore.setText("N/A");
            nomeAutore.setUnderline(false);
            nomeAutore.setDisable(true);
        } else if (articoloScientifico.getAutori().size() == 1) {
            nomeAutore.setText(articoloScientifico.getAutori().get(0).getNominativo());
        } else {
            nomeAutore.setText("Visualizza autori.");
        }
    }

    /**
     * Aggiorna le informazioni della pagina dopo aver premuto
     * il tasto F5.
     */
    public void refresh(KeyEvent keyEvent) {
        if (keyEvent.getCode() == KeyCode.F5) {
            listaAutori.setVisible(false);
            preparaPagina(articoloScientifico, utente);
        }
    }

    /**
     * Sul click del tasto "Modifica", visualizza tutti i campi per
     * la modifica delle informazioni della pagina.
     */
    public void modificaArticoloOnAction() {
        //visualizza i campi per la modifica
        modificaArticoloButton.setVisible(false);
        eliminaButton.setVisible(true);
        confermaModifiche.setVisible(true);
        modificaAnno.setVisible(true);
        modificaAnno.setText(String.valueOf(articoloScientifico.getAnnopubblicazione()));
        modificaArgomento.setVisible(true);
        modificaArgomento.setText(articoloScientifico.getArgomento());
        modificaEditore.setVisible(true);
        modificaEditore.setText(articoloScientifico.getEditore());
        modificaTema.setVisible(true);
        modificaTema.setText(articoloScientifico.getTema());
        checkAudiolibro.setVisible(true);
        checkCartaceo.setVisible(true);
        checkDigitale.setVisible(true);
        UtilControllerTesti.checkFormati(articoloScientifico.getCartaceo(), articoloScientifico.getDigitale(), articoloScientifico.getAudiolibro(), checkCartaceo, checkDigitale, checkAudiolibro); //imposta i formati in base al loro valore attuale
        editoreLabel.setText("");
        argomentoLabel.setText("");
        temaLabel.setText("");
        annoLabel.setText("");
        digitaleLabel.setText("");
        cartaceoLabel.setText("");
        audioLibroLabel.setText("");
        //imposta gli hyperlink per l'aggiunta e rimozione di conferenza, articolo e autori
        nomeAutore.setDisable(false);
        nomeAutore.setUnderline(true);
        nomeAutore.setText("Aggiungi/Rimuovi autori.");
        nomeConferenza.setDisable(false);
        nomeConferenza.setUnderline(true);
        if (articoloScientifico.getConferenza() != null) {
            nomeConferenza.setText("Rimuovi conferenza.");
        } else {
            nomeConferenza.setText("Aggiungi conferenza.");
        }
        nomeRivista.setDisable(false);
        nomeRivista.setUnderline(true);
        if (articoloScientifico.getRivista() != null) {
            nomeRivista.setText("Rimuovi rivista.");
        } else {
            nomeRivista.setText("Aggiungi rivista.");
        }
    }

    /**
     * Nasconde tutti i campi per la modifica dell'articolo.
     */
    public void resetModificheOnAction() {
        messaggioLabel.setText("");
        modificaArticoloButton.setVisible(true);
        eliminaButton.setVisible(false);
        confermaModifiche.setVisible(false);
        modificaAnno.setVisible(false);
        modificaArgomento.setVisible(false);
        modificaEditore.setVisible(false);
        modificaTema.setVisible(false);
        checkAudiolibro.setVisible(false);
        checkCartaceo.setVisible(false);
        checkDigitale.setVisible(false);
        //reimposta l'articolo e la conferenza
        if (articoloScientifico.getRivista() != null) { // se esiste, imposta l'articolo e imposta l'hyperlink
            nomeRivista.setText(articoloScientifico.getRivista().getNome() + " | n°" + articoloScientifico.getRivista().getNumero());
        } else { //se non esiste, lo indica e disabilita l'hyperlink
            nomeRivista.setText("Nessuna rivista.");
            nomeRivista.setDisable(true);
            nomeRivista.setUnderline(false);
        }
        if (articoloScientifico.getConferenza() != null) { // se esiste imposta la conferenza e imposta l'hyperlink
            nomeConferenza.setText(articoloScientifico.getConferenza().getStruttura() + " | " + articoloScientifico.getConferenza().getCitta());
        } else { //se non esiste, lo indica e disabilita l'hyperlink
            nomeConferenza.setText("Nessuna conferenza.");
            nomeConferenza.setDisable(true);
            nomeConferenza.setUnderline(false);
        }
        visualizzaAutoriArticolo(); //visualizza l'autore o gli autori dell'articolo
        setInformazioniBase(); //reimposta la pagina
    }

    /**
     * Sul click del tasto "conferma", esegue la modifica dell'articolo nel database, ed esce
     * dalla modalità di modifica.
     */
    public void confermaModificheOnAction() {
        //ottiene il contenuto dei campi
        String nuovoEditore = modificaEditore.getText();
        String nuovoArgomento = modificaArgomento.getText();
        String nuovoTema = modificaTema.getText();
        boolean nuovoCartaceo = UtilControllerTesti.modificaCartaceo(checkCartaceo);
        boolean nuovoDigitale = UtilControllerTesti.modificaDigitale(checkDigitale);
        boolean nuovoAudioLibro = UtilControllerTesti.modificaDigitale(checkAudiolibro);
        //controlla che l'editore inserito sia valido, in caso negativo lo imposta come l'editore già presente
        if (nuovoEditore.isBlank()) {
            nuovoEditore = articoloScientifico.getEditore();
        }
        //controlla che l'argomento inserito sia valido, in caso negativo lo imposta come l'argomento già presente
        if (nuovoArgomento.isBlank()) {
            nuovoArgomento = articoloScientifico.getArgomento();
        }
        //controlla che il tema inserito sia valido, in caso negativo lo imposta come il tema già presente
        if (nuovoTema.isBlank()) {
            nuovoTema = articoloScientifico.getTema();
        }
        //controlla che il nuovo tema coincida con quello dell'articolo, se esiste
        if (articoloScientifico.getRivista() != null && !nuovoTema.equals(articoloScientifico.getRivista().getTema())) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("IL NUOVO TEMA NON COINCIDE CON QUELLO DELLA RIVISTA");
            return;
        }
        int nuovoAnnoPubblicazione;
        //ottiene il nuovo anno di pubblicazione, se non è valido, visualizza un messaggio di errore
        try {
            nuovoAnnoPubblicazione = Integer.parseInt(modificaAnno.getText());
        } catch (NumberFormatException ex) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("INSERIRE UN ANNO VALIDO");
            return;
        }
        //controlla che il nuovo anno di pubblicazione e quello della rivista a cui appartiene, coincidano
        if (articoloScientifico.getRivista() != null && nuovoAnnoPubblicazione != articoloScientifico.getRivista().getAnno()) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("IL NUOVO ANNO DI PUBBLICAZIONE NON COINCIDE CON QUELLO DELLA RIVISTA");
            return;
        }
        //controlla che il nuovo anno di pubblicazione e quello della conferenza a cui appartiene, coincidano
        if (articoloScientifico.getConferenza() != null && nuovoAnnoPubblicazione != articoloScientifico.getConferenza().getDatainizio().getYear()) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("IL NUOVO ANNO DI PUBBLICAZIONE NON COINCIDE CON QUELLO DELLA CONFERENZA");
            return;
        }
        //controlla che almeno uno dei formati sia cartaceo o digitale
        if (!nuovoCartaceo && !nuovoDigitale) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("INSERIRE ALMENO UN FORMATO TRA CARTACEO E DIGITALE");
            return;
        }
        ArticoloScientificoDAO modificaArticolo = new ArticoloScientificoImplementazionePostgresDAO(); //connessione al database
        try {
            //esegue la modifica dell'articolo nel database, in base a se l'articolo fa parte di una rivista, di una conferenza, o di entrambe
            if (articoloScientifico.getRivista() == null) {
                modificaArticolo.modificaArticoloScientificoDB(articoloScientifico.getIdarticolo(), articoloScientifico.getTitolo(), nuovoTema, nuovoArgomento, nuovoAnnoPubblicazione, nuovoEditore, nuovoCartaceo, nuovoDigitale, nuovoAudioLibro, articoloScientifico.getConferenza().getIdconferenza(), null, null);
            } else if (articoloScientifico.getConferenza() == null) {
                modificaArticolo.modificaArticoloScientificoDB(articoloScientifico.getIdarticolo(), articoloScientifico.getTitolo(), nuovoTema, nuovoArgomento, nuovoAnnoPubblicazione, nuovoEditore, nuovoCartaceo, nuovoDigitale, nuovoAudioLibro, null, articoloScientifico.getRivista().getIssn(), articoloScientifico.getRivista().getNumero());
            } else {
                modificaArticolo.modificaArticoloScientificoDB(articoloScientifico.getIdarticolo(), articoloScientifico.getTitolo(), nuovoTema, nuovoArgomento, nuovoAnnoPubblicazione, nuovoEditore, nuovoCartaceo, nuovoDigitale, nuovoAudioLibro, articoloScientifico.getConferenza().getIdconferenza(), articoloScientifico.getRivista().getIssn(), articoloScientifico.getRivista().getNumero());
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            modificaArticolo.close(); //chiusura della connessione
        }
        //imposta i nuovi valori all'articolo
        articoloScientifico.setTema(nuovoTema);
        articoloScientifico.setArgomento(nuovoArgomento);
        articoloScientifico.setEditore(nuovoEditore);
        articoloScientifico.setAnnopubblicazione(nuovoAnnoPubblicazione);
        articoloScientifico.setCartaceo(nuovoCartaceo);
        articoloScientifico.setDigitale(nuovoDigitale);
        articoloScientifico.setAudiolibro(nuovoAudioLibro);
        resetModificheOnAction();
    }

    /**
     * Sul click del tasto "elimina", elimina l'articolo dal database.
     */
    public void eliminaOnAction() {
        ArticoloScientificoDAO eliminaArticolo = new ArticoloScientificoImplementazionePostgresDAO(); //connessione al database
        try {
            eliminaArticolo.eliminaArticoloScientificoDB(articoloScientifico.getIdarticolo()); //elimina l'articolo
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            eliminaArticolo.close(); //chiude la connessione
        }
        Stage stage = ((Stage) eliminaButton.getScene().getWindow());
        stage.close(); //chiusura della pagina
    }

    /**
     * Sul click dell'hyperlink della conferenza, apre la relativa pagina.
     */
    public void visualizzaConferenza() throws IOException {
        if (nomeConferenza.getText().equals("Aggiungi conferenza.")) { //apre la pagina per l'aggiunta di una conferenza all'articolo
            Stage stage = new Stage();
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("ModificaConferenza.fxml"));
            Parent root = fxmlLoader.load();
            ModificaConferenzaController paginaConferenza = fxmlLoader.getController();
            paginaConferenza.preparaPagina(articoloScientifico);
            Scene scene = new Scene(root, 350, 400);
            stage.setTitle("Aggiungi una conferenza");
            stage.setScene(scene);
            stage.show();
            stage.setResizable(false);
        } else if (nomeConferenza.getText().equals("Rimuovi conferenza.")) { //rimuove la conferenza dalla rivista
            rimuoviArticoloDaConferenza();
        } else {
            visualizzaPaginaConferenza(); //apre la pagina della conferenza
        }
    }

    /**
     * Rimuove dal database l'articolo dalla sua conferenza.
     */
    public void rimuoviArticoloDaConferenza() {
        //controlla che l'articolo abbia una rivista, in caso negativo manda un messaggio di errore
        if (articoloScientifico.getRivista() == null) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("L'ARTICOLO DEVE ESSERE PRESENTE IN UNA RIVISTA E/O IN UNA CONFERENZA");
            return;
        }
        ArticoloScientificoDAO rimuoviConferenzaArticolo = new ArticoloScientificoImplementazionePostgresDAO(); //connessione al database
        try {
            //rimozione della conferenza dalla rivista
            if (articoloScientifico.getRivista() == null) {
                rimuoviConferenzaArticolo.modificaArticoloScientificoDB(articoloScientifico.getIdarticolo(), articoloScientifico.getTitolo(), articoloScientifico.getTema(), articoloScientifico.getArgomento(), articoloScientifico.getAnnopubblicazione(), articoloScientifico.getEditore(), articoloScientifico.getCartaceo(), articoloScientifico.getDigitale(), articoloScientifico.getAudiolibro(), null, null, null);

            } else {
                rimuoviConferenzaArticolo.modificaArticoloScientificoDB(articoloScientifico.getIdarticolo(), articoloScientifico.getTitolo(), articoloScientifico.getTema(), articoloScientifico.getArgomento(), articoloScientifico.getAnnopubblicazione(), articoloScientifico.getEditore(), articoloScientifico.getCartaceo(), articoloScientifico.getDigitale(), articoloScientifico.getAudiolibro(), null, articoloScientifico.getRivista().getIssn(), articoloScientifico.getRivista().getNumero());
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            rimuoviConferenzaArticolo.close(); //chiusura della connessione
        }
        articoloScientifico.setConferenza(null); //rimozione della conferenza dall'articolo
    }

    /**
     * Sul click dell'hyperlink del nome di una conferenza, apre la relativa pagina.
     */
    public void visualizzaPaginaConferenza() throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaConferenza.fxml"));
        Parent root = fxmlLoader.load();
        PaginaConferenzaController paginaConferenza = fxmlLoader.getController();
        paginaConferenza.preparaPagina(articoloScientifico.getConferenza(), utente);
        Scene scene = new Scene(root, 500, 630);
        stage.setTitle(articoloScientifico.getConferenza().getStruttura() + ", " + articoloScientifico.getConferenza().getCitta());
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    /**
     * Sul click dell'hyperlink degli autori, se ci sono più autori per l'articolo, apre
     * la loro lista, altrimenti apre la pagina dell'unico autore.
     */
    public void visualizzaAutori() throws IOException {
        if (nomeAutore.getText().equals("Visualizza autori.")) { //se ci sono più autori da visualizzare, apre la loro lista
            listaAutori.getItems().clear();  //pulisce la lista
            for (Autore autore : articoloScientifico.getAutori()) { //aggiunge gli autori alla lista
                listaAutori.getItems().add(autore.getNominativo());
                listaAutori.setVisible(true); //rende visibile la lista
            }
        } else if (nomeAutore.getText().equals("Aggiungi/Rimuovi autori.")) { //se si è in modalità modifica, apre la pagina per gestire gli autori dell'articolo
            UtilControllerTesti.visualizzaGestioneAutore(articoloScientifico);
        } else { //se esiste un solo autore
            UtilControllerTesti.visualizzaAutore(articoloScientifico.getAutori().get(0), utente); //apre la pagina dell'unico autore
        }
    }

    /**
     * Sul click di uno degli autori nella lista degli autori, apre la sua pagina.
     */
    public void mostraAutoreSelezionato() throws IOException {
        if (!listaAutori.getSelectionModel().isEmpty()) { //controlla che sia stato selezionato un elemento valido
            int indiceAutoreSelezionato = listaAutori.getSelectionModel().getSelectedIndex(); //ottiene l'indice dell'autore selezionato
            UtilControllerTesti.visualizzaAutore(articoloScientifico.getAutori().get(indiceAutoreSelezionato), utente); //apre la pagina dell'autore selezionato
        }
    }

    /**
     * Sul click dell'hyperlink della rivista, in base al testo contenuto,
     * apre la pagina della rivista, la rimuove dall'articolo o apre la pagina
     * per l'aggiunta di una rivista.
     */
    public void visualizzaRivista() throws IOException {
        if (nomeRivista.getText().equals("Aggiungi rivista.")) { //apre la pagina per l'aggiunta di una rivista all'articolo
            Stage stage = new Stage();
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("ModificaRivista.fxml"));
            Parent root = fxmlLoader.load();
            ModificaRivistaController paginaRivista = fxmlLoader.getController();
            paginaRivista.preparaPagina(articoloScientifico);
            Scene scene = new Scene(root, 350, 400);
            stage.setTitle("Aggiungi una rivista");
            stage.setScene(scene);
            stage.show();
            stage.setResizable(false);
        } else if (nomeRivista.getText().equals("Rimuovi rivista.")) { //rimuove l'articolo dalla rivista
            rimuoviArticoloDaRivista();
        } else {
            visualizzaPaginaRivista(); //apre la pagina della rivista
        }
    }

    /**
     * Rimuove dal database l'articolo dalla sua rivista.
     */
    public void rimuoviArticoloDaRivista() {
        //controlla che l'articolo abbia una conferenza, in caso negativo manda un messaggio di errore
        if (articoloScientifico.getConferenza() == null) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("L'ARTICOLO DEVE ESSERE PRESENTE IN UNA RIVISTA E/O IN UNA CONFERENZA");
            return;
        }
        ArticoloScientificoDAO rimuoviRivistaArticolo = new ArticoloScientificoImplementazionePostgresDAO(); //connessione al database
        try {
            //rimozione dell'articolo dalla rivista
            if (articoloScientifico.getConferenza() == null) {
                rimuoviRivistaArticolo.modificaArticoloScientificoDB(articoloScientifico.getIdarticolo(), articoloScientifico.getTitolo(), articoloScientifico.getTema(), articoloScientifico.getArgomento(), articoloScientifico.getAnnopubblicazione(), articoloScientifico.getEditore(), articoloScientifico.getCartaceo(), articoloScientifico.getDigitale(), articoloScientifico.getAudiolibro(), null, null, null);

            } else {
                rimuoviRivistaArticolo.modificaArticoloScientificoDB(articoloScientifico.getIdarticolo(), articoloScientifico.getTitolo(), articoloScientifico.getTema(), articoloScientifico.getArgomento(), articoloScientifico.getAnnopubblicazione(), articoloScientifico.getEditore(), articoloScientifico.getCartaceo(), articoloScientifico.getDigitale(), articoloScientifico.getAudiolibro(), articoloScientifico.getConferenza().getIdconferenza(), articoloScientifico.getRivista().getIssn(), articoloScientifico.getRivista().getNumero());
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            rimuoviRivistaArticolo.close(); //chiusura della connessione
        }
        articoloScientifico.setRivista(null); //rimozione della rivista dall'articolo
    }

    /**
     * Sul click dell'hyperlink del nome di una rivista, apre la relativa pagina.
     */
    public void visualizzaPaginaRivista() throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaRivista.fxml"));
        Parent root = fxmlLoader.load();
        PaginaRivistaController paginaRivista = fxmlLoader.getController();
        paginaRivista.preparaPagina(articoloScientifico.getRivista(), utente);
        Scene scene = new Scene(root, 500, 630);
        stage.setTitle(articoloScientifico.getRivista().getNome() + " | n°" + articoloScientifico.getRivista().getNumero());
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }
}
