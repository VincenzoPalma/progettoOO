package com.biblioteca.controllers.controllersModifica;

import com.biblioteca.DAO.RomanzoDAO;
import com.biblioteca.ImplementazioneDAO.RomanzoImplementazionePostgresDAO;
import com.biblioteca.model.Romanzo;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Controller dedicato alla gestione della pagina per l'aggiunta e la rimozione del seguito dal libro.
 */
public class ModificaSeguitoController {
    @FXML
    private ListView<String> listaSeguitiDisponibili;
    private Romanzo romanzo;
    private ArrayList<Romanzo> seguitiDisponibili = new ArrayList<>();

    public Romanzo getRomanzo() {
        return romanzo;
    }

    public void setRomanzo(Romanzo romanzo) {
        this.romanzo = romanzo;
    }

    public ArrayList<Romanzo> getSeguitiDisponibili() {
        return seguitiDisponibili;
    }

    public void setSeguitiDisponibili(ArrayList<Romanzo> seguitiDisponibili) {
        this.seguitiDisponibili = seguitiDisponibili;
    }

    /**
     * Visualizza tutte i seguiti che possono essere attribuiti al libro.
     */
    public void aggiungiSeguito() {
        int indiceSeguitoSelezionato = listaSeguitiDisponibili.getSelectionModel().getSelectedIndex(); //prende l'indice del seguito selezionato nella lista
        Romanzo nuovoSeguito = seguitiDisponibili.get(indiceSeguitoSelezionato); //ottiene il seguito da inserire
        RomanzoDAO aggiungiSeguito = new RomanzoImplementazionePostgresDAO(); //connessione al database
        try {
            //attribuzione del seguito al libro nel database
            aggiungiSeguito.modificaRomanzoDB(romanzo.getIsbn(), romanzo.getEditore(), romanzo.getGenere(), LocalDate.of(romanzo.getAnnopubblicazione(), romanzo.getMesepubblicazione(), romanzo.getGiornopubblicazione()), romanzo.getIsbn(), romanzo.getCartaceo(), romanzo.getDigitale(), romanzo.getAudiolibro(), nuovoSeguito.getIsbn());
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            aggiungiSeguito.close(); //chiusura della connessione
        }
        romanzo.setSeguito(nuovoSeguito); //impostazione del seguito al libro
        Stage stage = ((Stage) listaSeguitiDisponibili.getScene().getWindow());
        stage.close(); //chiusura della pagina
    }

    /**
     * Visualizza in una lista, tutti i libri che possono essere seguito del romanzo.
     *
     * @param romanzo Romanzo a cui si vuole attribuire un seguito.
     */
    public void preparaPagina(Romanzo romanzo) {
        //imposta il romanzo
        setRomanzo(romanzo);
        //dichiarazione degli arraylist che conterranno i dati dei risultati
        ArrayList<String> isbn = new ArrayList<>();
        ArrayList<String> titoli = new ArrayList<>();
        ArrayList<String> generi = new ArrayList<>();
        ArrayList<LocalDate> dateUscita = new ArrayList<>();
        ArrayList<String> tipi = new ArrayList<>();
        ArrayList<String> editori = new ArrayList<>();
        ArrayList<Boolean> cartaceo = new ArrayList<>();
        ArrayList<Boolean> digitale = new ArrayList<>();
        ArrayList<Boolean> audiolibro = new ArrayList<>();
        ArrayList<String> isbnSeguiti = new ArrayList<>();
        RomanzoDAO cercaRomanziSerie = new RomanzoImplementazionePostgresDAO(); //connessione al database
        try {
            cercaRomanziSerie.cercaRomanziPerSerieSenzaSeguito(romanzo.getSerie().getIdserie(), isbn, titoli, generi, dateUscita, tipi, editori, cartaceo, digitale, audiolibro, isbnSeguiti); //ricerca di tutti i romanzi della stessa serie del libro che sono disponibili a essere seguiti
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaRomanziSerie.close(); //chiusura della connessione
        }
        //per ogni romanzo trovato, crea un oggetto
        for (int i = 0; i < isbn.size(); i++) {
            Romanzo romanzoTrovato = new Romanzo(titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), dateUscita.get(i).getYear(), isbn.get(i), dateUscita.get(i).getDayOfMonth(), dateUscita.get(i).getMonthValue(), generi.get(i), null, romanzo.getSerie());
            seguitiDisponibili.add(romanzoTrovato);
        }
        seguitiDisponibili.remove(romanzo); //rimuove il romanzo stesso a cui si vuole attribuire il seguito, nel caso rientri tra i risultati
        //per ogni romanzo trovato, lo visualizza nella lista di possibili seguiti
        for (Romanzo romanzoSelezionato : seguitiDisponibili) {
            listaSeguitiDisponibili.getItems().add(romanzoSelezionato.getTitolo() + " | " + LocalDate.of(romanzoSelezionato.getAnnopubblicazione(), romanzoSelezionato.getMesepubblicazione(), romanzoSelezionato.getGiornopubblicazione()));
        }
    }
}
