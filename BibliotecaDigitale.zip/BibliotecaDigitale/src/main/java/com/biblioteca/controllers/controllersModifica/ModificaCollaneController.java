package com.biblioteca.controllers.controllersModifica;

import com.biblioteca.DAO.CollanaDAO;
import com.biblioteca.DAO.LibroDAO;
import com.biblioteca.DAO.PartecipazioneDAO;
import com.biblioteca.ImplementazioneDAO.CollanaImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.LibroImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.PartecipazioneImplementazionePostgresDAO;
import com.biblioteca.model.*;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Controller dedicato alla gestione della pagina per l'aggiunta e la rimozione di collane dal libro.
 */
public class ModificaCollaneController {
    @FXML
    private Pane finestraEliminaCollana;
    @FXML
    private ListView<String> listaCollaneInserite;
    @FXML
    private ListView<String> listaCollaneDisponibili;
    @FXML
    private DatePicker dataDiAggiunta;
    @FXML
    private Label messaggioLabel;
    private ArrayList<Collana> collaneDisponibili = new ArrayList<>();
    private Libro libro;

    public ArrayList<Collana> getCollaneDisponibili() {
        return collaneDisponibili;
    }

    public void setCollaneDisponibili(ArrayList<Collana> collaneDisponibili) {
        this.collaneDisponibili = collaneDisponibili;
    }

    public Libro getLibro() {
        return libro;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }

    /**
     * Mostra tutte le collane dello stesso autore del libro disponibili per essere aggiunte a esso, e tutte le collane attribuite al libro che possono essere rimosse
     *
     * @param libro Il libro di cui si gestiscono le collane.
     */
    public void preparaPagina(Libro libro) {
        //imposta il libro
        setLibro(libro);
        //visualizza le collane già associate al libro
        for (Partecipazione partecipazione : libro.getPartecipazioni()) {
            listaCollaneInserite.getItems().add(partecipazione.getCollana().getNome() + " | " + partecipazione.getCollana().getCaratteristica());
            cercaPartecipazioniCollanaAggiunta(partecipazione.getCollana()); //per ogni collana a cui il libro partecipa, trova le partecipazioni della collana
        }
        //dichiarazione degli arraylist che conterranno i dati del risultato della ricerca delle collane
        ArrayList<String> issnCollane = new ArrayList<>();
        ArrayList<String> nomeCollane = new ArrayList<>();
        ArrayList<String> caratteristicaCollane = new ArrayList<>();
        ArrayList<String> descrizioneCollane = new ArrayList<>();
        ArrayList<LocalDate> dataPubblicazioneCollane = new ArrayList<>();
        ArrayList<String> direttoreCollane = new ArrayList<>();
        ArrayList<String> editoreCollane = new ArrayList<>();
        ArrayList<Collana> collaneTrovate = new ArrayList<>();
        CollanaDAO cercaCollaneDisponibili = new CollanaImplementazionePostgresDAO(); //connessione al database
        try {
            cercaCollaneDisponibili.getAllCollane(issnCollane, nomeCollane, caratteristicaCollane, descrizioneCollane, dataPubblicazioneCollane, direttoreCollane, editoreCollane); //cerca tutte le collane
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaCollaneDisponibili.close(); //chiusura della connessione
        }
        //per ogni collana trovata, crea il relativo oggetto
        for (int i = 0; i < issnCollane.size(); i++) {
            Collana collana = new Collana(issnCollane.get(i), nomeCollane.get(i), caratteristicaCollane.get(i), descrizioneCollane.get(i), dataPubblicazioneCollane.get(i), direttoreCollane.get(i), editoreCollane.get(i));
            cercaPartecipazioniCollanaAggiunta(collana); //carica le partecipazioni della collana
            collaneTrovate.add(collana);
        }
        //scarta le collane che non hanno lo stesso editore del libro di cui si gestiscono le collane e quelle che già lo contengono
        for (Collana collana : collaneTrovate) {
            boolean contenuto = false;
            for (Partecipazione partecipazione : libro.getPartecipazioni()) { //controlla che il libro non sia già contenuto in quella collana
                if (partecipazione.getCollana().equals(collana)) {
                    contenuto = true;
                    break;
                }
            }
            if (collana.getEditore().equals(libro.getEditore()) && !contenuto) { //controlla che l'editore della collana e del libro siano uguali
                collaneDisponibili.add(collana); //aggiunta della collana alle collane disponibili
                listaCollaneDisponibili.getItems().add(collana.getNome() + " | " + collana.getCaratteristica());
            }
        }
    }

    /**
     * Sul click di una delle collane associate al libro, lo rimuove da essa, e lo sposta nella lista
     * delle collane disponibili.
     */
    public void rimuoviPartecipazione() {
        if (!listaCollaneInserite.getSelectionModel().isEmpty()) { //se viene selezionato un elemento valido
            int indiceCollanaSelezionata = listaCollaneInserite.getSelectionModel().getSelectedIndex(); //ottiene l'indice della collana selezionata
            Collana collanaRimossa = libro.getPartecipazioni().get(indiceCollanaSelezionata).getCollana(); //ottiene la collana da rimuovere
            if (collanaRimossa.getPartecipazioni().size() == 1) { //se la collana ha un solo libro in essa, apre una schermata per la conferma della rimozione (una collana vuota viene eliminata)
                finestraEliminaCollana.setVisible(true); //apertura della finestra di conferma
            } else { //se la collana ha più di un libro in essa, procede alla rimozione
                rimuoviCollana();
                //aggiunta della collana nella lista delle collane disponibili
                collaneDisponibili.add(collanaRimossa);
                listaCollaneDisponibili.getItems().add(collanaRimossa.getNome() + " | " + collanaRimossa.getCaratteristica());
            }
        }
    }

    /**
     * Effettua la rimozione della collana da un libro.
     */
    public void rimuoviCollana() {
        int indiceCollanaSelezionata = listaCollaneInserite.getSelectionModel().getSelectedIndex();
        Collana collanaRimossa = libro.getPartecipazioni().get(indiceCollanaSelezionata).getCollana(); //ottiene la collana da rimuovere
        PartecipazioneDAO rimuoviCollana = new PartecipazioneImplementazionePostgresDAO(); //connessione al database
        try {
            rimuoviCollana.eliminaPartecipazioneDB(libro.getIsbn(), collanaRimossa.getIssn()); //rimuove il libro dalla collana nel database
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            rimuoviCollana.close(); //chiusura della connessione
        }
        listaCollaneInserite.getItems().remove(indiceCollanaSelezionata); //rimuove la collana dalla lista delle collane associate
        libro.getPartecipazioni().remove(indiceCollanaSelezionata); //rimuove la partecipazione dal libro
        collanaRimossa.getPartecipazioni().removeIf(partecipazione -> partecipazione.getLibro().equals(libro));
    }

    /**
     * Sul click di una delle collane disponibili, la aggiunge al testo, e la sposta nella lista
     * delle collane associate.
     */
    public void aggiungiCollana() {
        if (!listaCollaneDisponibili.getSelectionModel().isEmpty()) { //se viene selezionato un elemento valido
            int indiceCollanaSelezionata = listaCollaneDisponibili.getSelectionModel().getSelectedIndex(); //ottenimento dell'indice della collana selezionata nella lista
            Collana collanaAggiunta = collaneDisponibili.get(indiceCollanaSelezionata); //ottiene la collana da inserire
            LocalDate dataPartecipazione = dataDiAggiunta.getValue(); //prende il valore della data di partecipazione inserita
            //se non è stata inserita una data, o la data viene prima della pubblicazione della collana, visualizza un messaggio di errore
            if (dataPartecipazione == null || dataPartecipazione.isBefore(collanaAggiunta.getDatapubblicazione())) {
                messaggioLabel.setTextFill(Color.web("#FF2E2E"));
                messaggioLabel.setText("INSERIRE UNA DATA VALIDA");
                return;
            }
            Partecipazione partecipazioneAggiunta = new Partecipazione(dataPartecipazione, libro, collanaAggiunta); //creazione dell'oggetto della partecipazione
            PartecipazioneDAO aggiungiCollana = new PartecipazioneImplementazionePostgresDAO(); //connessione al database
            try {
                aggiungiCollana.aggiungiPartecipazoneDB(partecipazioneAggiunta); //inserimento della partecipazione nel database
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                aggiungiCollana.close(); //chiusura della connessione
            }
            collaneDisponibili.remove(collanaAggiunta); //rimozione della collana dalle collane disponibili
            listaCollaneDisponibili.getItems().remove(indiceCollanaSelezionata); //rimozione della collana dalla lista delle collane disponibili
            listaCollaneInserite.getItems().add(partecipazioneAggiunta.getCollana().getNome() + " | " + partecipazioneAggiunta.getCollana().getCaratteristica());  //aggiunta della collana dalla lista delle collane associate
            libro.getPartecipazioni().add(partecipazioneAggiunta); //aggiunta della partecipazione al libro
            collanaAggiunta.getPartecipazioni().add(partecipazioneAggiunta); //aggiunta della partecipazione alla collana
            //cercaPartecipazioniCollanaAggiunta(collanaAggiunta); //aggiorna le partecipazioni
            messaggioLabel.setText(""); //reset del messaggio di errore
            dataDiAggiunta.setValue(null); //reset della data
        }
    }

    /**
     * Cerca le partecipazioni per la collana passata come parametro.
     *
     * @param collanaAggiunta Collana di cui si cercano le partecipazioni.
     */
    public void cercaPartecipazioniCollanaAggiunta(Collana collanaAggiunta) {
        //dichiarazione degli arraylist che conterranno i risultati
        ArrayList<String> isbnLibri = new ArrayList<>();
        ArrayList<LocalDate> datePartecipazioni = new ArrayList<>();
        ArrayList<Partecipazione> partecipazioniTrovate = new ArrayList<>();
        PartecipazioneDAO cercaPartecipazioniCollana = new PartecipazioneImplementazionePostgresDAO(); //connessione al database
        try {
            cercaPartecipazioniCollana.cercaPartecipazionePerIssnCollana(collanaAggiunta.getIssn(), isbnLibri, datePartecipazioni); //cerca partecipazione nel database
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaPartecipazioniCollana.close(); //chiusura della connessione
        }
        LibroDAO cercaLibri = new LibroImplementazionePostgresDAO(); //connessione al database
        ArrayList<Libro> libriCollana = new ArrayList<>(); //arraylist dei libri della collana
        //dichiarazione degli arraylist che conterranno le informazioni dei risultati della ricerca
        ArrayList<String> isbn = new ArrayList<>();
        ArrayList<String> titoli = new ArrayList<>();
        ArrayList<String> generi = new ArrayList<>();
        ArrayList<LocalDate> dateUscita = new ArrayList<>();
        ArrayList<String> tipoLibri = new ArrayList<>();
        ArrayList<String> editori = new ArrayList<>();
        ArrayList<Boolean> cartaceo = new ArrayList<>();
        ArrayList<Boolean> digitale = new ArrayList<>();
        ArrayList<Boolean> audiolibro = new ArrayList<>();
        try {
            cercaLibri.cercaLibroPerCollana(collanaAggiunta.getIssn(), isbn, titoli, generi, dateUscita, tipoLibri, editori, cartaceo, digitale, audiolibro);//ricerca dei libri della collana
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        //per ogni libro trovato, viene creato un oggetto in base al tipo di libro e viene inserito nell'arraylist
        for (int i = 0; i < isbn.size(); i++) {
            if (tipoLibri.get(i).equals("Romanzo")) {
                Romanzo romanzo = new Romanzo(titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), dateUscita.get(i).getYear(), isbn.get(i), dateUscita.get(i).getDayOfMonth(), dateUscita.get(i).getMonthValue(), generi.get(i), null, null);
                libriCollana.add(romanzo);
            } else {
                LibroDidattico libroDidattico = new LibroDidattico(titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), dateUscita.get(i).getYear(), isbn.get(i), dateUscita.get(i).getDayOfMonth(), dateUscita.get(i).getMonthValue(), generi.get(i));
                libriCollana.add(libroDidattico);
            }
        }
        //per ogni partecipazione trovata, crea un oggetto e lo aggiunge all'arraylist
        for (int i = 0; i < isbnLibri.size(); i++) {
            Partecipazione partecipazione = new Partecipazione(datePartecipazioni.get(i), libriCollana.get(i), collanaAggiunta);
            partecipazioniTrovate.add(partecipazione);
        }
        collanaAggiunta.setPartecipazioni(partecipazioniTrovate);
    }

    /**
     * Sul click del tasto "annulla", nella conferma dell'eliminazione della collana, annulla l'eliminazione e chiude la pagina.
     */
    public void annullaOnAction() {
        finestraEliminaCollana.setVisible(false);
    }

    /**
     * Sul click del tasto "conferma", nella conferma dell'eliminazione della collana, elimina la collana e chiude la pagina.
     */
    public void confermaOnAction() {
        rimuoviCollana(); //eliminazione della collana
        finestraEliminaCollana.setVisible(false);
    }
}
