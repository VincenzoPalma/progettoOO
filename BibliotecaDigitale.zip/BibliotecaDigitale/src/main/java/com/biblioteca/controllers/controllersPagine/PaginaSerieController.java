package com.biblioteca.controllers.controllersPagine;


import com.biblioteca.DAO.NotificaDAO;
import com.biblioteca.DAO.RomanzoDAO;
import com.biblioteca.DAO.SerieDAO;
import com.biblioteca.DAO.UtenteDAO;
import com.biblioteca.ImplementazioneDAO.NotificaImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.RomanzoImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.SerieImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.UtenteImplementazionePostgresDAO;
import com.biblioteca.bibliotecadigitale.Main;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaDidatticoController;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaRomanzoController;
import com.biblioteca.model.Notifica;
import com.biblioteca.model.Romanzo;
import com.biblioteca.model.Serie;
import com.biblioteca.model.Utente;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Controller dedicato alla gestione della pagina per le serie.
 */
public class PaginaSerieController implements Initializable {
    @FXML
    private Label nomeSerieLabel;
    @FXML
    private ListView<String> listaLibriSerie;
    @FXML
    private CheckBox preferiti;
    @FXML
    private Button modificaSerieButton;
    @FXML
    private Button confermaModifiche;
    @FXML
    private Button annullaModifiche;
    @FXML
    private TextField modificaNomeSerie;
    @FXML
    private Label messaggioLabel;
    @FXML
    private Button eliminaButton;
    @FXML
    private ImageView sfondo;

    /**
     * Serie di cui si vogliono mostrare le informazioni.
     */
    private Serie serie;

    /**
     * Utente che ha aperto la pagina, utilizzato per
     * decidere se l'utente in questione può o meno modificare i
     * dati della pagina e per gestire la preferenza alla serie.
     */
    private Utente utente;

    public Serie getSerie() {
        return serie;
    }

    public void setSerie(Serie serie) {
        this.serie = serie;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        File sfondoFile = new File("src/Images/paginaSerie.png");
        Image sfondoImmagine = new Image(sfondoFile.toURI().toString());
        sfondo.setImage(sfondoImmagine);

    }


    /**
     * Sul click per la spunta per la preferenza, aggiunge o rimuove la preferenza all'utente.
     */
    public void preferitiOnAction() {
        UtenteDAO modificaPreferenza = new UtenteImplementazionePostgresDAO(); //connessione al database
        if (preferiti.isSelected()) { //se è stata messa la spunta
            try {
                if (modificaPreferenza.aggiungiPreferenzaSerieDB(utente.getUsername(), serie.getIdserie())) { //se esiste una notifica per la serie appena aggiunta come preferita, la carica
                    //dichiarazione degli arraylist che conterranno i dati della notifica
                    ArrayList<LocalDate> dataNotifica = new ArrayList<>();
                    ArrayList<LocalTime> orarioNotifica = new ArrayList<>();
                    NotificaDAO cercaNotifica = new NotificaImplementazionePostgresDAO();
                    cercaNotifica.cercaNotificaPreferenzaUtente(utente.getUsername(), serie.getIdserie(), dataNotifica, orarioNotifica); //ricerca della notifica
                    utente.getNotifiche().add(new Notifica(utente, serie, dataNotifica.get(0), orarioNotifica.get(0))); //inserimento nella notifica tra quelle dell'utente
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                modificaPreferenza.close(); //chiusura della connessione
            }
            utente.getSerie().add(serie); //aggiunta della serie alle preferenze dell'utente
        } else { //se è stata rimossa la spunta
            try {
                modificaPreferenza.eliminaPreferenzaSerieDB(utente.getUsername(), serie.getIdserie());
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                modificaPreferenza.close(); //chiusura della connessione
            }
            utente.getSerie().remove(serie); //rimozione della serie dall'arraylist di preferenze dell'utente
            utente.getNotifiche().removeIf(notifica -> notifica.getSerie().equals(serie)); //rimozione delle notifiche della serie dall'arraylist di notifiche dell'utente
        }
    }

    /**
     * Imposta le informazioni della serie nella pagina.
     *
     * @param serie  La serie di cui si vogliono mostrare le informazioni.
     * @param utente L'utente che ha aperto la pagina.
     */
    public void preparaPagina(Serie serie, Utente utente) {
        //imposta l'utente e la serie
        setUtente(utente);
        setSerie(serie);
        //se l'utente è un amministratore, rende visibile il pulsante di modifica
        if (utente.getTipo().equals("Amministratore")) {
            modificaSerieButton.setVisible(true);
            modificaSerieButton.setDisable(false);
        }
        nomeSerieLabel.setText(serie.getTitolo()); //imposta il titolo della pagina
        //se l'utente ha una preferenza per la serie della pagina, visualizza la spunta già selezionata
        if (utente.getSerie().contains(serie)) {
            preferiti.setSelected(true);
        }
        ArrayList<Romanzo> romanziSerie = new ArrayList<>(); //arraylist dei libri del negozio
        //dichiarazione degli arraylist che conterranno le informazioni dei risultati della ricerca
        ArrayList<String> isbn = new ArrayList<>();
        ArrayList<String> titoli = new ArrayList<>();
        ArrayList<String> generi = new ArrayList<>();
        ArrayList<LocalDate> dateUscita = new ArrayList<>();
        ArrayList<String> tipoLibri = new ArrayList<>();
        ArrayList<String> editori = new ArrayList<>();
        ArrayList<Boolean> cartaceo = new ArrayList<>();
        ArrayList<Boolean> digitale = new ArrayList<>();
        ArrayList<Boolean> audiolibro = new ArrayList<>();
        RomanzoDAO cercaLibri = new RomanzoImplementazionePostgresDAO(); //connessione al database
        try {
            cercaLibri.cercaRomanzoPerSerie(serie.getIdserie(), isbn, titoli, generi, dateUscita, tipoLibri, editori, cartaceo, digitale, audiolibro); //ricerca dei romanzi della serie
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaLibri.close(); //chiusura della connessione
        }
        //per ogni libro trovato, viene creato un oggetto in base al tipo di libro e viene inserito nell'arraylist
        for (int i = 0; i < isbn.size(); i++) {
            Romanzo romanzo = new Romanzo(titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), dateUscita.get(i).getYear(), isbn.get(i), dateUscita.get(i).getDayOfMonth(), dateUscita.get(i).getMonthValue(), generi.get(i), null, null);
            romanziSerie.add(romanzo);
        }
        serie.setLibri(romanziSerie); //imposta i romanzi della serie
        //visualizza i libri appartenenti alla serie
        for (Romanzo libro : serie.getLibri()) {
            listaLibriSerie.getItems().add(libro.getTitolo() + " | " + libro.getGenere() + " | " + libro.getEditore());
        }
    }

    /**
     * Sul click del tasto "Conferma", modifica il negozio nel database.
     */
    public void confermaModificheOnAction() {
        //ottiene il contenuto dei campi
        String nuovoTitolo = modificaNomeSerie.getText();
        //controlla che il nuovo titolo sia valido
        if (nuovoTitolo.isBlank()) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("INSERIRE UN TITOLO VALIDO");
            return;
        }
        SerieDAO modificaSerie = new SerieImplementazionePostgresDAO(); //connessione al database
        try {
            modificaSerie.modificaSerieDB(serie.getIdserie(), nuovoTitolo); //modifica della serie nel db
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            modificaSerie.close(); //chiusura della connessione
        }
        serie.setTitolo(nuovoTitolo); //imposta il nuovo titolo
        resetModificheOnAction(); //reimposta i dati nella pagina
    }

    /**
     * Sul click del tasto "Annulla", nasconde i campi relativi alla modifica.
     */
    public void resetModificheOnAction() {
        modificaSerieButton.setVisible(true);
        confermaModifiche.setVisible(false);
        annullaModifiche.setVisible(false);
        modificaNomeSerie.setVisible(false);
        nomeSerieLabel.setText(serie.getTitolo());
        eliminaButton.setVisible(false);
        messaggioLabel.setText("");
    }

    /**
     * Sul click del tasto "Modifica", visualizza i campi per modificare le informazioni.
     */
    public void modificaSerieOnAction() {
        modificaSerieButton.setVisible(false);
        confermaModifiche.setVisible(true);
        annullaModifiche.setVisible(true);
        modificaNomeSerie.setVisible(true);
        modificaNomeSerie.setText(serie.getTitolo());
        nomeSerieLabel.setText("");
        eliminaButton.setVisible(true);
    }

    /**
     * Sul click di un libro, chiama una nuova finestra che
     * conterrà le informazioni di quel libro, le informazioni mostrate dalla finestra
     * dipenderanno dal tipo di libro.
     * <p>
     * Passa l'oggetto del libro selezionato e il tipo di utente al controller della schermata che chiama.
     *
     * @see PaginaRomanzoController
     * @see PaginaDidatticoController
     */
    public void mostraLibroSelezionato() throws IOException {
        try {
            Stage stage = new Stage();
            FXMLLoader fxmlLoader;
            Scene scene = null;
            int indiceTesto = listaLibriSerie.getSelectionModel().getSelectedIndex(); //ottiene l'indice del testo selezionato nella lista di testi visualizzati
            Romanzo libroSelezionato = serie.getLibri().get(indiceTesto); //ottiene il romanzo selezionato dall'autore tramite l'indice ottenuto in precedenza
            fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaRomanzo.fxml"));
            Parent root = fxmlLoader.load();
            PaginaRomanzoController paginaRomanzo = fxmlLoader.getController();
            paginaRomanzo.preparaPagina(libroSelezionato, utente);
            scene = new Scene(root, 1300, 900);
            stage.setTitle(libroSelezionato.getTitolo());
            stage.setScene(scene);
            stage.show();
            stage.setResizable(false);
        } catch (IndexOutOfBoundsException ignored) {
        }
        //se viene cliccato uno spazio vuoto, ignora l'eccezione lanciata
    }

    /**
     * Sul click del tasto "Elimina", cancella la serie della pagina.
     */
    public void eliminaOnAction() {
        SerieDAO eliminaSerie = new SerieImplementazionePostgresDAO();
        RomanzoDAO eliminaSeguito = new RomanzoImplementazionePostgresDAO();
        try {
            eliminaSeguito.eliminaSeguito(serie.getIdserie());
            eliminaSerie.eliminaSerieDB(serie.getIdserie());
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            eliminaSeguito.close();
        }
        for (Romanzo romanzo : serie.getLibri()) {
            romanzo.setSeguito(null);
            romanzo.setSerie(null);
        }
        serie.setLibri(null);
        utente.getSerie().remove(serie); //rimozione della serie dall'arraylist di preferenze dell'utente
        utente.getNotifiche().removeIf(notifica -> notifica.getSerie().equals(serie)); //rimozione delle notifiche della serie dall'arraylist di notifiche dell'utente
        Stage stage = (Stage) eliminaButton.getScene().getWindow(); //chiude la pagina
        stage.close();
    }
}

