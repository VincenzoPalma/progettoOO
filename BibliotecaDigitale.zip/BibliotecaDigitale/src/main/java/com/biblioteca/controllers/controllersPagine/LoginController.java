package com.biblioteca.controllers.controllersPagine;

import com.biblioteca.DAO.UtenteDAO;
import com.biblioteca.ImplementazioneDAO.UtenteImplementazionePostgresDAO;
import com.biblioteca.bibliotecadigitale.Main;
import com.biblioteca.model.Utente;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;


/**
 * Controller dedicato alla gestione della pagina di login.
 *
 * @see RegisterController
 */
public class LoginController implements Initializable {
    @FXML
    private Button loginButton;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField usernameField;

    @FXML
    private ImageView sfondoLogin;

    @FXML
    private Label errorLabel;

    @FXML
    private Button registerButton;

    /**
     * Prende il contenuto del campo username e del campo password nella schermata di login
     * e verifica l'esistenza di quell'utente con quella password nel database tramite la
     * classe {@link UtenteImplementazionePostgresDAO}.
     * <p>
     * Se il metodo cercaUtenteDB trova i dati dell'utente, cerca e carica le serie preferite
     * e le notifiche di quell'utente tramite il metodo caricaPreferenze, accetta il login e passa il controllo al
     * controller della homepage, altrimenti visualizza un messaggio di errore.
     *
     * @see HomePageController
     */
    public void loginOnAction() throws IOException {
        //ottiene il contenuto dei due campi
        String username = usernameField.getText();
        String password = passwordField.getText();
        UtenteDAO cercaUtente = new UtenteImplementazionePostgresDAO(); //apre la connessione col database
        //creazione degli arraylist che conterranno il risultato della ricerca
        ArrayList<String> usernameTrovato = new ArrayList<>();
        ArrayList<String> passwordTrovata = new ArrayList<>();
        ArrayList<String> tipoUtenteTrovato = new ArrayList<>();
        try {
            cercaUtente.cercaUtenteDB(username, password, usernameTrovato, passwordTrovata, tipoUtenteTrovato); //ricerca dell'utente nel database e creazione del relativo oggetto Utente
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaUtente.close(); //chiude la connessione
        }
        Utente utente = null;
        try {
            utente = new Utente(usernameTrovato.get(0), passwordTrovata.get(0), tipoUtenteTrovato.get(0)); //crea un oggetto di tipo Utente con i dati risultanti dalla ricerca
        } catch (IndexOutOfBoundsException ignored) {
            //se non è stato trovato un utente, l'arraylist sarà vuoto, e l'oggetto 'utente' rimarrà null
        }
        try {
            if (utente == null) {
                throw new IllegalArgumentException(); //se l'utente non è stato trovato, quindi null, lancia un eccezione
            }
        } catch (IllegalArgumentException e) {
            errorLabel.setText("USERNAME O PASSWORD NON VALIDI"); //quando non viene trovato un utente visualizza un messaggio di errore
            return;
        }
        //caricamento e visualizzazione della homepage nel caso il login sia andato a buon fine
        Stage stage = (Stage) loginButton.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("HomePage.fxml"));
        Parent root = fxmlLoader.load();
        HomePageController homepage = fxmlLoader.getController();
        homepage.preparaPagina(utente); //passaggio dell'oggetto dell'utente che ha effettuato l'accesso e impostazione del messaggio di benvenuto
        Scene scene = new Scene(root, 1920, 1010);
        stage.setTitle("HomePage");
        stage.setScene(scene);
        stage.show();
        stage.centerOnScreen();
        stage.setResizable(false);
    }


    /**
     * Esegue il metodo LoginOnAction dopo aver premuto il tasto
     * "Invio".
     */
    public void invioPremuto(KeyEvent e) throws IOException {
        if (e.getCode().equals(KeyCode.ENTER)) {
            loginOnAction();
        }
    }

    /**
     * Carica l'immagine utilizzata per lo sfondo della
     * pagina di login.
     *
     * @param url Un URL che indica la locazione dell'immagine
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        File loginFile = new File("src/Images/SfondoPaginaLogin.png");
        Image loginImage = new Image(loginFile.toURI().toString());
        sfondoLogin.setImage(loginImage);
    }

    /**
     * Sul click del tasto "Registrati" richiama la pagina di registrazione
     * e passa il controllo al controller dedicato a essa.
     *
     * @throws IOException the io exception
     * @see RegisterController
     */
    public void registratiOnAction() throws IOException {
        Stage stage = (Stage) registerButton.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Register.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 400, 500);
        stage.setTitle("Registrazione");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);

    }
}

