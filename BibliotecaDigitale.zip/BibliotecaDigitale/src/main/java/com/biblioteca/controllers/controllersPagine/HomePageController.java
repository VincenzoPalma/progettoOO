package com.biblioteca.controllers.controllersPagine;

import com.biblioteca.DAO.*;
import com.biblioteca.ImplementazioneDAO.*;
import com.biblioteca.bibliotecadigitale.Main;
import com.biblioteca.controllers.controllersAggiungi.AggiungiArticoloScientificoController;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaArticoloController;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaDidatticoController;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaRomanzoController;
import com.biblioteca.model.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuButton;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Controller dedicato alla gestione della homepage.
 */
public class HomePageController implements Initializable {
    @FXML
    public Label messaggioNuovoUsername;

    /**
     * Lista delle preferenze dell'utente visualizzata nell'interfaccia grafica.
     */
    @FXML
    ListView<String> pannelloPreferenze;
    @FXML
    private TextField barraRicerca;

    /**
     * Lista dei libri visualizzata nell'interfaccia grafica.
     */
    @FXML
    private ListView<String> listaLibri;

    /**
     * Lista degli articoli visualizzata nell'interfaccia grafica.
     */
    @FXML
    private ListView<String> listaPubblicazioni;
    @FXML
    private MenuButton menuUtenteButton;
    @FXML
    private ImageView sfondoHomePage;
    @FXML
    private Pane finestraEliminaProfilo;


    /**
     * Lista delle notifiche dell'utente visualizzata nell'interfaccia grafica.
     */
    @FXML
    private ListView<String> pannelloNotifiche;
    @FXML
    private Label benvenutoLabel;
    @FXML
    private TextField nuovoUsernameField;
    @FXML
    private TextField confermaNuovoUsernameField;
    @FXML
    private Pane pannelloCambiaNomeUtente;
    @FXML
    private Pane pannelloCancellaPreferenza;
    @FXML
    private Label nomeSeriePreferenzaDaEliminare;
    @FXML
    private MenuButton aggiungiMenu;

    /**
     * Oggetto di tipo Utente passato dal controller della pagina di login.
     * Contiene i dati dell'utente che ha effettuato il login.
     */
    private Utente utente;

    /**
     * ArrayList che contiene oggetti di tipo Libro o che lo estendono.
     * Contiene gli oggetti relativi ai libri risultanti da una ricerca.
     */
    private ArrayList<Libro> risultatiLibri = new ArrayList<>();

    /**
     * ArrayList che contiene oggetti di tipo ArticoloScientifico.
     * Contiene gli oggetti relativi agli articoli risultanti da una ricerca.
     */
    private ArrayList<ArticoloScientifico> risultatiArticoliScientifici = new ArrayList<>();

    public ArrayList<ArticoloScientifico> getRisultatiArticoliScientifici() {
        return risultatiArticoliScientifici;
    }

    public void setRisultatiArticoliScientifici(ArrayList<ArticoloScientifico> risultatiArticoliScientifici) {
        this.risultatiArticoliScientifici = risultatiArticoliScientifici;
    }

    public ArrayList<Libro> getRisultatiLibri() {
        return risultatiLibri;
    }

    public void setRisultatiLibri(ArrayList<Libro> risultatiLibri) {
        this.risultatiLibri = risultatiLibri;
    }

    /**
     * Imposta l'utente.
     *
     * @param utente L'utente che ha effettuato l'accesso.
     */
    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    /**
     * Imposta il messaggio di benvenuto in base all'username dell'utente che ha
     * effettuato l'accesso.
     *
     * @param utenteAccesso L'oggetto che contiene i dati dell'utente che ha
     *                      effettuato l'accesso.
     */
    public void preparaPagina(Utente utenteAccesso) {
        setUtente(utenteAccesso);
        utente = caricaPreferenze(utente); //carica le serie preferite e le notifiche dell'utente
        benvenutoLabel.setText("Benvenuto, " + utente.getUsername());
        //se l'utente che ha effettuato l'accesso è di tipo "amministratore", rende visibile il tasto per aggiungere informazioni
        if (utenteAccesso.getTipo().equals("Amministratore")) {
            aggiungiMenu.setVisible(true);
        }
    }

    /**
     * Carica l'immagine di sfondo della homepage e imposta le
     * diverse icone che la compongono.
     *
     * @param url Un URL che indica la locazione dell'immagine.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        File homePageFile = new File("src/Images/SfondoHomePage.png");
        Image homePageImage = new Image(homePageFile.toURI().toString());
        sfondoHomePage.setImage(homePageImage);
    }

    /**
     * Cerca nel database le serie preferite dell'utente passato come parametro
     * tramite {@link SerieImplementazionePostgresDAO} e le notifiche tramite {@link NotificaImplementazionePostgresDAO}.
     * <p>
     *
     * @param utente L'utente di cui si vogliono ottenere le preferenze e le notifiche.
     * @return L'oggetto utente preso come parametro con le preferenze e notifiche attribuite.
     */
    public Utente caricaPreferenze(Utente utente) {
        //apre la connessione con il database
        SerieDAO cercaPreferenzeUtente = new SerieImplementazionePostgresDAO();
        NotificaDAO cercaNotificheUtente = new NotificaImplementazionePostgresDAO();
        try {
            //creazione degli arraylist che conterranno il risultato della ricerca delle serie preferite
            ArrayList<String> titoliSerie = new ArrayList<>();
            ArrayList<Integer> idSerie = new ArrayList<>();
            cercaPreferenzeUtente.cercaSeriePerUtente(utente.getUsername(), titoliSerie, idSerie); //ricerca delle serie preferite dell'utente
            ArrayList<Serie> preferenzeUtente = new ArrayList<>();
            for (int i = 0; i < idSerie.size(); i++) {
                //per ogni serie trovata, viene creato un oggetto Serie, e viene aggiunto alla lista di serie preferite dell'utente
                Serie preferenza = new Serie(titoliSerie.get(i), idSerie.get(i));
                preferenzeUtente.add(preferenza);
            }
            utente.setSerie(preferenzeUtente);
            //creazione degli arraylist che conterranno il risultato della ricerca delle notifiche
            ArrayList<Integer> serieNotifica = new ArrayList<>();
            ArrayList<LocalDate> dataNotifiche = new ArrayList<>();
            ArrayList<LocalTime> orarioNotifiche = new ArrayList<>();
            cercaNotificheUtente.cercaNotificheUtente(utente.getUsername(), serieNotifica, dataNotifiche, orarioNotifiche); //ricerca delle notifiche dell'utente
            ArrayList<Serie> serieConNotifica = new ArrayList<>(); //arraylist che contiene le serie preferite dell'utente per le quali esiste una notifica
            for (Serie serie : utente.getSerie()) {
                for (Integer idSerieNotifica : serieNotifica) {
                    //per ogni serie preferita e per l'idserie di ogni notifica, controlla se sono uguali
                    if (serie.getIdserie() == idSerieNotifica) {
                        //se sono uguali, allora esiste una notifica per quella serie, e viene aggiunto al relativo arraylist
                        serieConNotifica.add(serie);
                    }
                }
            }
            ArrayList<Notifica> notificheUtente = new ArrayList<>();
            for (int i = 0; i < serieNotifica.size(); i++) {
                /* per ogni notifica trovata, viene creato un oggetto Notifica, e viene aggiunto alla lista di notifiche dell'utente
                utilizzando l'arraylist di serie con notifica, in modo tale da attribuire a ogni serie, la propria notifica */
                for (Serie serieAttuale : serieConNotifica) { //trova la serie con id uguale a quello della notifica, e crea l'oggetto Notifica
                    if (serieAttuale.getIdserie() == serieNotifica.get(i)) {
                        Notifica notifica = new Notifica(utente, serieAttuale, dataNotifiche.get(i), orarioNotifiche.get(i));
                        notificheUtente.add(notifica);
                    }
                }
            }
            utente.setNotifiche(notificheUtente);
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaNotificheUtente.close(); //chiusura della connessione
        }
        return utente;
    }

    /**
     * Sul click del tasto "Esci" richiama la schermata di login e
     * passa il controllo al controller dedicato a essa tramite
     * il metodo tornaLoginPage.
     */
    public void esciOnAction() throws IOException {
        tornaLoginPage();
    }

    /**
     * Chiama la schermata di login e passa il controllo al relativo controller.
     */
    public void tornaLoginPage() throws IOException {
        Stage stage = (Stage) menuUtenteButton.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 400, 500);
        stage.setTitle("Accedi");
        stage.setScene(scene);
        stage.show();
        stage.centerOnScreen();
        stage.setResizable(false);
    }

    /**
     * Sul click del tasto "Cancella profilo" rende visibile una schermata
     * per la conferma.
     */
    public void cancellaProfiloOnAction() {
        finestraEliminaProfilo.setVisible(true);
    }

    /**
     * Sul click del tasto "Cambia nome utente" rende visibile una schermata
     * per la modifica dell'username.
     */
    public void cambiaNomeUtenteOnAction() {
        pannelloCambiaNomeUtente.setVisible(true);
    }

    /**
     * Sul click del tasto "X" nella schermata per modificare il
     * nome utente, chiude tale schermata.
     */
    public void annullaCambiaNomeUtenteOnAction() {
        pannelloCambiaNomeUtente.setVisible(false);
        messaggioNuovoUsername.setText("");
        nuovoUsernameField.clear();
        confermaNuovoUsernameField.clear();
    }

    /**
     * Sul click del tasto "Conferma" nella schermata per cambiare l'username,
     * controlla il contenuto dei due textfield in modo tale che:
     * <ul>
     *     <li>L'username inserito non sia vuoto e non contenga spazi.</li>
     *      <li>L'username inserito coincida con la conferma.</li>
     *      <li>L'username inserito non sia uguale a quello attuale.</li>
     * </ul>
     * Se una delle condizioni non è soddisfatta mostrerà uno specifico messaggio di errore in rosso.
     * Se tutte le condizioni sono soddisfatte, tramite {@link UtenteImplementazionePostgresDAO} invia una richiesta di
     * modifica dell'username per quell'utente al database. Se la modifica non è avvenuta, significa che è stato inserito
     * un username già in uso, e verrà mostrato un messaggio di errore in rosso.
     * Altrimenti verrà mostrato un messaggio in verde per l'avvenuta modifica dell'username.
     */
    public void confermaNuovoNomeUtenteOnAction() {
        //ottiene il contenuto dei due campi
        String nuovoUsername = nuovoUsernameField.getText();
        String confermaNuovoUsername = confermaNuovoUsernameField.getText();
        try {
            controlloUsername(nuovoUsername, confermaNuovoUsername); //esegue un controllo sull'username inserito
        } catch (IllegalArgumentException e) {
            return;
        }
        UtenteDAO modificaUsernameUtente = new UtenteImplementazionePostgresDAO(); //apre la connessione col database
        try {
            modificaUsernameUtente.modificaUsernameUtenteDB(nuovoUsername, utente.getUsername()); //esegue la modifica dell'username dell'utente nel database
        } catch (SQLException ex) {
            messaggioNuovoUsername.setTextFill(Color.web("#FF2E2E")); //imposta il colore del messaggio in rosso
            messaggioNuovoUsername.setText("USERNAME GIA' IN USO"); //se l'username inserito è già in uso, visualizza un messaggio di errore
            return;
        } finally {
            modificaUsernameUtente.close(); //chiude la connessione
        }
        utente.setUsername(nuovoUsername); //imposta il nuovo username dell'utente
        messaggioNuovoUsername.setTextFill(Color.web("#00A300")); //imposta il colore del messaggio in verde
        messaggioNuovoUsername.setText("MODIFICA USERNAME RIUSCITA"); //messaggio visualizzato al termine della modifica dell'username
        preparaPagina(utente); //aggiornamento del messaggio di benvenuto
    }

    /**
     * Sul click del tasto "Annulla" nasconde la finestra per la conferma dell'
     * eliminazione dell'utente.
     */
    public void cancellaOnAction() {
        finestraEliminaProfilo.setVisible(false);
    }

    /**
     * Sul click del tasto "Conferma" nella schermata per eliminare l'utente,
     * tramite {@link UtenteImplementazionePostgresDAO} effettua una richiesta al
     * database per eliminare quell'utente. Una volta fatto ritorna alla
     * schermata di login.
     */
    public void confermaOnAction() throws IOException {
        UtenteDAO eliminaUtente = new UtenteImplementazionePostgresDAO();
        try {
            eliminaUtente.eliminaUtenteDB(utente.getUsername()); //elimina l'utente dal database
        } catch (SQLException ex) {
            ex.printStackTrace();
            return;
        } finally {
            eliminaUtente.close(); //chiude la connessione
        }
        tornaLoginPage(); //torna alla schermata di login
    }

    /**
     * Controlla il contenuto del campo della barra di ricerca, controlla che non sia vuoto
     * e tramite {@link RomanzoImplementazionePostgresDAO}, {@link LibroDidatticoImplementazionePostgresDAO} e {@link ArticoloScientificoImplementazionePostgresDAO}
     * esegue delle ricerche del database per romanzi, libri didattici e articoli scientifici.
     * <p>
     * Una volta ottenuti gli ArrayList per i romanzi e i libri didattici, salva il loro contenuto nell'
     * ArrayList di risultati dei libri del controller, poi controlla se entrambi sono vuoti,
     * in tal caso mostra un messaggio per l'assenza di risultati, altrimenti mostra i risultati ottenuti.
     * Controlla se l'ArrayList di articoli è vuoto, in tal caso mostra un messaggio per l'assenza di risultati, altrimenti
     * mostra i risultati ottenuti.
     */
    public void cercaOnAction() {
        String ricerca = barraRicerca.getText(); //ottiene la stringa di ricerca
        //si interrompe se la stringa di ricerca è vuota
        if (ricerca.isEmpty()) {
            return;
        }
        ArrayList<Romanzo> risultatiRomanzi = cercaRomanzi(ricerca); //ricerca dei romanzi
        ArrayList<LibroDidattico> risultatiDidattici = cercaLibriDidattici(ricerca); //ricerca dei libri didattici
        ArrayList<ArticoloScientifico> risultatiArticoli = cercaArticoliScientifici(ricerca); //ricerca degli articoli scientifici
        componiRisultato(risultatiRomanzi, risultatiDidattici, risultatiArticoli); //aggiorna gli arraylist di risultati del controller con i nuovi risultati
        mostraRisultati(); //visualizza i risultati ottenuti
    }

    /**
     * Esegue una ricerca nel database tramite {@link RomanzoImplementazionePostgresDAO} per trovare
     * i romanzi che hanno nel titolo, editore o genere la stringa di ricerca.
     * Per ogni risultato trovato crea un oggetto di tipo Romanzo che viene inserito in un
     * arraylist e poi dato come ritorno.
     *
     * @param ricerca Stringa di ricerca utilizzata per l'interrogazione nel database
     * @return ArrayList contenente oggetti di tipo Romanzo creati dai risultati dell'interrogazione nel database
     */
    public ArrayList<Romanzo> cercaRomanzi(String ricerca) {
        //apre la connessione col database
        RomanzoDAO ricercaRomanzi = new RomanzoImplementazionePostgresDAO();
        //creazione degli arraylist che conterranno le informazioni dei risultati dell'interrogazione
        ArrayList<Romanzo> risultatiRomanzi = new ArrayList<>();
        ArrayList<String> isbn = new ArrayList<>();
        ArrayList<String> titoli = new ArrayList<>();
        ArrayList<String> generi = new ArrayList<>();
        ArrayList<LocalDate> dateUscita = new ArrayList<>();
        ArrayList<String> editori = new ArrayList<>();
        ArrayList<Boolean> cartaceo = new ArrayList<>();
        ArrayList<Boolean> digitale = new ArrayList<>();
        ArrayList<Boolean> audiolibro = new ArrayList<>();
        try {
            ricercaRomanzi.cercaRomanzoDB(ricerca, isbn, titoli, generi, dateUscita, editori, cartaceo, digitale, audiolibro); //esegue la ricerca per i romanzi nel database
        } catch (SQLException ignored) {
            return new ArrayList<>(); //ritorna un arraylist vuoto in caso di eccezione
        } finally {
            ricercaRomanzi.close(); //chiusura della connessione al database
        }
        for (int i = 0; i < isbn.size(); i++) {
            //per ogni romanzo trovato, crea il relativo oggetto e lo aggiunge all'arraylist
            Romanzo romanzoTrovato = new Romanzo(titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), dateUscita.get(i).getYear(), isbn.get(i), dateUscita.get(i).getDayOfMonth(), dateUscita.get(i).getMonthValue(), generi.get(i), null, null);
            risultatiRomanzi.add(romanzoTrovato);
        }
        return risultatiRomanzi;
    }

    /**
     * Esegue una ricerca nel database tramite {@link LibroDidatticoImplementazionePostgresDAO} per trovare
     * i libri didattici che hanno nel titolo, editore o ambito la stringa di ricerca.
     * Per ogni risultato trovato crea un oggetto di tipo LibroDidattico che viene inserito in un
     * arraylist e poi dato come ritorno.
     *
     * @param ricerca Stringa di ricerca utilizzata per l'interrogazione nel database
     * @return ArrayList contenente oggetti di tipo LibroDidattico creati dai risultati dell'interrogazione nel database
     */
    public ArrayList<LibroDidattico> cercaLibriDidattici(String ricerca) {
        //creazione degli arraylist che conterranno le informazioni dei risultati dell'interrogazione
        ArrayList<String> isbn = new ArrayList<>();
        ArrayList<String> titoli = new ArrayList<>();
        ArrayList<String> ambiti = new ArrayList<>();
        ArrayList<LocalDate> dateUscita = new ArrayList<>();
        ArrayList<String> editori = new ArrayList<>();
        ArrayList<Boolean> cartaceo = new ArrayList<>();
        ArrayList<Boolean> digitale = new ArrayList<>();
        ArrayList<Boolean> audiolibro = new ArrayList<>();
        //apre la connessione col database
        LibroDidatticoDAO ricercaLibriDidattici = new LibroDidatticoImplementazionePostgresDAO();
        ArrayList<LibroDidattico> risultatiLibriDidattici = new ArrayList<>();
        try {
            ricercaLibriDidattici.cercaLibroDidatticoDB(ricerca, isbn, titoli, ambiti, dateUscita, editori, cartaceo, digitale, audiolibro); //esegue la ricerca per i romanzi nel database
        } catch (SQLException ignored) {
            return new ArrayList<>(); //ritorna un arraylist vuoto in caso di eccezione
        } finally {
            ricercaLibriDidattici.close(); //chiusura della connessione al database
        }
        for (int i = 0; i < isbn.size(); i++) {
            //per ogni libro didattico trovato, crea il relativo oggetto di tipo Romanzo e lo aggiunge all'arraylist
            LibroDidattico libroDidatticoTrovato = new LibroDidattico(titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), dateUscita.get(i).getYear(), isbn.get(i), dateUscita.get(i).getDayOfMonth(), dateUscita.get(i).getMonthValue(), ambiti.get(i));
            risultatiLibriDidattici.add(libroDidatticoTrovato);
        }
        return risultatiLibriDidattici;
    }

    /**
     * Esegue una ricerca nel database tramite {@link ArticoloScientificoImplementazionePostgresDAO} per trovare
     * gli articoli che hanno nel titolo, editore, tema o argomento la stringa di ricerca.
     * Per ogni risultato trovato crea un oggetto di tipo ArticoloScientifico che viene inserito in un
     * arraylist e poi dato come ritorno.
     *
     * @param ricerca Stringa di ricerca utilizzata per l'interrogazione nel database
     * @return ArrayList contenente oggetti di tipo ArticoloScientifico creati dai risultati dell'interrogazione nel database
     */
    public ArrayList<ArticoloScientifico> cercaArticoliScientifici(String ricerca) {
        //creazione degli arraylist che conterranno le informazioni dei risultati dell'interrogazione
        ArrayList<String> titoli = new ArrayList<>();
        ArrayList<String> argomenti = new ArrayList<>();
        ArrayList<String> temi = new ArrayList<>();
        ArrayList<Integer> annoPubblicazione = new ArrayList<>();
        ArrayList<Integer> idArticoli = new ArrayList<>();
        ArrayList<String> editori = new ArrayList<>();
        ArrayList<Boolean> cartaceo = new ArrayList<>();
        ArrayList<Boolean> digitale = new ArrayList<>();
        ArrayList<Boolean> audiolibro = new ArrayList<>();
        //apre la connessione col database
        ArticoloScientificoDAO ricercaArticoliScientifici = new ArticoloScientificoImplementazionePostgresDAO();
        ArrayList<ArticoloScientifico> risultatiArticoli = new ArrayList<>();
        try {
            ricercaArticoliScientifici.cercaArticoloDB(ricerca, idArticoli, titoli, temi, argomenti, annoPubblicazione, editori, cartaceo, digitale, audiolibro); //esegue la ricerca per gli articoli nel database
        } catch (SQLException ignored) {
            return new ArrayList<>(); //ritorna un arraylist vuoto in caso di eccezione
        } finally {
            ricercaArticoliScientifici.close(); //chiusura della connessione al database
        }
        for (int i = 0; i < idArticoli.size(); i++) {
            //per ogni articolo trovato, crea il relativo oggetto di tipo ArticoloScientifico e lo aggiunge all'arraylist
            ArticoloScientifico articoloScientificoTrovato = new ArticoloScientifico(idArticoli.get(i), titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), annoPubblicazione.get(i), temi.get(i), argomenti.get(i), null, null);
            risultatiArticoli.add(articoloScientificoTrovato);
        }
        return risultatiArticoli;
    }

    /**
     * Sul click dell'icona per le notifiche, se non è già aperta, apre la schermata delle notifiche,
     * altrimenti la chiude.
     */
    public void bottoneNotificheOnAction() {
        //se il pannello delle notifiche è visibile, lo nasconde, altrimenti lo visualizza
        if (pannelloNotifiche.isVisible()) {
            pannelloNotifiche.setVisible(false);
        } else {
            pannelloNotifiche.setVisible(true);
            pannelloNotifiche.getItems().clear();
            if (utente.notifiche.isEmpty()) { //se non ci sono notifiche, viene indicato
                pannelloNotifiche.getItems().addAll("Nessuna notifica");
            } else {
                for (Notifica notifica : utente.getNotifiche()) {
                    //per ogni notifica, viene mostrata nella lista delle notifiche, la relativa serie, la data e l'orario
                    pannelloNotifiche.getItems().addAll("La serie '" + notifica.getSerie().getTitolo() + "' è disponibile!" + " | " + notifica.getData() + " - " + notifica.getOrario());
                }
            }
        }
    }

    /**
     * Sul click di un risultato di un libro, chiama una nuova finestra che
     * conterrà le informazioni di quel libro, le informazioni mostrate dalla finestra
     * dipenderanno dal tipo di libro.
     * <p>
     * Passa l'oggetto del libro selezionato e il tipo di utente al controller della schermata che chiama.
     *
     * @see PaginaRomanzoController
     * @see PaginaDidatticoController
     */
    public void mostraLibroSelezionato() throws IOException {
        try {
            if (!listaLibri.getItems().contains("Nessun libro trovato")) {
                //se viene cliccato un risultato valido nella lista dei risultati dei libri
                int indiceRisultati = listaLibri.getSelectionModel().getSelectedIndex(); //ottiene l'indice dell'elemento selezionato nella lista dei risultati dei libri
                Stage stage = new Stage();
                FXMLLoader fxmlLoader;
                if (risultatiLibri.get(indiceRisultati) instanceof Romanzo) {
                    //se il libro selezionato è un romanzo, apre la pagina per i romanzi
                    fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaRomanzo.fxml"));
                    Parent root = fxmlLoader.load();
                    PaginaRomanzoController paginaRomanzo = fxmlLoader.getController();
                    paginaRomanzo.preparaPagina((Romanzo) risultatiLibri.get(indiceRisultati), utente); //passa l'oggetto del romanzo selezionato e il tipo di utente al controller della pagina del romanzo
                    Scene scene = new Scene(root, 1300, 900);
                    stage.setTitle(risultatiLibri.get(indiceRisultati).getTitolo());
                    stage.setScene(scene);
                } else {
                    //se il libro selezionato è un libro didattico, apre la pagina per i libri didattici
                    fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaLibroDidattico.fxml"));
                    Parent root = fxmlLoader.load();
                    PaginaDidatticoController paginaDidattico = fxmlLoader.getController();
                    paginaDidattico.preparaPagina((LibroDidattico) risultatiLibri.get(indiceRisultati), utente); //passa l'oggetto del libro didattico selezionato e il tipo di utente al controller della pagina del libro didattico
                    Scene scene = new Scene(root, 1300, 900);
                    stage.setTitle(risultatiLibri.get(indiceRisultati).getTitolo());
                    stage.setScene(scene);
                }
                stage.show();
                stage.setResizable(false);
                //rimuove tutti i risultati visualizzati e pulisce il contenuto della barra di ricerca
                risultatiLibri.clear();
                risultatiArticoliScientifici.clear();
                barraRicerca.clear();
                listaLibri.getItems().clear();
                listaPubblicazioni.getItems().clear();
            }
        } catch (IndexOutOfBoundsException ignored) {
        } //se viene cliccato uno spazio vuoto, ignora l'eccezione lanciata
    }

    /**
     * Sul click di un risultato di un articolo, chiama una nuova finestra che
     * conterrà le informazioni di quell'articolo.
     * <p>
     * Passa l'oggetto dell'articolo selezionato e il tipo di utente al controller della schermata che chiama.
     *
     * @see com.biblioteca.controllers.controllersPaginaTesti.PaginaArticoloController
     */
    public void mostraArticoloSelezionato() throws IOException {
        try {
            if (!listaPubblicazioni.getItems().contains("Nessuna pubblicazione trovata")) {
                //se viene cliccato un risultato valido nella lista dei risultati dei libri
                int indiceRisultati = listaPubblicazioni.getSelectionModel().getSelectedIndex(); //ottiene l'indice dell'elemento selezionato nella lista dei risultati degli articoli
                Stage stage = new Stage();
                FXMLLoader fxmlLoader;
                fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaArticolo.fxml"));
                Parent root = fxmlLoader.load();
                PaginaArticoloController paginaArticolo = fxmlLoader.getController();
                paginaArticolo.preparaPagina(risultatiArticoliScientifici.get(indiceRisultati), utente); //passa l'oggetto dell'articolo selezionato e il tipo di utente al controller della pagina dell'articolo
                Scene scene = new Scene(root, 1300, 900);
                stage.setTitle(risultatiArticoliScientifici.get(indiceRisultati).getTitolo());
                stage.setScene(scene);
                stage.show();
                stage.setResizable(false);
                //rimuove tutti i risultati visualizzati e pulisce il contenuto della barra di ricerca
                risultatiLibri.clear();
                risultatiArticoliScientifici.clear();
                barraRicerca.clear();
                listaLibri.getItems().clear();
                listaPubblicazioni.getItems().clear();
            }
        } catch (IndexOutOfBoundsException ignored) {
        } //se viene cliccato uno spazio vuoto, ignora l'eccezione lanciata
    }

    /**
     * Gestisce la finestra delle preferenze dell'utente.
     * Quando viene premuto il tasto "Preferenze", se la schermata è aperta, la chiude,
     * altrimenti la apre e visualizza le preferenze dell'utente.
     */
    public void mostraPreferenze() {
        //se il pannello delle preferenze è visibile, lo nasconde, altrimenti lo visualizza
        if (pannelloPreferenze.isVisible()) {
            pannelloPreferenze.setVisible(false);
        } else {
            pannelloPreferenze.setVisible(true);
            pannelloPreferenze.getItems().clear();
        }
        if (utente.getSerie().isEmpty()) { //se non ci sono preferenze, viene indicato
            pannelloPreferenze.getItems().add("Nessuna preferenza");
        } else {
            for (Serie serie : utente.getSerie()) {
                //per ogni preferenza, viene mostrato il relativo titolo
                pannelloPreferenze.getItems().add(serie.getTitolo());
            }
        }
    }

    /**
     * Sul click del tasto sinistro del mouse su uno spazio vuoto, chiude, se aperti,
     * i pannelli per le preferenze e le notifiche.
     */
    public void nascondiFinestre(MouseEvent e) {
        if (e.getButton().equals(MouseButton.PRIMARY)) {
            if (pannelloPreferenze.isVisible()) {
                pannelloPreferenze.setVisible(false);
            }
            if (pannelloNotifiche.isVisible()) {
                pannelloNotifiche.setVisible(false);
            }
        }
    }

    /**
     * Sul click di una preferenza nella lista delle preferenze, apre
     * una schermata per scegliere se si vuole eliminare quella preferenza.
     */
    public void mostraEliminaPreferenze() {
        //se il pannello per eliminare le preferenze è visibile, lo nasconde, altrimenti lo visualizza
        if (pannelloCancellaPreferenza.isVisible()) {
            pannelloCancellaPreferenza.setVisible(false);
        } else {
            if (!pannelloPreferenze.getItems().contains("Nessuna preferenza") && !pannelloPreferenze.getSelectionModel().isEmpty()) {
                //se viene cliccata una serie valida, apre il pannello per eliminare tale serie
                pannelloCancellaPreferenza.setVisible(true);
                pannelloPreferenze.setVisible(false);
                nomeSeriePreferenzaDaEliminare.setText(pannelloPreferenze.getSelectionModel().getSelectedItem());
            }
        }

    }

    /**
     * Sul click del tasto "Annulla", chiude la schermata per eliminare una preferenza.
     */
    public void annullaEliminaPreferenzaOnAction() {
        pannelloCancellaPreferenza.setVisible(false);
    }

    /**
     * Sul click del tasto "Conferma" nella schermata per eliminare una
     * preferenza, elimina dal database, tramite {@link UtenteImplementazionePostgresDAO}, la preferenza relativa alla serie selezionata
     * dell'utente che ha effettuato il login.
     */
    public void confermaEliminaPreferenzaOnAction() {
        UtenteDAO eliminaPreferenza = new UtenteImplementazionePostgresDAO(); //apre la connessione col database
        int indiceSerieSelezionata = pannelloPreferenze.getSelectionModel().getSelectedIndex(); //ottiene l'indice della preferenza selezionata nella lista delle preferenze
        try {
            eliminaPreferenza.eliminaPreferenzaSerieDB(utente.getUsername(), utente.getSerie().get(indiceSerieSelezionata).getIdserie()); //elimina dal database la preferenza selezionata
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            eliminaPreferenza.close(); //chiusura della connessione col database
            pannelloCancellaPreferenza.setVisible(false); //chiusura del pannello per eliminare le preferenze
        }
        utente.getNotifiche().removeIf(notifica -> notifica.getSerie().getIdserie() == utente.getSerie().get(indiceSerieSelezionata).getIdserie()); //rimozione della notifica della serie rimossa dall'arraylist di notifiche dell'utente
        utente.getSerie().remove(indiceSerieSelezionata); //rimozione della serie dall'arraylist di preferenze dell'utente
    }

    /**
     * Controlla la validità dell'username inserito quando si vuole
     * modificare il nome utente.
     *
     * @param username         Il nuovo username.
     * @param confermaUsername Il contenuto del campo utilizzato per confermare
     *                         l'username.
     */
    public void controlloUsername(String username, String confermaUsername) throws IllegalArgumentException {
        //se non viene inserito un username, visualizza un messaggio di errore
        if (username.isBlank()) {
            messaggioNuovoUsername.setText("INSERIRE UN USERNAME VALIDO");
            messaggioNuovoUsername.setTextFill(Color.web("#FF2E2E"));
            throw new IllegalArgumentException();
        }
        //se l'username e la conferma non coincidono, visualizza un messaggio di errore
        if (!username.equals(confermaUsername)) {
            messaggioNuovoUsername.setText("GLI USERNAME NON COINCIDONO");
            messaggioNuovoUsername.setTextFill(Color.web("#FF2E2E"));
            throw new IllegalArgumentException();
        }
        //se viene inserito un username uguale a quello attuale, visualizza un messaggio di errore
        if (username.equals(utente.getUsername())) {
            messaggioNuovoUsername.setText("INSERIRE UN USERNAME DIVERSO");
            messaggioNuovoUsername.setTextFill(Color.web("#FF2E2E"));
            throw new IllegalArgumentException();
        }
    }

    /**
     * Elimina i risultati precedenti nell'ArrayList dei risultati e lo riempe con i nuovi risultati.
     *
     * @param romanzi             I romanzi trovati tramite la ricerca.
     * @param libriDidattici      I libri didattici trovati tramite la ricerca.
     * @param articoliScientifici Gli articoli scientifici trovati tramite la ricerca.
     */
    public void componiRisultato(ArrayList<Romanzo> romanzi, ArrayList<LibroDidattico> libriDidattici, ArrayList<ArticoloScientifico> articoliScientifici) {
        //pulisce gli arraylist che contengono gli oggetti dei risultati precedenti
        risultatiLibri.clear();
        risultatiArticoliScientifici.clear();
        //inserisce i nuovi risultati negli arraylist
        risultatiLibri.addAll(romanzi);
        risultatiLibri.addAll(libriDidattici);
        risultatiArticoliScientifici.addAll(articoliScientifici);
    }

    /**
     * Mostra i risultati contenuti negli ArrayList risultatiLibri e risultatiArticoliScientifici, ottenuti tramite la ricerca.
     */
    public void mostraRisultati() {
        //rimuove i risultati attuali
        listaLibri.getItems().clear();
        listaPubblicazioni.getItems().clear();
        //se non ci sono risultati, viene indicato
        if (risultatiLibri.isEmpty()) {
            listaLibri.getItems().add("Nessun libro trovato");
        } else {
            for (Libro libro : risultatiLibri) {
                //per ogni libro trovato, vengono visualizzati nella lista dei risultati, il titolo, il genere e l'editore
                if (libro instanceof Romanzo) {
                    listaLibri.getItems().addAll(libro.getTitolo() + " | " + ((Romanzo) libro).getGenere() + " | " + libro.getEditore());
                } else {
                    listaLibri.getItems().addAll(libro.getTitolo() + " | " + ((LibroDidattico) libro).getAmbito() + " | " + libro.getEditore());
                }
            }
        }
        //se non ci sono risultati, viene indicato
        if (risultatiArticoliScientifici.isEmpty()) {
            listaPubblicazioni.getItems().add("Nessuna pubblicazione trovata");
        } else {
            for (ArticoloScientifico articoloScientifico : risultatiArticoliScientifici)
                //per ogni articolo trovato, vengono visualizzati nella lista dei risultati, il titolo, il tema, l'argomento e l'editore
                listaPubblicazioni.getItems().addAll(articoloScientifico.getTitolo() + " | " + articoloScientifico.getTema() + " | " + articoloScientifico.getArgomento() + " | " + articoloScientifico.getEditore()); //visualizza gli articoli trovati
        }
    }

    /**
     * Sul click del tasto "Articolo", apre la pagina per l'inserimento di un nuovo articolo.
     */
    public void aggiungiArticoloScientificoOnAction() throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AggiungiArticoloScientifico.fxml"));
        Parent root = fxmlLoader.load();
        AggiungiArticoloScientificoController paginaAggiungiArticolo = fxmlLoader.getController();
        paginaAggiungiArticolo.preparaPagina();
        Scene scene = new Scene(root, 830, 600);
        stage.setTitle("Aggiungi Un Nuovo Articolo");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);

    }

    /**
     * Sul click del tasto "Libro", apre la pagina per l'inserimento di un nuovo libro.
     */
    public void aggiungiLibroOnAction() throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AggiungiLibro.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 700, 300);
        stage.setTitle("Aggiungi Un Nuovo Libro");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    /**
     * Sul click del tasto "Sala", apre la pagina per l'inserimento di una nuova sala.
     */
    public void aggiungiSalaOnAction() throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AggiungiSala.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 600, 200);
        stage.setTitle("Aggiungi Una Nuova Sala");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);

    }

    /**
     * Sul click del tasto "Collana", apre la pagina per l'inserimento di una nuova collana.
     */
    public void aggiungiCollanaOnAction() throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AggiungiCollana.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 600, 300);
        stage.setTitle("Aggiungi Una Nuova Collana");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);

    }

    /**
     * Sul click del tasto "Autore", apre la pagina per l'inserimento di un nuovo autore.
     */
    public void aggiungiAutoreOnAction() throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AggiungiAutore.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 500, 250);
        stage.setTitle("Aggiungi Un Nuovo Autore");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);


    }

    /**
     * Sul click del tasto "Rivista", apre la pagina per l'inserimento di una nuova rivista.
     */
    public void aggiungiRivistaOnAction() throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AggiungiRivista.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 600, 250);
        stage.setTitle("Aggiungi Una Nuova Rivista");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);

    }

    /**
     * Sul click del tasto "Conferenza", apre la pagina per l'inserimento di una nuova Conferenza.
     */
    public void aggiungiConferenzaOnAction() throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AggiungiConferenza.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 650, 250);
        stage.setTitle("Aggiungi Una Nuova Conferenza");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);

    }

    /**
     * Sul click del tasto "Negozio", apre la pagina per l'inserimento di un nuovo negozio.
     */
    public void aggiungiNegozioOnAction() throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AggiungiNegozio.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 600, 150);
        stage.setTitle("Aggiungi Un Nuovo Negozio");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    /**
     * Sul click del tasto "Serie", apre la pagina per l'inserimento di una nuova serie.
     */
    public void aggiungiSerieOnAction() throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AggiungiSerie.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root, 450, 100);
        stage.setTitle("Aggiungi Una Nuova Serie");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);

    }

    /**
     * Sul click del tasto "X" della barra di ricerca, pulisce il campo.
     */
    public void ripristinaRicercaOnAction() {
        barraRicerca.clear();
    }

    /**
     * Aggiorna le informazioni della pagina dopo aver premuto
     * il tasto F5.
     */
    public void refresh(KeyEvent keyEvent) {
        if (keyEvent.getCode() == KeyCode.F5) {
            preparaPagina(utente);
        }
    }
}





