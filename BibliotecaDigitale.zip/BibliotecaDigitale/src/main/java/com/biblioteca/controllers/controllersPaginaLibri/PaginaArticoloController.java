package com.biblioteca.controllers.controllersPaginaLibri;

import com.biblioteca.model.ArticoloScientifico;
import com.biblioteca.model.Romanzo;
import com.biblioteca.model.Utente;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class PaginaArticoloController {
    @FXML
    private Label conferenzaLabel;
    @FXML
    private Label titoloLabel;
    @FXML
    private Label editoreLabel;
    @FXML
    private Label cartaceoLabel;
    @FXML
    private Label digitaleLabel;
    @FXML
    private Label audilioLibroLabel;
    @FXML
    private Label annoLabel;
    @FXML
    private Label issnLabel;
    @FXML
    private Label temaLabel;
    @FXML
    private Label argomentoLabel;
    @FXML
    private TextField modificaEditore;
    @FXML
    private TextField modificaGenere;
    @FXML
    private TextField modificaAnno;
    @FXML
    private TextField modificaIssn;
    @FXML
    private TextField modificaArgomento;
    @FXML
    private Button modificaArticolo;
    @FXML
    private Button annullaModifiche;
    @FXML
    private Button confermaModifiche;
    @FXML
    private Button elimina;
    @FXML
    private RadioButton checkDigitale;
    @FXML
    private RadioButton checkAudiolibro;
    @FXML
    private RadioButton checkCartaceo;
    @FXML
    private ListView listaAutori;
    @FXML
    private ListView listaRiviste;
    @FXML
    private ListView listaConferenze;
    @FXML
    private Hyperlink nomeConferenza;
    @FXML
    private Hyperlink nomeAutore;
    @FXML
    private Hyperlink nomeRivista;

    private ArticoloScientifico articoloScientifico;

    private Utente utente;

    public ArticoloScientifico getArticoloScientifico() {
        return articoloScientifico;
    }

    public void setArticoloScientifico(ArticoloScientifico articoloScientifico) {
        this.articoloScientifico = articoloScientifico;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    public void refresh() {
    }

    public void modificaArticoloOnAction() {
    }

    public void resetModificheOnAction() {
    }

    public void confermaModificheOnAction() {
    }

    public void eliminaOnAction() {
    }

    public void mostraAutoreSelezionato() {
    }

    public void mostraRivistaSelezionata() {
    }

    public void mostraConferenzaSelezionato() {
    }

    public void visualizzaConferenza() {
    }

    public void visualizzaAutori() {
    }

    public void visualizzaRivista() {
    }

    public void preparaPagina(ArticoloScientifico articoloScientifico, Utente utente) {
    }
}
