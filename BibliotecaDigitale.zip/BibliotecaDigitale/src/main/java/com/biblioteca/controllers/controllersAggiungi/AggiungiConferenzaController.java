package com.biblioteca.controllers.controllersAggiungi;

import com.biblioteca.DAO.ConferenzaDAO;
import com.biblioteca.ImplementazioneDAO.ConferenzaImplementazionePostgresDAO;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

import java.sql.SQLException;
import java.time.LocalDate;

/**
 * Controller dedicato alla gestione della pagina per l'inserimento di conferenze.
 */
public class AggiungiConferenzaController {
    @FXML
    private Label messaggioLabel;
    @FXML
    private TextField responsabileField;
    @FXML
    private TextField strutturaField;
    @FXML
    private TextField cittaField;
    @FXML
    private DatePicker dataInizio;
    @FXML
    private DatePicker dataFine;

    /**
     * Sul click del tasto "Conferma", ottiene il contenuto dei campi, ne verifica la validità, e inserisce una collana
     * con quei valori nel database.
     */
    public void confermaOnAction() {
        //prende il contenuto dei campi
        String struttura = strutturaField.getText();
        String responsabile = responsabileField.getText();
        String citta = cittaField.getText();
        LocalDate dataInizio = this.dataInizio.getValue();
        LocalDate dataFine = this.dataFine.getValue();
        //controlla la validità delle informazioni inserite
        try {
            checkDati(struttura, responsabile, citta, dataInizio, dataFine);
        } catch (IllegalArgumentException ex) {
            return;
        }
        ConferenzaDAO aggiungiConferenza = new ConferenzaImplementazionePostgresDAO(); //apertura della connessione col database
        try {
            aggiungiConferenza.aggiungiConferenzaDB(citta, struttura, responsabile, dataInizio, dataFine); //inserimento della conferenza nel database
        } catch (SQLException ex) {
            ex.printStackTrace();

        } finally {
            aggiungiConferenza.close(); //chiusura della connessione col database
        }
        //messaggio di avvenuto inserimento in verde
        messaggioLabel.setTextFill(Color.web("#00A300"));
        messaggioLabel.setText("CONFERENZA INSERITA");
        resetCampi(); //pulisce i campi
    }

    /**
     * Controlla la validità dei campi inseriti.
     *
     * @param struttura    Nome della struttura che ospita la conferenza da inserire
     * @param responsabile Nome del responsabile della conferenza da inserire
     * @param citta        Nome della città della conferenza da inserire
     * @param dataInizio   Data d'inizio della conferenza da inserire
     * @param dataFine     Data di fine della conferenza da inserire
     */
    public void checkDati(String struttura, String responsabile, String citta, LocalDate dataInizio, LocalDate dataFine) {
        messaggioLabel.setTextFill(Color.web("#FF2E2E")); //imposta il messaggio in rosso, nell'eventualità di un errore
        //controlla che il nome della struttura inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (struttura.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERISCI UNA STRUTTURA");
            throw new IllegalArgumentException();
        }
        //controlla che il nome del responsabile inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (responsabile.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERISCI UN RESPONSABILE");
            throw new IllegalArgumentException();
        }
        //controlla che il nome della città inserita sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (citta.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERISCI UNA CITTA");
            throw new IllegalArgumentException();
        }
        //controlla che la data d'inizio sia valida, in caso negativo visualizza un apposito messaggio di errore
        if (dataInizio == null) {
            messaggioLabel.setText("ERRORE: INSERIRE UNA DATA DI INIZIO");
            throw new IllegalArgumentException();
        }
        //controlla che la data di fine, se specificata, sia successiva alla data d'inizio, in caso negativo visualizza un apposito messaggio di errore
        if (dataFine != null && dataInizio.isAfter(dataFine)) {
            messaggioLabel.setText("ERRORE: LA DATA DI FINE NON PUO PRECEDERE LA DATA DI INIZIO");
            throw new IllegalArgumentException();
        }

    }

    /**
     * Pulisce i campi dopo l'inserimento di una collana
     */
    public void resetCampi() {
        cittaField.clear();
        responsabileField.clear();
        strutturaField.clear();
        dataInizio.setValue(null);
        dataFine.setValue(null);
    }
}
