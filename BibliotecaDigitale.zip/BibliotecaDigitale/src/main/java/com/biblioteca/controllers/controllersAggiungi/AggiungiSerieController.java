package com.biblioteca.controllers.controllersAggiungi;

import com.biblioteca.DAO.SerieDAO;
import com.biblioteca.ImplementazioneDAO.SerieImplementazionePostgresDAO;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

import java.sql.SQLException;

/**
 * Controller dedicato alla gestione della pagina per l'inserimento di serie.
 */
public class AggiungiSerieController {
    @FXML
    private TextField nomeSerieField;
    @FXML
    private Label messaggioLabel;

    /**
     * Sul click del tasto "Conferma", ottiene il contenuto dei campi, ne verifica la validità, e inserisce una serie
     * con quei valori nel database.
     */
    public void confermaOnAction() {
        //prende il contenuto del campo del nome della serie
        String nomeSerie = nomeSerieField.getText();
        //verifica che il nome inserito sia valido
        if (nomeSerie.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERIRE UN NOME VALIDO");
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            return;
        }
        SerieDAO aggiungiSerie = new SerieImplementazionePostgresDAO(); //apertura della connessione col database
        try {
            aggiungiSerie.aggiungiSerieDB(nomeSerie); //inserimento della serie
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            aggiungiSerie.close(); //chiusura della connessione col database
        }
        //messaggio di avvenuto inserimento in verde
        messaggioLabel.setTextFill(Color.web("#00A300"));
        messaggioLabel.setText("SERIE AGGIUNTA");
        nomeSerieField.clear(); //pulisce il campo
    }

}
