package com.biblioteca.controllers.controllersPaginaTesti;

import com.biblioteca.DAO.*;
import com.biblioteca.ImplementazioneDAO.*;
import com.biblioteca.bibliotecadigitale.Main;
import com.biblioteca.controllers.controllersModifica.*;
import com.biblioteca.controllers.controllersPagine.PaginaAutoreController;
import com.biblioteca.controllers.controllersPagine.PaginaCollanaController;
import com.biblioteca.controllers.controllersPagine.PaginaNegozioController;
import com.biblioteca.controllers.controllersPagine.PaginaSalaController;
import com.biblioteca.model.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Classe che contiene metodi utilizzati dai controller
 * delle pagine per la visualizzazione di testi.
 */
public class UtilControllerTesti {

    private UtilControllerTesti() {

    }

    /**
     * Cerca gli autori del libro della pagina nel database, se esiste crea un oggetto
     * per ognuno e li dà come valore di ritorno tramite un
     * arraylist, altrimenti ritorna un arraylist vuoto.
     *
     * @param isbn L'isbn del libro di cui si vogliono cercare gli autori.
     */
    static ArrayList<Autore> cercaAutoriLibro(String isbn) {
        //dichiarazione degli arraylist che conterranno i dati del risultato
        ArrayList<Integer> idAutori = new ArrayList<>();
        ArrayList<String> nominativoAutori = new ArrayList<>();
        ArrayList<LocalDate> dataNascitaAutori = new ArrayList<>();
        ArrayList<String> istitutoAutori = new ArrayList<>();
        AutoreDAO cercaAutori = new AutoreImplementazionePostgresDAO(); //connessione al database
        try {
            cercaAutori.cercaAutorePerLibroDB(isbn, idAutori, nominativoAutori, dataNascitaAutori, istitutoAutori); //ricerca degli autori
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaAutori.close(); //chiusura della connessione al database
        }
        if (idAutori.isEmpty()) { //ritorna un arraylist vuoto se non ci sono risultati
            return new ArrayList<>();
        } else { //altrimenti riempie e ritorna un arraylist di oggetti Autore contenente le informazioni degli autori trovati
            ArrayList<Autore> autoriRomanzo = new ArrayList<>();
            for (int i = 0; i < idAutori.size(); i++) {
                Autore autore = new Autore(idAutori.get(i), nominativoAutori.get(i), istitutoAutori.get(i), dataNascitaAutori.get(i));
                autoriRomanzo.add(autore);
            }
            return autoriRomanzo;
        }
    }

    /**
     * Cerca le esposizioni nelle sale del libro della pagina nel database, se esiste crea un oggetto
     * per ognuna e li dà come valore di ritorno tramite un
     * arraylist, altrimenti ritorna un arraylist vuoto.
     *
     * @param libro Il libro di cui si vogliono cercare le esposizioni.
     */
    static ArrayList<Esposizione> cercaEsposizioni(Libro libro) {
        //dichiarazione degli arraylist che conterranno i dati del risultato della ricerca delle esposizioni
        ArrayList<Integer> idSaleEsposizione = new ArrayList<>();
        ArrayList<LocalDate> dataEsposizione = new ArrayList<>();
        EsposizioneDAO cercaEsposizioni = new EsposizioneImplementazionePostgresDAO(); //connessione al database
        try {
            cercaEsposizioni.cercaEsposizioniPerIsbnDB(libro.getIsbn(), idSaleEsposizione, dataEsposizione); //ricerca delle esposizioni
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaEsposizioni.close(); //chiusura della connessione al database
        }
        if (idSaleEsposizione.isEmpty()) { //ritorna un arraylist vuoto se non ci sono risultati
            return new ArrayList<>();
        }
        //dichiarazione degli arraylist che conterranno i dati del risultato della ricerca delle sale
        ArrayList<String> nomeSale = new ArrayList<>();
        ArrayList<String> indirizzoSale = new ArrayList<>();
        ArrayList<Integer> capienzaSale = new ArrayList<>();
        SalaDAO cercaSale = new SalaImplementazionePostgresDAO(); //connessione al database
        try {
            for (Integer idSala : idSaleEsposizione) {
                cercaSale.cercaSalaPerIdDB(idSala, nomeSale, indirizzoSale, capienzaSale);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaSale.close(); //chiusura della connessione col database
        }
        //arraylist che conterrà le sale delle relative esposizioni trovate
        ArrayList<Sala> sale = new ArrayList<>();
        //per ogni sala trovata, viene creato un oggetto Sala e inserito nell'apposito arraylist
        for (int i = 0; i < idSaleEsposizione.size(); i++) {
            Sala sala = new Sala(idSaleEsposizione.get(i), nomeSale.get(i), indirizzoSale.get(i), capienzaSale.get(i));
            sale.add(sala);
        }
        //per ogni esposizione trovata, viene creato un oggetto Esposizione, utilizzando la relativa serie, e viene inserito nell'apposito arraylist
        ArrayList<Esposizione> esposizioniRomanzo = new ArrayList<>();
        for (int i = 0; i < idSaleEsposizione.size(); i++) {
            Esposizione esposizione = new Esposizione(dataEsposizione.get(i), libro, sale.get(i));
            esposizioniRomanzo.add(esposizione);
        }
        return esposizioniRomanzo;
    }

    /**
     * Cerca le disponibilità nei negozi del libro della pagina nel database, se esiste crea un oggetto
     * per ognuna e li dà come valore di ritorno tramite un
     * arraylist, altrimenti ritorna un arraylist vuoto.
     *
     * @param libro Il libro di cui si vogliono cercare le disponibilità.
     */
    static ArrayList<Disponibilita> cercaDisponibilita(Libro libro) {
        //dichiarazione degli arraylist che conterranno i dati del risultato della ricerca delle disponibilità
        ArrayList<Integer> idNegoziEsposizione = new ArrayList<>();
        ArrayList<BigDecimal> prezzoLibro = new ArrayList<>();
        DisponibilitaDAO cercaDisponibilita = new DisponibilitaImplementazionePostgresDAO(); //connessione al database
        try {
            cercaDisponibilita.cercaDisponibilitaPerIsbnDB(libro.getIsbn(), idNegoziEsposizione, prezzoLibro); //ricerca delle disponibilità
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaDisponibilita.close(); //chiusura della connessione al database
        }
        if (idNegoziEsposizione.isEmpty()) { //ritorna un arraylist vuoto se non ci sono risultati
            return new ArrayList<>();
        }
        //dichiarazione degli arraylist che conterranno i dati del risultato della ricerca dei negozi
        ArrayList<String> nomeNegozi = new ArrayList<>();
        ArrayList<String> sitoNegozi = new ArrayList<>();
        NegozioDAO cercaNegozi = new NegozioImplementazionePostgresDAO(); //connessione al database
        try {
            for (Integer idNegozio : idNegoziEsposizione) {
                cercaNegozi.cercaNegozioPerID(idNegozio, nomeNegozi, sitoNegozi);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaNegozi.close(); //chiusura della connessione col database
        }
        //arraylist che conterrà i negozi delle relative esposizioni trovate
        ArrayList<Negozio> negozi = new ArrayList<>();
        //per ogni negozio trovato, viene creato un oggetto Negozio e inserito nell'apposito arraylist
        for (int i = 0; i < idNegoziEsposizione.size(); i++) {
            Negozio negozio = new Negozio(idNegoziEsposizione.get(i), nomeNegozi.get(i), sitoNegozi.get(i));
            negozi.add(negozio);
        }
        //per ogni disponibilità trovata, viene creato un oggetto Disponibilita, utilizzando il relativo negozio, e viene inserito nell'apposito arraylist
        ArrayList<Disponibilita> disponibilitaRomanzo = new ArrayList<>();
        for (int i = 0; i < idNegoziEsposizione.size(); i++) {
            Disponibilita disponibilita = new Disponibilita(prezzoLibro.get(i), libro, negozi.get(i));
            disponibilitaRomanzo.add(disponibilita);
        }
        return disponibilitaRomanzo;
    }

    /**
     * Cerca le partecipazioni nelle collane del libro della pagina nel database, se esiste crea un oggetto
     * per ognuna e li dà come valore di ritorno tramite un
     * arraylist, altrimenti ritorna un arraylist vuoto.
     *
     * @param libro Il libro di cui si vogliono cercare le partecipazioni.
     */
    static ArrayList<Partecipazione> cercaPartecipazioni(Libro libro) {
        //dichiarazione degli arraylist che conterranno i dati del risultato della ricerca delle partecipazioni
        ArrayList<String> issnCollanaPartecipazioni = new ArrayList<>();
        ArrayList<LocalDate> dataPartecipazioni = new ArrayList<>();
        PartecipazioneDAO cercaPartecipazione = new PartecipazioneImplementazionePostgresDAO(); //connessione al database
        try {
            cercaPartecipazione.cercaPartecipazionePerIsbnDB(libro.getIsbn(), issnCollanaPartecipazioni, dataPartecipazioni); //ricerca delle partecipazioni
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaPartecipazione.close(); //chiusura della connessione al database
        }
        if (issnCollanaPartecipazioni.isEmpty()) { //ritorna un arraylist vuoto se non ci sono risultati
            return new ArrayList<>();
        }
        //dichiarazione degli arraylist che conterranno i dati del risultato della ricerca delle collane
        ArrayList<String> nomeCollane = new ArrayList<>();
        ArrayList<String> caratteristicaCollane = new ArrayList<>();
        ArrayList<String> descrizioneCollane = new ArrayList<>();
        ArrayList<LocalDate> dataPubblicazioneCollane = new ArrayList<>();
        ArrayList<String> direttoreCollane = new ArrayList<>();
        ArrayList<String> editoreCollane = new ArrayList<>();
        CollanaDAO cercaCollane = new CollanaImplementazionePostgresDAO(); //connessione al database
        try {
            for (String issnCollana : issnCollanaPartecipazioni) {
                cercaCollane.cercaCollanaPerIdDB(issnCollana, nomeCollane, caratteristicaCollane, descrizioneCollane, dataPubblicazioneCollane, direttoreCollane, editoreCollane);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaCollane.close(); //chiusura della connessione col database
        }
        //arraylist che conterrà le collane delle relative partecipazioni trovate
        ArrayList<Collana> collane = new ArrayList<>();
        //per ogni collana trovata, viene creato un oggetto Collana e inserito nell'apposito arraylist
        for (int i = 0; i < issnCollanaPartecipazioni.size(); i++) {
            Collana collana = new Collana(issnCollanaPartecipazioni.get(i), nomeCollane.get(i), caratteristicaCollane.get(i), descrizioneCollane.get(i), dataPubblicazioneCollane.get(i), direttoreCollane.get(i), editoreCollane.get(i));
            collane.add(collana);
        }
        //per ogni partecipazione trovata, viene creato un oggetto Partecipazione, utilizzando la relativa collana, e viene inserito nell'apposito arraylist
        ArrayList<Partecipazione> partecipazioneRomanzo = new ArrayList<>();
        for (int i = 0; i < issnCollanaPartecipazioni.size(); i++) {
            Partecipazione partecipazione = new Partecipazione(dataPartecipazioni.get(i), libro, collane.get(i));
            partecipazioneRomanzo.add(partecipazione);
        }
        return partecipazioneRomanzo;
    }

    /**
     * Disabilita i label hyperlink della pagina del libro.
     */
    static void disabilitaCampi(ListView<String> listaSale, ListView<String> listaCollane, ListView<String> listaNegozi, ListView<String> listaAutori, Button modifica) {
        listaSale.setVisible(false);
        listaCollane.setVisible(false);
        listaNegozi.setVisible(false);
        listaAutori.setVisible(false);
        modifica.setVisible(false);
    }

    /**
     * Imposta i label e abilita i textfield e i radiobutton per la modifica
     */
    static void preparaModifica(Label dataUscitaLabel, Label isbnLabel, Label cartaceoLabel, Label audiolibroLabel, Label digitaleLabel, TextField modificaEditore, String editore, TextField modificaGenere, Label genereLabel,
                                String genere, DatePicker modificaData, TextField modificaIsbn, String isbn, int giorno, int mese, int anno, Button confermaModifiche, RadioButton checkCartaceo, RadioButton checkDigitale, RadioButton checkAudiolibro, Label editoreLabel, Button elimina) {
        //impostazione dei label
        dataUscitaLabel.setText("");
        isbnLabel.setText("");
        cartaceoLabel.setText("");
        audiolibroLabel.setText("");
        editoreLabel.setText("");
        genereLabel.setText("");
        digitaleLabel.setText("");
        //impostazione dei textfield e radiobutton
        modificaEditore.setText(editore);
        modificaEditore.setVisible(true);
        modificaGenere.setText(genere);
        modificaGenere.setVisible(true);
        LocalDate dataLibro = LocalDate.of(anno, mese, giorno);
        modificaData.setValue(dataLibro);
        modificaData.setVisible(true);
        modificaIsbn.setText(isbn);
        modificaIsbn.setVisible(true);
        confermaModifiche.setVisible(true);
        checkAudiolibro.setVisible(true);
        checkCartaceo.setVisible(true);
        checkDigitale.setVisible(true);
        elimina.setVisible(true);
    }

    /**
     * Imposta i radio button dei formati in base al loro valore attuale quando si entra nella modalitò di modifica.
     */
    static void checkFormati(Boolean cartaceo, Boolean digitale, Boolean audiolibro, RadioButton checkCartaceo, RadioButton checkDigitale, RadioButton checkAudiolibro) {
        if (audiolibro) {
            checkAudiolibro.setSelected(true);
        }
        if (cartaceo) {
            checkCartaceo.setSelected(true);
        }
        if (digitale) {
            checkDigitale.setSelected(true);
        }
    }

    /**
     * Imposta i label hyperlink per l'aggiunta e rimozione di vari elementi del libro nella modalità di modifica.
     */
    static void setTastiModifica(Hyperlink nomeSala, Hyperlink nomeCollana, Hyperlink nomeAutore, Hyperlink nomeNegozio, @Nullable Hyperlink nomeSeguito, @Nullable Hyperlink nomeSerie) {
        nomeSala.setText("Aggiungi/Rimuovi esposizione.");
        nomeSala.setVisible(true);
        nomeSala.setDisable(false);
        nomeSala.setUnderline(true);
        nomeCollana.setText("Aggiungi/Rimuovi collana.");
        nomeCollana.setVisible(true);
        nomeCollana.setDisable(false);
        nomeCollana.setUnderline(true);
        nomeNegozio.setText("Aggiungi/Rimuovi negozio.");
        nomeNegozio.setVisible(true);
        nomeNegozio.setDisable(false);
        nomeNegozio.setUnderline(true);
        nomeAutore.setText("Aggiungi/Rimuovi autore.");
        nomeAutore.setVisible(true);
        nomeNegozio.setUnderline(true);
        //l'invocazione di questo metodo avrà nomeSeguito e nomeSerie entrambi a null nel caso dei libri didattici, o entrambi non null, per i romanzi
        if (nomeSerie != null) {
            if (!nomeSerie.getText().equals("Nessuna serie.")) {
                nomeSerie.setText("Rimuovi serie.");
                nomeSeguito.setDisable(false);
                if (nomeSeguito.getText().equals("Nessun seguito.")) {
                    nomeSeguito.setText("Aggiungi seguito.");
                } else {
                    nomeSeguito.setText("Rimuovi seguito.");
                }
                nomeSeguito.setVisible(true);
                nomeSeguito.setUnderline(true);
            } else {
                nomeSerie.setText("Aggiungi serie.");
                nomeSerie.setDisable(false);
                nomeSeguito.setText("N/A");
                nomeSeguito.setDisable(true);
                nomeSeguito.setUnderline(false);
            }
            nomeSerie.setVisible(true);
            nomeSerie.setUnderline(true);
        }

    }

    /**
     * Controlla che i dati passati come parametri, per la modifica del libro, siano validi.
     *
     * @param nuovaData   Nuova data di pubblicazione del libro inserita.
     * @param nuovoIsbn   Nuovo isbn del libro inserito.
     * @param autoriLibro ArrayList di autori del libro, utilizzato per controllare la coerenza tra la data
     *                    di nascita dell'autore e quella di pubblicazione del libro.
     * @return true se tutti i dati sono validi, altrimenti false.
     */
    static Boolean controlloDatiModifica(LocalDate nuovaData, String nuovoIsbn, ArrayList<Autore> autoriLibro, Label messaggioErroreIsbn, Label messaggioErroreData) {
        //controlla che il nuovo isbn inserito sia di 13 caratteri e sia composto da soli caratteri numerici, in caso negativo visualizza un apposito messaggio di errore
        if (!nuovoIsbn.matches("[0-9]{13}") || nuovoIsbn.isBlank()) {
            messaggioErroreIsbn.setText("Inserire un ISBN valido.");
            messaggioErroreIsbn.setTextFill(Color.web("#FF2E2E"));
            return false;
        }
        //controlla che la nuova data di pubblicazione sia valida
        if (nuovaData == null) {
            messaggioErroreData.setText("Data non valida.");
            messaggioErroreData.setTextFill(Color.web("#FF2E2E"));
            return false;
        }
        //per ogni autore del libro, controlla che la sua data di nascita venga prima della nuova data di pubblicazione del libro, in caso negativo visualizza un apposito messaggio di errore
        for (Autore autore : autoriLibro) {
            if (autore.getDatanascita() != null && autore.getDatanascita().isAfter(nuovaData)) {
                messaggioErroreData.setText("Data non valida.");
                messaggioErroreData.setTextFill(Color.web("#FF2E2E"));
                return false;
            }
        }
        return true; //se tutti i controlli vengono passati, ritorna true
    }

    /**
     * Imposta il messaggio di errore, in rosso, in base al tipo di errore.
     */
    static void setMessaggioErrore(Label messaggioErroreFormato, Label messaggioErroreIsbn, Boolean nuovoCartaceo, Boolean nuovoDigitale) {
        //se non è stato selezionato un formato tra digitale e cartaceo visualizza un errore
        if (!nuovoCartaceo && !nuovoDigitale) {
            messaggioErroreFormato.setText("IL FORMATO DEVE ESSERE ALMENO UNO TRA 'DIGITALE' E 'CARTACEO'");
            messaggioErroreFormato.setTextFill(Color.web("#FF2E2E"));
        } else { //se l'isbn inserito è già in uso, visualizza un errore
            messaggioErroreIsbn.setText("ISBN già in uso.");
            messaggioErroreIsbn.setTextFill(Color.web("#FF2E2E"));
        }
    }

    /**
     * Imposta nella pagina le informazioni di base sempre presenti in un libro.
     */
    static void setInformazioniBase(String titolo, String editore, String genere, String isbn, int giorno, int mese, int anno, Label editoreLabel, Label titoloLabel, Label genereLabel, Label isbnLabel, Label datauscitaLabel) {
        titoloLabel.setText(titolo);
        editoreLabel.setText(editore);
        genereLabel.setText(genere);
        isbnLabel.setText(isbn);
        datauscitaLabel.setText(giorno + " / " + mese + " / " + anno);
    }

    /**
     * Imposta le informazioni sul formato del libro nella pagina.
     */
    static void setFormati(Boolean cartaceo, Boolean digitale, Boolean audiolibro, Label cartaceoLabel, Label digitaleLabel, Label audiolibroLabel) {
        if (cartaceo) {
            cartaceoLabel.setText("Si");
        } else {
            cartaceoLabel.setText("No");
        }
        if (digitale) {
            digitaleLabel.setText("Si");
        } else {
            digitaleLabel.setText("No");
        }
        if (audiolibro) {
            audiolibroLabel.setText("Si");
        } else {
            audiolibroLabel.setText("No");
        }
    }

    /**
     * Nasconde tutti i campi per la modifica.
     */
    static void chiudiModifiche(TextField modificaEditore, TextField modificaGenere, DatePicker modificaData, Button modificaLibro, Button confermaModifiche, TextField modificaIsbn, RadioButton checkCartaceo, RadioButton checkDigitale, RadioButton checkAudiolibro, Label messaggioErroreIsbn, Label messaggioErroreData, Label messaggioErroreFormato, Button elimina) {
        modificaEditore.setVisible(false);
        modificaGenere.setVisible(false);
        modificaData.setVisible(false);
        modificaLibro.setVisible(true);
        confermaModifiche.setVisible(false);
        modificaIsbn.setVisible(false);
        messaggioErroreIsbn.setText("");
        messaggioErroreData.setText("");
        messaggioErroreFormato.setText("");
        checkAudiolibro.setVisible(false);
        checkCartaceo.setVisible(false);
        checkDigitale.setVisible(false);
        elimina.setVisible(false);
    }

    /**
     * Imposta nella pagina le informazioni che hanno un HyperLink.
     */
    static void setInformazioniHyperLink(Hyperlink nomeCollana, Hyperlink nomeSala, Hyperlink nomeAutore, Hyperlink nomeNegozio, @Nullable Hyperlink nomeSerie, @Nullable Hyperlink nomeSeguito, Libro libro) {
        if (nomeSeguito != null) {
            if ((((Romanzo) libro).getSeguito() == null)) {
                nomeSeguito.setText("Nessun seguito.");
                nomeSeguito.setDisable(true);
                nomeSeguito.setUnderline(false);
            } else nomeSeguito.setText(((Romanzo) libro).getSeguito().getTitolo());
        }
        if (nomeSerie != null) {
            if ((((Romanzo) libro).getSerie() == null)) {
                nomeSerie.setText("Nessuna serie.");
                nomeSerie.setUnderline(false);
                nomeSerie.setDisable(true);
            } else {
                nomeSerie.setText((((Romanzo) libro).getSerie().getTitolo()));
                nomeSerie.setUnderline(true);
                nomeSerie.setDisable(false);
            }
        }
        if (libro.getPartecipazioni().isEmpty()) {
            nomeCollana.setDisable(true);
            nomeCollana.setUnderline(false);
            nomeCollana.setText("Nessuna collana.");
        } else if (libro.getPartecipazioni().size() > 1) {
            nomeCollana.setText("Visualizza Collane");
        } else {
            nomeCollana.setText(libro.getPartecipazioni().get(0).getCollana().getNome());
        }
        if (libro.getEsposizioni().isEmpty()) {
            nomeSala.setDisable(true);
            nomeSala.setUnderline(false);
            nomeSala.setText("Nessuna esposizione.");
        } else if (libro.getEsposizioni().size() > 1) {
            nomeSala.setText("Visualizza Sale");
        } else {
            nomeSala.setText(libro.getEsposizioni().get(0).getSala().getNome());
        }
        if (libro.getAutori().size() > 1) {
            nomeAutore.setText("Visualizza Autori");
        } else if (libro.getAutori().isEmpty()) {
            nomeAutore.setText("N/A");
        } else {
            nomeAutore.setText(libro.getAutori().get(0).getNominativo());
        }
        if (libro.getDisponibili().isEmpty()) {
            nomeNegozio.setText("Nessun Negozio.");
            nomeNegozio.setDisable(true);
            nomeNegozio.setUnderline(false);
        } else if (libro.getDisponibili().size() > 1) {
            nomeNegozio.setText("Visualizza Negozi");
        } else {
            nomeNegozio.setText(libro.getDisponibili().get(0).negozio.getNome());
        }
    }

    /**
     * Ritorna il valore dei radio button dei formati.
     */
    static Boolean modificaDigitale(RadioButton digitale) {
        return digitale.isSelected();
    }

    static Boolean modificaCartaceo(RadioButton cartaceo) {
        return cartaceo.isSelected();
    }

    static Boolean modificaAudiolibro(RadioButton audiolibro) {
        return audiolibro.isSelected();
    }

    /**
     * Apre una nuova finestra contenente le informazioni della sala che è stata selezionata.
     *
     * @param sala Oggetto di tipo Sala contenente le informazioni della sala selezionata.
     */
    static void visualizzaSalaSelezionata(Sala sala, Utente utente) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaSala.fxml"));
        Parent root = fxmlLoader.load();
        PaginaSalaController paginaSala = fxmlLoader.getController();
        paginaSala.preparaPagina(sala, utente);
        Scene scene = new Scene(root, 550, 500);
        stage.setTitle(sala.getNome());
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    /**
     * Apre una nuova finestra contenente le informazioni dell'autore che è stato selezionato.
     *
     * @param autore Oggetto di tipo Autore contenente le informazioni dell'autore selezionato.
     */
    static void visualizzaAutore(Autore autore, Utente utente) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaAutore.fxml"));
        Parent root = fxmlLoader.load();
        PaginaAutoreController paginaAutore = fxmlLoader.getController();
        paginaAutore.preparaPagina(autore, utente);
        Scene scene = new Scene(root, 500, 600);
        stage.setTitle(autore.getNominativo());
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    /**
     * Apre una nuova finestra contenente le informazioni della collana che è stata selezionata.
     *
     * @param collana Oggetto di tipo Collana contenente le informazioni della collana selezionata.
     */
    static void visualizzaCollana(Collana collana, Utente utente) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaCollana.fxml"));
        Parent root = fxmlLoader.load();
        PaginaCollanaController paginaCollana = fxmlLoader.getController();
        paginaCollana.preparaPagina(collana, utente);
        Scene scene = new Scene(root, 500, 630);
        stage.setTitle(collana.getNome());
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    /**
     * Apre la pagina per aggiungere e rimuovere partecipazioni del libro nelle collane.
     *
     * @param libro Il libro di cui si vogliono gestire le partecipazioni.
     */
    static void visualizzaGestioneCollana(Libro libro) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("ModificaCollane.fxml"));
        Parent root = fxmlLoader.load();
        ModificaCollaneController paginaModificaCollana = fxmlLoader.getController();
        paginaModificaCollana.preparaPagina(libro);
        Scene scene = new Scene(root, 600, 400);
        stage.setTitle("Aggiungi/Rimuovi collana");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    /**
     * Apre la pagina per aggiungere e rimuovere esposizioni del libro nelle sale.
     *
     * @param libro Il libro di cui si vogliono gestire le esposizioni.
     */
    public static void visualizzaGestioneSala(Libro libro) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("ModificaSale.fxml"));
        Parent root = fxmlLoader.load();
        ModificaSaleController paginaModificaSala = fxmlLoader.getController();
        paginaModificaSala.preparaPagina(libro);
        Scene scene = new Scene(root, 600, 400);
        stage.setTitle("Aggiungi/Modifica sala");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    /**
     * Apre la pagina per aggiungere e rimuovere autori del libro.
     *
     * @param testo Il testo di cui si vogliono gestire gli autori.
     */
    public static void visualizzaGestioneAutore(Testo testo) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("ModificaAutore.fxml"));
        Parent root = fxmlLoader.load();
        ModificaAutoreController paginaModificaAutore = fxmlLoader.getController();
        paginaModificaAutore.preparaPagina(testo);
        Scene scene = new Scene(root, 600, 400);
        stage.setTitle("Aggiungi/Rimuovi autore");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    /**
     * Apre la pagina per aggiungere e rimuovere il libro dai negozi.
     *
     * @param libro Il libro di cui si vogliono gestire i negozi.
     */
    public static void visualizzaGestioneNegozio(Libro libro) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("ModificaNegozio.fxml"));
        Parent root = fxmlLoader.load();
        ModificaNegozioController paginaModificaNegozio = fxmlLoader.getController();
        paginaModificaNegozio.preparaPagina(libro);
        Scene scene = new Scene(root, 600, 400);
        stage.setTitle("Aggiungi/Rimuovi Negozio");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    /**
     * Apre la pagina per aggiungere e rimuovere la serie del romanzo.
     *
     * @param romanzo Il romanzo di cui si vuole gestire la serie.
     */
    public static void visualizzaGestioneSerie(Romanzo romanzo) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("ModificaSerie.fxml"));
        Parent root = fxmlLoader.load();
        ModificaSerieController paginaModificaSerie = fxmlLoader.getController();
        paginaModificaSerie.preparaPagina(romanzo);
        Scene scene = new Scene(root, 350, 400);
        stage.setTitle("Aggiungi Serie");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    /**
     * Apre la pagina per aggiungere e rimuovere il seguito del romanzo.
     *
     * @param romanzo Il romanzo di cui si vuole gestire il seguito.
     */
    public static void visualizzaGestioneSeguito(Romanzo romanzo) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("ModificaSeguito.fxml"));
        Parent root = fxmlLoader.load();
        ModificaSeguitoController modificaSeguito = fxmlLoader.getController();
        modificaSeguito.preparaPagina(romanzo);
        Scene scene = new Scene(root, 350, 400);
        stage.setTitle("Aggiungi Seguito");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }


    /**
     * Apre una nuova finestra contenente le informazioni del negozio che è stato selezionato.
     *
     * @param negozio Oggetto di tipo Negozio contenente le informazioni del negozio selezionato.
     */
    static void visualizzaNegozio(Negozio negozio, Utente utente) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaNegozio.fxml"));
        Parent root = fxmlLoader.load();
        PaginaNegozioController paginaNegozio = fxmlLoader.getController();
        paginaNegozio.preparaPagina(negozio, utente);
        Scene scene = new Scene(root, 800, 500);
        stage.setTitle(negozio.getNome());
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    /**
     * Visualizza le sale una sola volta anche se esistono più esposizioni
     * nella stessa sala.
     *
     * @param esposizioni La lista delle esposizioni del libro.
     * @param listaSale   La lista di sale da riempire e visualizzare.
     */
    static void visualizzaSale(ArrayList<Esposizione> esposizioni, ListView<String> listaSale) {
        listaSale.getItems().clear();
        for (Esposizione esposizione : esposizioni) {
            if (!listaSale.getItems().contains(esposizione.getSala().getNome())) {
                listaSale.getItems().addAll(esposizione.sala.getNome());
            }
        }
    }

    /**
     * Visualizza il pannello selezionato che contiene la lista d'informazioni chiudendo gli altri.
     */
    static void gestisciVisualizzazioneListe(ListView<String> listaAutori, ListView<String> listaCollane, ListView<String> listaNegozi, ListView<String> listaSale, ListView<String> listaScelta) {
        listaAutori.setVisible(listaAutori.equals(listaScelta));
        listaCollane.setVisible(listaCollane.equals(listaScelta));
        listaNegozi.setVisible(listaNegozi.equals(listaScelta));
        listaSale.setVisible(listaSale.equals(listaScelta));
    }

    /**
     * Chiude i pannelli che visualizzano le liste d'informazioni.
     */
    static void chiudiPannelliInformazioni(ListView<String> autori, ListView<String> sale, ListView<String> collane, ListView<String> negozi) {
        autori.setVisible(false);
        sale.setVisible(false);
        collane.setVisible(false);
        negozi.setVisible(false);
    }

    /**
     * Sul click del tasto "elimina" in modalità modifica, elimina il libro della pagina attuale.
     *
     * @param libro Il libro da eliminare
     */
    static void eliminaLibro(Libro libro) {
        LibroDAO eliminaLibro = new LibroImplementazionePostgresDAO();
        try {
            eliminaLibro.eliminaLibroDB(libro.getIsbn());
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            eliminaLibro.close();
        }
    }
}
