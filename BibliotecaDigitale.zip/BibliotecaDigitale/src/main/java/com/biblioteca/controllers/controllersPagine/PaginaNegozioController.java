package com.biblioteca.controllers.controllersPagine;

import com.biblioteca.DAO.DisponibilitaDAO;
import com.biblioteca.DAO.LibroDAO;
import com.biblioteca.DAO.NegozioDAO;
import com.biblioteca.DAO.PuntoVenditaDAO;
import com.biblioteca.ImplementazioneDAO.DisponibilitaImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.LibroImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.NegozioImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.PuntoVenditaImplementazionePostgresDAO;
import com.biblioteca.bibliotecadigitale.Main;
import com.biblioteca.controllers.controllersAggiungi.AggiungiPuntoVenditaController;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaDidatticoController;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaRomanzoController;
import com.biblioteca.model.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Controller dedicato alla gestione della pagina per i negozi.
 */
public class PaginaNegozioController implements Initializable {

    @FXML
    private Hyperlink nomeSito;
    @FXML
    private Label nomeNegozioLabel;
    @FXML
    private ListView<String> listaTestiDisponibili;
    @FXML
    private ListView<String> listaPuntiVendita;
    @FXML
    private Button confermaModifiche;
    @FXML
    private Button modificaNegozioButton;
    @FXML
    private Button annullaModifiche;
    @FXML
    private TextField modificaSito;
    @FXML
    private Label messaggioLabel;
    @FXML
    private TextField modificaNomeNegozio;
    @FXML
    private Button eliminaButton;
    @FXML
    private ImageView sfondo;

    /**
     * Negozio di cui si vogliono mostrare le informazioni.
     */
    private Negozio negozio;

    /**
     * Utente che ha aperto la pagina, utilizzato per
     * decidere se l'utente in questione può o meno modificare i
     * dati della pagina.
     */
    private Utente utente;

    public Negozio getNegozio() {
        return negozio;
    }

    public void setNegozio(Negozio negozio) {
        this.negozio = negozio;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        File sfondoFile = new File("src/Images/paginaNegozio.png");
        Image sfondoImmagine = new Image(sfondoFile.toURI().toString());
        sfondo.setImage(sfondoImmagine);
    }

    /**
     * @param negozio Negozio di cui si mostrano le informazioni.
     * @param utente  Utente che ha aperto la pagina.
     */
    public void preparaPagina(Negozio negozio, Utente utente) {
        //imposta il negozio e l'utente
        setNegozio(negozio);
        setUtente(utente);
        nomeNegozioLabel.setText(negozio.getNome()); //imposta il nome della pagina
        //imposta il sito, se non esiste, viene indicato
        if (negozio.getSito() == null) {
            nomeSito.setText("Non Disponibile.");
            nomeSito.setDisable(true);
        } else {
            nomeSito.setText("www." + negozio.getSito());
        }
        //dichiarazione degli arraylist che conterranno le informazioni dei risultati delle disponibilità
        ArrayList<String> isbnLibri = new ArrayList<>();
        ArrayList<BigDecimal> prezziLibri = new ArrayList<>();
        ArrayList<Disponibilita> disponibilitaNegozio = new ArrayList<>();
        DisponibilitaDAO cercaDisponibilita = new DisponibilitaImplementazionePostgresDAO(); //connessione col database
        PuntoVenditaDAO cercaPuntiVendita = new PuntoVenditaImplementazionePostgresDAO();
        //dichiarazione degli arraylist che conterranno le informazioni dei risultati dei punti vendita
        ArrayList<Integer> idPuntiVendita = new ArrayList<>();
        ArrayList<String> nomePuntoVendita = new ArrayList<>();
        ArrayList<String> cittaPuntoVendita = new ArrayList<>();
        ArrayList<PuntoVendita> puntiVenditaNegozio = new ArrayList<>();
        try {
            cercaDisponibilita.cercaDisponibilitaPerIdNegozioDB(negozio.getIdnegozio(), isbnLibri, prezziLibri); //cerca le disponibilità del negozio
            cercaPuntiVendita.cercaPuntoVenditaPerIdNegozio(negozio.getIdnegozio(), idPuntiVendita, nomePuntoVendita, cittaPuntoVendita); //cerca i punti vendita del negozio
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaPuntiVendita.close(); //chiusura della connessione
        }
        //per ogni punto vendita trovato, crea un oggetto e lo aggiunge all'arraylist
        for (int i = 0; i < idPuntiVendita.size(); i++) {
            PuntoVendita puntoVendita = new PuntoVendita(idPuntiVendita.get(i), nomePuntoVendita.get(i), cittaPuntoVendita.get(i), negozio);
            puntiVenditaNegozio.add(puntoVendita);
        }
        negozio.setPuntivendita(puntiVenditaNegozio); //imposta i punti vendita trovati al negozio
        ArrayList<Libro> libriDisponibili = cercaLibriNegozio(negozio.getIdnegozio());
        //per ogni libro trovato, crea il relativo oggetto Disponibilita
        for (int i = 0; i < libriDisponibili.size(); i++) {
            Disponibilita disponibilita = new Disponibilita(prezziLibri.get(i), libriDisponibili.get(i), negozio);
            disponibilitaNegozio.add(disponibilita);
        }
        negozio.setDisponibili(disponibilitaNegozio);
        //visualizza nella lista, ogni libro disponibile
        for (Disponibilita disponibilita : negozio.getDisponibili()) {
            if (disponibilita.getLibro() instanceof Romanzo) {
                listaTestiDisponibili.getItems().add(disponibilita.getLibro().getTitolo() + " | Romanzo | € " + disponibilita.getPrezzo());
            } else {
                listaTestiDisponibili.getItems().add(disponibilita.getLibro().getTitolo() + " | Didattico | € " + disponibilita.getPrezzo());
            }
        }
        //visualizza i punti vendita del negozio
        if (negozio.getPuntivendita().isEmpty()) {
            listaPuntiVendita.getItems().add("Nessun punto vendita");
        } else {
            for (PuntoVendita puntoVendita : negozio.getPuntivendita()) {
                listaPuntiVendita.getItems().addAll((puntoVendita.getNome() + " | " + puntoVendita.getCitta()));
            }

        }
        //se l'utente è un amministratore, visualizza il bottone di modifica
        if (utente.getTipo().equals("Amministratore")) {
            modificaNegozioButton.setDisable(false);
            modificaNegozioButton.setVisible(true);
        }

    }

    /**
     * Cerca i libri del negozio con id uguale a quello passato
     * come parametro nel database. Ritorna un arraylist di libri trovati, sia didattici che romanzi.
     *
     * @param idNegozio Id del negozio di cui si vogliono ottenere i libri.
     * @return Un arraylist di oggetti di tipo Libro.
     */
    public ArrayList<Libro> cercaLibriNegozio(int idNegozio) {
        LibroDAO cercaLibri = new LibroImplementazionePostgresDAO(); //connessione al database
        ArrayList<Libro> libriNegozio = new ArrayList<>(); //arraylist dei libri del negozio
        //dichiarazione degli arraylist che conterranno le informazioni dei risultati della ricerca
        ArrayList<String> isbn = new ArrayList<>();
        ArrayList<String> titoli = new ArrayList<>();
        ArrayList<String> generi = new ArrayList<>();
        ArrayList<LocalDate> dateUscita = new ArrayList<>();
        ArrayList<String> tipoLibri = new ArrayList<>();
        ArrayList<String> editori = new ArrayList<>();
        ArrayList<Boolean> cartaceo = new ArrayList<>();
        ArrayList<Boolean> digitale = new ArrayList<>();
        ArrayList<Boolean> audiolibro = new ArrayList<>();
        try {
            cercaLibri.cercaLibroPerNegozio(idNegozio, isbn, titoli, generi, dateUscita, tipoLibri, editori, cartaceo, digitale, audiolibro);//ricerca dei libri del negozio
        } catch (SQLException ex) {
            ex.printStackTrace();
            return new ArrayList<>(); //ritorna un arraylist vuoto in caso di eccezione
        }
        //per ogni libro trovato, viene creato un oggetto in base al tipo di libro e viene inserito nell'arraylist
        for (int i = 0; i < isbn.size(); i++) {
            if (tipoLibri.get(i).equals("Romanzo")) {
                Romanzo romanzo = new Romanzo(titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), dateUscita.get(i).getYear(), isbn.get(i), dateUscita.get(i).getDayOfMonth(), dateUscita.get(i).getMonthValue(), generi.get(i), null, null);
                libriNegozio.add(romanzo);
            } else {
                LibroDidattico libroDidattico = new LibroDidattico(titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), dateUscita.get(i).getYear(), isbn.get(i), dateUscita.get(i).getDayOfMonth(), dateUscita.get(i).getMonthValue(), generi.get(i));
                libriNegozio.add(libroDidattico);
            }
        }
        return libriNegozio;
    }

    /**
     * Apre la pagina del libro selezionato disponibile nel negozio.
     */
    public void visualizzaTesto() throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader;
        Scene scene = null;
        int indiceTesto = listaTestiDisponibili.getSelectionModel().getSelectedIndex();
        Testo testoSelezionato = negozio.getDisponibili().get(indiceTesto).getLibro();
        //se il libro è un romanzo, apre la pagina per i romanzi, altrimenti apre la pagina per i libri didattici
        if (testoSelezionato instanceof Romanzo) {
            fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaRomanzo.fxml"));
            Parent root = fxmlLoader.load();
            PaginaRomanzoController paginaRomanzo = fxmlLoader.getController();
            paginaRomanzo.preparaPagina((Romanzo) testoSelezionato, utente);
            scene = new Scene(root, 1300, 900);
        } else if (testoSelezionato instanceof LibroDidattico) {
            fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaLibroDidattico.fxml"));
            Parent root = fxmlLoader.load();
            PaginaDidatticoController paginaRomanzo = fxmlLoader.getController();
            paginaRomanzo.preparaPagina((LibroDidattico) testoSelezionato, utente);
            scene = new Scene(root, 1300, 900);
        }
        stage.setTitle(testoSelezionato.getTitolo());
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    /**
     * Sul click del tasto "Modifica", visualizza i campi per modificare le informazioni.
     */
    public void modificaNegozioOnAction() {
        modificaNegozioButton.setVisible(false);
        confermaModifiche.setVisible(true);
        annullaModifiche.setVisible(true);
        modificaSito.setVisible(true);
        modificaSito.setText(negozio.getSito());
        nomeSito.setText("");
        modificaNomeNegozio.setVisible(true);
        modificaNomeNegozio.setText(negozio.getNome());
        nomeNegozioLabel.setText("");
        listaPuntiVendita.getItems().add("+AGGIUNGI PUNTO VENDITA+");
        eliminaButton.setVisible(true);
    }

    /**
     * Sul click del tasto "Conferma", modifica il negozio nel database.
     */
    public void confermaModificheOnAction() {
        //prende il contenuto dei campi
        String nuovoSito = modificaSito.getText();
        String nuovoNome = modificaNomeNegozio.getText();
        //controlla che il nome sia valido, in caso negativo visualizza un messaggio di errore
        if (nuovoNome.isBlank()) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("INSERIRE UN NOME VALIDO");
            return;
        }
        if (nuovoSito != null && nuovoSito.isBlank()) {
            if (negozio.getPuntivendita().isEmpty()) { //impedisce la rimozione del sito nel caso in cui il negozio non abbia punti vendita
                messaggioLabel.setTextFill(Color.web("#FF2E2E"));
                messaggioLabel.setText("PER RIMUOVERE IL SITO, IL NEGOZIO DEVE AVERE ALMENO UN PUNTO VENDITA");
                return;
            }
            nuovoSito = null;
        }
        //controlla che il sito inserito sia valido
        if (nuovoSito != null && !nuovoSito.isBlank() && !nuovoSito.endsWith(".it") && !nuovoSito.endsWith(".com")) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("IL SITO DEVE TERMINARE CON '.it' O '.com'");
            return;
        }
        NegozioDAO modificaNegozio = new NegozioImplementazionePostgresDAO(); //connessione al database
        try {
            modificaNegozio.modificaNegozioDB(negozio.getIdnegozio(), nuovoSito, nuovoNome); //modifica il negozio nel database
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            modificaNegozio.close(); //chiusura della connessione
        }
        //imposta i nuovi dati del negozio
        negozio.setNome(nuovoNome);
        negozio.setSito(nuovoSito);
        resetModificheOnAction(); //reimposta i dati nella pagina
    }

    /**
     * Sul click del tasto "Annulla", nasconde i campi relativi alla modifica.
     */
    public void resetModificheOnAction() {
        modificaNegozioButton.setVisible(true);
        confermaModifiche.setVisible(false);
        annullaModifiche.setVisible(false);
        modificaSito.setVisible(false);
        modificaNomeNegozio.setVisible(false);
        nomeNegozioLabel.setText(negozio.getNome());
        if (negozio.getSito() == null){
            nomeSito.setText("Non Disponibile.");
            nomeSito.setDisable(true);
        } else {
            nomeSito.setText("www." + negozio.getSito());
        }
        messaggioLabel.setText("");
        listaPuntiVendita.getItems().remove("+AGGIUNGI PUNTO VENDITA+");
        eliminaButton.setVisible(false);
    }

    /**
     * Sul click del tasto "Elimina", cancella il negozio della pagina.
     */
    public void eliminaOnAction() {
        NegozioDAO eliminaNegozio = new NegozioImplementazionePostgresDAO();
        try {
            eliminaNegozio.eliminaNegozioDB(negozio.getIdnegozio());
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            eliminaNegozio.close();
        }
        for (Disponibilita disponibilita : negozio.getDisponibili()) {
            disponibilita.setLibro(null);
        }
        Stage stage = (Stage) eliminaButton.getScene().getWindow(); //chiude la pagina
        stage.close();
    }

    /**
     * Apre la pagina per la creazione e l'aggiunta di un punto vendita al negozio.
     */
    public void aggiungiPuntovendita() throws IOException {
        //se viene premuto, nella lista, l'elemento "+AGGIUNGI PUNTO VENDITA+", apre la pagina
        if (!listaPuntiVendita.getSelectionModel().isEmpty() && listaPuntiVendita.getSelectionModel().getSelectedItem().equals("+AGGIUNGI PUNTO VENDITA+")) {
            Stage stage = new Stage();
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AggiungiPuntoVendita.fxml"));
            Parent root = fxmlLoader.load();
            AggiungiPuntoVenditaController aggiungiPuntoVenditaController = fxmlLoader.getController();
            aggiungiPuntoVenditaController.preparaPagina(negozio);
            Scene scene = new Scene(root, 600, 150);
            stage.setTitle("Aggiungi Un Nuovo Punto Vendita Per " + negozio.getNome());
            stage.setScene(scene);
            stage.show();
            stage.setResizable(false);
            Stage chiudiPagina = (Stage) listaPuntiVendita.getScene().getWindow();
            chiudiPagina.close();
        }
    }


}

