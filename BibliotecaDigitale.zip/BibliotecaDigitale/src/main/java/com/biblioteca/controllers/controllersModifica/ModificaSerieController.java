package com.biblioteca.controllers.controllersModifica;

import com.biblioteca.DAO.SerieDAO;
import com.biblioteca.ImplementazioneDAO.SerieImplementazionePostgresDAO;
import com.biblioteca.model.Romanzo;
import com.biblioteca.model.Serie;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Controller dedicato alla gestione della pagina per l'aggiunta e la rimozione della serie dal libro.
 */
public class ModificaSerieController {
    ArrayList<Serie> serieDisponibili = new ArrayList<>();
    @FXML
    private ListView<String> listaSerieDisponibili;
    private Romanzo romanzo;

    public ArrayList<Serie> getSerieDisponibili() {
        return serieDisponibili;
    }

    public void setSerieDisponibili(ArrayList<Serie> serieDisponibili) {
        this.serieDisponibili = serieDisponibili;
    }

    public Romanzo getRomanzo() {
        return romanzo;
    }

    public void setRomanzo(Romanzo romanzo) {
        this.romanzo = romanzo;
    }

    /**
     * Visualizza tutte le serie a cui si può aggiungere il romanzo.
     *
     * @param romanzo Romanzo che verrà aggiunto a una serie.
     */
    public void preparaPagina(Romanzo romanzo) {
        //imposta il romanzo
        setRomanzo(romanzo);
        SerieDAO cercaSerieDisponibili = new SerieImplementazionePostgresDAO(); //connessione al database
        //dichiarazione degli arraylist che conterranno i dati dei risultati
        ArrayList<Integer> idSerie = new ArrayList<>();
        ArrayList<String> nomeSerie = new ArrayList<>();
        ArrayList<Serie> serieTrovate = new ArrayList<>();
        try {
            cercaSerieDisponibili.getAllSerie(idSerie, nomeSerie); //ricerca di tutte le serie nel database
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaSerieDisponibili.close(); //chiusura della connessione
        }
        for (int i = 0; i < idSerie.size(); i++) {
            Serie serie = new Serie(nomeSerie.get(i), idSerie.get(i));
            serieTrovate.add(serie);
        }
        //per ogni serie trovata, la visualizza nella lista
        for (Serie serietrovate : serieTrovate) {
            serieDisponibili.add(serietrovate);
            listaSerieDisponibili.getItems().add(serietrovate.getTitolo());
        }

    }

    /**
     * Aggiunge il libro alla serie selezionata.
     */
    public void aggiungiSerie() {
        if (!listaSerieDisponibili.getSelectionModel().isEmpty()) { //se viene selezionato un elemento valido
            int indiceSerieSelezionata = listaSerieDisponibili.getSelectionModel().getSelectedIndex(); //ottenimento dell'indice della serie selezionata nella lista
            SerieDAO aggiungiLibroASerie = new SerieImplementazionePostgresDAO(); //apertura della connessione con il database
            Serie serieAggiunta = serieDisponibili.get(indiceSerieSelezionata); //ottenimento della serie selezionata
            try {
                aggiungiLibroASerie.aggiungiSerieALibro(romanzo.getIsbn(), serieAggiunta.getIdserie()); //aggiunta del libro alla serie nel database
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                aggiungiLibroASerie.close(); //chiusura della connessione
            }
            serieAggiunta.getLibri().add(romanzo); //aggiunge il libro alla serie
            romanzo.setSerie(serieAggiunta);
            Stage stage = (Stage) listaSerieDisponibili.getScene().getWindow();
            stage.close(); //chiude la pagina
        }
    }

}
