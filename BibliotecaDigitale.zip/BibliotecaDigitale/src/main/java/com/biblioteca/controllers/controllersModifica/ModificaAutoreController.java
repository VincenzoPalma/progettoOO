package com.biblioteca.controllers.controllersModifica;

import com.biblioteca.DAO.AutoreDAO;
import com.biblioteca.ImplementazioneDAO.AutoreImplementazionePostgresDAO;
import com.biblioteca.model.ArticoloScientifico;
import com.biblioteca.model.Autore;
import com.biblioteca.model.Libro;
import com.biblioteca.model.Testo;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Controller dedicato alla gestione della pagina per l'aggiunta e la rimozione di autori dal libro.
 */
public class ModificaAutoreController {

    @FXML
    private ListView<String> listaAutoriInseriti;
    @FXML
    private ListView<String> listaAutoriDisponibili;

    private ArrayList<Autore> autoriDisponibili = new ArrayList<>();
    private Testo testo;

    public ArrayList<Autore> getAutoriDisponibili() {
        return autoriDisponibili;
    }

    public void setAutoriDisponibili(ArrayList<Autore> autoriDisponibili) {
        this.autoriDisponibili = autoriDisponibili;
    }

    public Testo getTesto() {
        return testo;
    }

    public void setTesto(Testo testo) {
        this.testo = testo;
    }

    /**
     * Mostra tutti gli autori disponibili per essere aggiunti al libro, e tutti gli autori attribuiti al libro che possono essere rimossi
     *
     * @param testo Il testo di cui si gestiscono gli autori.
     */
    public void preparaPagina(Testo testo) {
        //imposta il testo
        setTesto(testo);
        //visualizza gli autori già associati al libro
        for (Autore autore : testo.getAutori()) {
            listaAutoriInseriti.getItems().add(autore.getNominativo());
        }
        //dichiarazione degli arraylist che conterranno i risultati
        ArrayList<Integer> idAutori = new ArrayList<>();
        ArrayList<String> nominativoAutori = new ArrayList<>();
        ArrayList<LocalDate> dataNascitaAutori = new ArrayList<>();
        ArrayList<String> istitutoAutori = new ArrayList<>();
        ArrayList<Autore> autori = new ArrayList<>();
        AutoreDAO cercaAutoriDisponibili = new AutoreImplementazionePostgresDAO(); //connessione al database
        try {
            cercaAutoriDisponibili.getAllAutori(idAutori, nominativoAutori, istitutoAutori, dataNascitaAutori); //ricerca degli autori disponibili
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaAutoriDisponibili.close(); //chiusura della connessione
        }
        //per ogni autore trovato, crea un oggetto
        for (int i = 0; i < idAutori.size(); i++) {
            Autore autore = new Autore(idAutori.get(i), nominativoAutori.get(i), istitutoAutori.get(i), dataNascitaAutori.get(i));
            autori.add(autore);
        }
        //per ogni autore trovato, scarta quelli che già sono associati al libro e quelli che sono nati dopo la pubblicazione del libro
        for (Autore autore : autori) {
            if (autore.getDatanascita() == null || (autore.getDatanascita().getYear() < testo.getAnnopubblicazione() && !testo.getAutori().contains(autore))) {
                autoriDisponibili.add(autore);
                listaAutoriDisponibili.getItems().add(autore.getNominativo());
            }
        }
    }

    /**
     * Sul click di uno degli autori associati al testo, lo rimuove da esso, e lo sposta nella lista
     * degli autori disponibili.
     */
    public void rimuoviAutore() {
        if (!listaAutoriInseriti.getSelectionModel().isEmpty()) { //se viene selezionato un elemento valido
            int indiceAutoreSelezionato = listaAutoriInseriti.getSelectionModel().getSelectedIndex(); //ottenimento dell'indice dell'autore selezionato nella lista
            Autore autoreRimosso = testo.getAutori().get(indiceAutoreSelezionato); //ottiene l'autore da rimuovere
            AutoreDAO rimuoviAutore = new AutoreImplementazionePostgresDAO(); //connessione al database
            try {
                if (testo instanceof Libro) { //se il testo da cui rimuovere l'autore è un libro, utilizza la funzione per la rimozione dei libri
                    rimuoviAutore.rimuoviAutoreDaLibro(autoreRimosso.getIdautore(), ((Libro) testo).getIsbn()); //rimozione del libro dall'autore
                } else { //altrimenti utilizza la funzione per la rimozione degli articoli
                    rimuoviAutore.rimuoviAutoreDaArticolo(autoreRimosso.getIdautore(), ((ArticoloScientifico) testo).getIdarticolo()); //rimozione dell'articolo dall'autore
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                rimuoviAutore.close(); //chiusura della connessione
            }
            listaAutoriInseriti.getItems().remove(indiceAutoreSelezionato); //rimozione dell'autore dalla lista degli autori assegnati
            listaAutoriDisponibili.getItems().add(autoreRimosso.getNominativo()); //aggiunta dell'autore nella lista degli autori disponibili
            autoreRimosso.getTesti().remove(testo); //rimozione del testo dall'arraylist di testi scritti dall'autore
            testo.getAutori().remove(indiceAutoreSelezionato); //rimozione dell'autore tra gli autori del testo
            autoriDisponibili.add(autoreRimosso); //aggiunta dell'autore all'arraylist di autori disponibili
        }
    }

    /**
     * Sul click di uno degli autori disponibili, lo aggiunge al testo, e lo sposta nella lista
     * degli autori associati.
     */
    public void aggiungiAutore() {
        if (!listaAutoriDisponibili.getSelectionModel().isEmpty()) { //se viene selezionato un elemento valido
            int indiceAutoreSelezionato = listaAutoriDisponibili.getSelectionModel().getSelectedIndex(); //ottenimento dell'indice dell'autore selezionato nella lista
            Autore autoreAggiunto = autoriDisponibili.get(indiceAutoreSelezionato); //ottiene l'autore da inserire
            AutoreDAO aggiungiAutore = new AutoreImplementazionePostgresDAO(); //connessione al database
            try {
                if (testo instanceof Libro) { //se il testo da cui rimuovere l'autore è un libro, utilizza la funzione per l'aggiunta dei libri
                    aggiungiAutore.aggiungiAutoreALibro(autoreAggiunto.getIdautore(), ((Libro) testo).getIsbn()); //aggiunta del libro all'autore
                } else { //altrimenti utilizza la funzione per l'aggiunta degli articoli
                    aggiungiAutore.aggiungiAutoreAdArticolo(autoreAggiunto.getIdautore(), ((ArticoloScientifico) testo).getIdarticolo()); //aggiunta dell'articolo all'autore
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                aggiungiAutore.close(); //chiusura della connessione
            }
            listaAutoriDisponibili.getItems().remove(indiceAutoreSelezionato); //rimozione dell'autore dalla lista degli autori disponibili
            listaAutoriInseriti.getItems().add(autoreAggiunto.getNominativo()); //aggiunta dell'autore nella lista degli autori assegnati
            autoreAggiunto.getTesti().add(testo); //aggiunta del testo dall'arraylist di testi scritti dall'autore
            testo.getAutori().add(autoreAggiunto); //aggiunta dell'autore tra gli autori del testo
            autoriDisponibili.remove(indiceAutoreSelezionato); //rimozione dell'autore all'arraylist di autori disponibili
        }
    }
}
