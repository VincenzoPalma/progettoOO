package com.biblioteca.controllers.controllersPagine;

import com.biblioteca.DAO.ArticoloScientificoDAO;
import com.biblioteca.DAO.AutoreDAO;
import com.biblioteca.DAO.LibroDAO;
import com.biblioteca.ImplementazioneDAO.ArticoloScientificoImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.AutoreImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.LibroImplementazionePostgresDAO;
import com.biblioteca.bibliotecadigitale.Main;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaArticoloController;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaDidatticoController;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaRomanzoController;
import com.biblioteca.model.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Controller dedicato alla gestione della pagina per gli autori.
 */
public class PaginaAutoreController implements Initializable {
    @FXML
    private Label nomeAutoreLabel;
    @FXML
    private Label dataNascitaLabel;
    @FXML
    private Label istitutoLabel;
    @FXML
    private ListView<String> listaTestiScritti;
    @FXML
    private DatePicker modificaDataNascita;
    @FXML
    private TextField modificaIstituto;
    @FXML
    private Button modificaAutoreButton;
    @FXML
    private Button annullaModifiche;
    @FXML
    private Button confermaModifiche;
    @FXML
    private Label messaggioLabel;
    @FXML
    private Button eliminaButton;
    @FXML
    private ImageView sfondo;


    /**
     * Utente che ha aperto la pagina, utilizzato per
     * decidere se l'utente in questione può o meno modificare i
     * dati della pagina.
     */
    private Utente utente;

    /**
     * Autore di cui si visualizzano le informazioni nella pagina.
     */
    private Autore autore;

    public Autore getAutore() {
        return autore;
    }

    public void setAutore(Autore autore) {
        this.autore = autore;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        File sfondoFile = new File("src/Images/paginaAutore.png");
        Image sfondoImmagine = new Image(sfondoFile.toURI().toString());
        sfondo.setImage(sfondoImmagine);

    }

    /**
     * Imposta le informazioni dell'autore nella pagina.
     *
     * @param autore L'autore di cui si mostrano le informazioni.
     * @param utente L'utente che ha aperto la pagina.
     */
    public void preparaPagina(Autore autore, Utente utente) {
        //assegna l'autore, il testo e l'utente agli attributi del controller
        setAutore(autore);
        setUtente(utente);
        //imposta i label che compongono la pagina in base al contenuto dell'oggetto autore
        nomeAutoreLabel.setText(autore.getNominativo());
        setInformazioniAutore(); //imposta le informazioni dell'autore sulla pagina
        autore.setTesti(cercaTestiPerAutore(autore.getIdautore())); //cerca i testi scritti dall'autore e li assegna all'arraylist di testi dell'autore
        //visualizza i testi scritti dall'autore
        for (Testo testoAttuale : autore.getTesti()) {
            if (testoAttuale instanceof Romanzo) {
                listaTestiScritti.getItems().add(testoAttuale.getTitolo() + " | Romanzo");
            } else if (testoAttuale instanceof LibroDidattico) {
                listaTestiScritti.getItems().add(testoAttuale.getTitolo() + " | Didattico");
            } else {
                listaTestiScritti.getItems().add(testoAttuale.getTitolo() + " | Articolo");
            }
        }
        //visualizza i bottoni di modifica se l'utente è amministratore
        if (utente.getTipo().equals("Amministratore")) {
            modificaAutoreButton.setVisible(true);
            modificaAutoreButton.setDisable(false);
        }
    }


    /**
     * Sul click di un libro, chiama una nuova finestra che
     * conterrà le informazioni di quel libro, le informazioni mostrate dalla finestra
     * dipenderanno dal tipo di libro.
     * <p>
     * Passa l'oggetto del libro selezionato e il tipo di utente al controller della schermata che chiama.
     *
     * @see PaginaRomanzoController
     * @see PaginaDidatticoController
     */
    public void visualizzaTesto() throws IOException {
        try {
            Stage stage = new Stage();
            FXMLLoader fxmlLoader;
            Scene scene = null;
            int indiceTesto = listaTestiScritti.getSelectionModel().getSelectedIndex(); //ottiene l'indice del testo selezionato nella lista di testi visualizzati
            Testo testoSelezionato = autore.getTesti().get(indiceTesto); //ottiene il testo selezionato dall'autore tramite l'indice ottenuto in precedenza
            if (testoSelezionato instanceof Romanzo) {
                //se il testo selezionato è un romanzo, prepara e apre la pagina per i romanzi
                fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaRomanzo.fxml"));
                Parent root = fxmlLoader.load();
                PaginaRomanzoController paginaRomanzo = fxmlLoader.getController();
                paginaRomanzo.preparaPagina((Romanzo) testoSelezionato, utente);
                scene = new Scene(root, 1300, 900);
            } else if (testoSelezionato instanceof LibroDidattico) {
                //se il testo selezionato è un libro didattico, prepara e apre la pagina per i libri didattici
                fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaLibroDidattico.fxml"));
                Parent root = fxmlLoader.load();
                PaginaDidatticoController paginaRomanzo = fxmlLoader.getController();
                paginaRomanzo.preparaPagina((LibroDidattico) testoSelezionato, utente);
                scene = new Scene(root, 1300, 900);
            } else {
                //se il testo selezionato è un articolo, prepara e apre la pagina per gli articoli
                fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaArticolo.fxml"));
                Parent root = fxmlLoader.load();
                PaginaArticoloController paginaArticolo = fxmlLoader.getController();
                paginaArticolo.preparaPagina((ArticoloScientifico) testoSelezionato, utente);
                scene = new Scene(root, 1300, 900);
            }
            stage.setTitle(testoSelezionato.getTitolo());
            stage.setScene(scene);
            stage.show();
            stage.setResizable(false);
        } catch (IndexOutOfBoundsException ignored) {
        } //se viene cliccato uno spazio vuoto, ignora l'eccezione lanciata
    }

    /**
     * Cerca nel database, i testi scritti dall'autore della pagina tramite varie classi DAO.
     *
     * @param idautore L'id dell'autore di cui si vogliono ottenere i testi.
     * @return Un ArrayList di oggetti di tipo Testo.
     */
    public ArrayList<Testo> cercaTestiPerAutore(int idautore) {
        ArrayList<Libro> libriAutore = cercaLibriAutore(idautore); //cerca i libri dell'autore
        ArrayList<ArticoloScientifico> articoliScientifici = cercaArticoliScientificiAutore(idautore);
        ArrayList<Testo> testi = new ArrayList<>();
        //aggiunge a un array list di testi tutti i risultati ottenuti dalle ricerche nel database
        testi.addAll(libriAutore);
        testi.addAll(articoliScientifici);
        return testi;
    }

    /**
     * Cerca i libri scritti dall'autore con id uguale a quello passato
     * come parametro nel database. Ritorna un arraylist di libri trovati, sia didattici che romanzi.
     *
     * @param idAutore L'id dell'autore di cui si vogliono ottenere i libri.
     * @return Un arraylist di oggetti di tipo Libro.
     */
    public ArrayList<Libro> cercaLibriAutore(int idAutore) {
        LibroDAO cercaLibri = new LibroImplementazionePostgresDAO(); //connessione al database
        ArrayList<Libro> libriAutore = new ArrayList<>(); //arraylist dei libri scritti dall'autore
        //dichiarazione degli arraylist che conterranno le informazioni dei risultati della ricerca
        ArrayList<String> isbn = new ArrayList<>();
        ArrayList<String> titoli = new ArrayList<>();
        ArrayList<String> generi = new ArrayList<>();
        ArrayList<LocalDate> dateUscita = new ArrayList<>();
        ArrayList<String> tipoLibri = new ArrayList<>();
        ArrayList<String> editori = new ArrayList<>();
        ArrayList<Boolean> cartaceo = new ArrayList<>();
        ArrayList<Boolean> digitale = new ArrayList<>();
        ArrayList<Boolean> audiolibro = new ArrayList<>();
        try {
            cercaLibri.cercaLibriPerAutore(idAutore, isbn, titoli, generi, dateUscita, tipoLibri, editori, cartaceo, digitale, audiolibro);//ricerca dei libri scritti dall'autore
        } catch (SQLException ex) {
            ex.printStackTrace();
            return new ArrayList<>(); //ritorna un arraylist vuoto in caso di eccezione
        }
        //per ogni libro trovato, viene creato un oggetto in base al tipo di libro e viene inserito nell'arraylist
        for (int i = 0; i < isbn.size(); i++) {
            if (tipoLibri.get(i).equals("Romanzo")) {
                Romanzo romanzo = new Romanzo(titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), dateUscita.get(i).getYear(), isbn.get(i), dateUscita.get(i).getDayOfMonth(), dateUscita.get(i).getMonthValue(), generi.get(i), null, null);
                libriAutore.add(romanzo);
            } else {
                LibroDidattico libroDidattico = new LibroDidattico(titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), dateUscita.get(i).getYear(), isbn.get(i), dateUscita.get(i).getDayOfMonth(), dateUscita.get(i).getMonthValue(), generi.get(i));
                libriAutore.add(libroDidattico);
            }
        }
        return libriAutore;
    }

    /**
     * Cerca gli articoli scritti dall'autore con id uguale a quello passato
     * come parametro nel database. Ritorna un arraylist di articoli trovati.
     *
     * @param idAutore L'id dell'autore di cui si vogliono ottenere gli articoli.
     * @return Un arraylist di oggetti di tipo ArticoloScientifico.
     */
    public ArrayList<ArticoloScientifico> cercaArticoliScientificiAutore(int idAutore) {
        //creazione degli arraylist che conterranno le informazioni dei risultati dell'interrogazione
        ArrayList<String> titoli = new ArrayList<>();
        ArrayList<String> argomenti = new ArrayList<>();
        ArrayList<String> temi = new ArrayList<>();
        ArrayList<Integer> annoPubblicazione = new ArrayList<>();
        ArrayList<Integer> idArticoli = new ArrayList<>();
        ArrayList<String> editori = new ArrayList<>();
        ArrayList<Boolean> cartaceo = new ArrayList<>();
        ArrayList<Boolean> digitale = new ArrayList<>();
        ArrayList<Boolean> audiolibro = new ArrayList<>();
        //apre la connessione col database
        ArticoloScientificoDAO ricercaArticoliScientifici = new ArticoloScientificoImplementazionePostgresDAO();
        ArrayList<ArticoloScientifico> risultatiArticoli = new ArrayList<>();
        try {
            ricercaArticoliScientifici.cercaArticoloPerAutore(idAutore, idArticoli, titoli, temi, argomenti, annoPubblicazione, editori, cartaceo, digitale, audiolibro); //esegue la ricerca per gli articoli nel database
        } catch (SQLException ex) {
            ex.printStackTrace();
            return new ArrayList<>(); //ritorna un arraylist vuoto in caso di eccezione
        } finally {
            ricercaArticoliScientifici.close(); //chiusura della connessione al database
        }
        for (int i = 0; i < idArticoli.size(); i++) {
            //per ogni articolo trovato, crea il relativo oggetto e lo aggiunge all'arraylist
            ArticoloScientifico articoloScientificoTrovato = new ArticoloScientifico(idArticoli.get(i), titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), annoPubblicazione.get(i), temi.get(i), argomenti.get(i), null, null);
            risultatiArticoli.add(articoloScientificoTrovato);
        }
        return risultatiArticoli;
    }

    /**
     * Sul click del tasto "Modifica", visualizza gli elementi per poter modificare
     * le informazioni dell'autore.
     */
    public void modificaAutoreOnAction() {
        dataNascitaLabel.setText("");
        modificaDataNascita.setVisible(true);
        modificaDataNascita.setValue(autore.getDatanascita());
        istitutoLabel.setText("");
        modificaIstituto.setVisible(true);
        modificaIstituto.setText(autore.getIstituto());
        modificaAutoreButton.setVisible(false);
        confermaModifiche.setVisible(true);
        annullaModifiche.setVisible(true);
        eliminaButton.setVisible(true);
    }

    /**
     * Imposta le informazioni dell'autore nella pagina.
     */
    public void setInformazioniAutore() {
        nomeAutoreLabel.setText(autore.getNominativo());
        if (autore.getDatanascita() == null) {
            dataNascitaLabel.setText("N/A");
        } else {
            dataNascitaLabel.setText(autore.getDatanascita().toString());
        }
        String istituto = autore.getIstituto();
        if (istituto != null) {
            istitutoLabel.setText(istituto);
        } else {
            istitutoLabel.setText("Nessun istituto.");
        }
    }

    /**
     * Sul click del tasto "annulla" reimposta le informazioni dell'autore.
     */
    public void resetModificheOnAction() {
        setInformazioniAutore();
        modificaAutoreButton.setVisible(true);
        confermaModifiche.setVisible(false);
        annullaModifiche.setVisible(false);
        modificaDataNascita.setVisible(false);
        modificaIstituto.setVisible(false);
        eliminaButton.setVisible(false);
        messaggioLabel.setText("");
    }

    /**
     * Sul click del tasto "conferma" prende il contenuto dei campi di modifica,
     * controlla la loro validità, e modifica l'autore nel database.
     */
    public void confermaModificheOnAction() {
        //prende il contenuto dei campi
        String nuovoIstituto = modificaIstituto.getText();
        LocalDate nuovaDataNascita = modificaDataNascita.getValue();
        //per ogni testo dell'autore, verifica il testo sia stato pubblicato dopo la nascita dell'autore, in caso negativo visualizza un messaggio di errore
        if (nuovaDataNascita != null) {
            for (Testo testo : autore.getTesti()) {
                if (testo instanceof ArticoloScientifico) {
                    if (nuovaDataNascita.getYear() > testo.getAnnopubblicazione()) {
                        messaggioLabel.setText("L'ANNO DI NASCITA INSERITO E' ANTECEDENTE AD UNA SUA PUBBLICAZIONE");
                        messaggioLabel.setTextFill(Color.web("#FF2E2E"));
                        return;
                    }
                } else {
                    if (nuovaDataNascita.isAfter(LocalDate.of(testo.getAnnopubblicazione(), ((Libro) testo).getMesepubblicazione(), ((Libro) testo).getGiornopubblicazione()))) {
                        messaggioLabel.setText("LA DATA DI NASCITA INSERITA E' ANTECEDENTE AD UN SUO TESTO PUBBLICATO");
                        messaggioLabel.setTextFill(Color.web("#FF2E2E"));
                        return;
                    }
                }
            }
        }
        AutoreDAO modificaAutore = new AutoreImplementazionePostgresDAO(); //apertura della connessione
        //se l'istituto non è stato inserito, viene posto a null
        if (nuovoIstituto == null || nuovoIstituto.isBlank()) {
            nuovoIstituto = null;
        }
        try {
            modificaAutore.modificaAutoreDB(autore.getIdautore(), autore.getNominativo(), nuovoIstituto, nuovaDataNascita); //esegue la modifica nel database
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            modificaAutore.close(); //chiude la connessione
        }
        autore.setIstituto(nuovoIstituto);
        autore.setDatanascita(nuovaDataNascita);
        resetModificheOnAction(); //reimposta le informazioni nella pagina
    }

    /**
     * Sul click del tasto "Elimina", cancella l'autore della pagina.
     */
    public void eliminaOnAction() {
        AutoreDAO eliminaAutore = new AutoreImplementazionePostgresDAO();
        try {
            eliminaAutore.eliminaAutoreDB(autore.getIdautore());
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            eliminaAutore.close();
        }
        autore.setTesti(null);
        Stage stage = (Stage) eliminaButton.getScene().getWindow(); //chiude la pagina
        stage.close();
    }

}
