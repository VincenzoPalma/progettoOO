package com.biblioteca.controllers.controllersModifica;

import com.biblioteca.DAO.EsposizioneDAO;
import com.biblioteca.DAO.SalaDAO;
import com.biblioteca.ImplementazioneDAO.EsposizioneImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.SalaImplementazionePostgresDAO;
import com.biblioteca.model.Esposizione;
import com.biblioteca.model.Libro;
import com.biblioteca.model.Sala;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.paint.Color;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Controller dedicato alla gestione della pagina per l'aggiunta e la rimozione di esposizioni in sale dal libro.
 */
public class ModificaSaleController {
    @FXML
    private ListView<String> listaSaleInserite;
    @FXML
    private ListView<String> listaSaleDisponibili;
    @FXML
    private DatePicker dataEsposizione;
    @FXML
    private Label messaggioLabel;
    private ArrayList<Sala> saleDisponibili = new ArrayList<>();
    private Libro libro;

    public ArrayList<Sala> getSaleDisponibili() {
        return saleDisponibili;
    }

    public void setSaleDisponibili(ArrayList<Sala> saleDisponibili) {
        this.saleDisponibili = saleDisponibili;
    }

    public Libro getLibro() {
        return libro;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }

    public void preparaPagina(Libro libro) {
        //imposta il libro
        setLibro(libro);
        //visualizza le esposizioni in sale già associate al libro
        for (Esposizione esposizione : libro.getEsposizioni()) {
            listaSaleInserite.getItems().add(esposizione.getSala().getNome() + " | " + esposizione.getData());
        }
        //dichiarazione degli arraylist che conterranno i dati del risultato della ricerca delle sale
        ArrayList<Integer> idSale = new ArrayList<>();
        ArrayList<String> nomeSale = new ArrayList<>();
        ArrayList<String> indirizzoSale = new ArrayList<>();
        ArrayList<Integer> capienzaSale = new ArrayList<>();
        ArrayList<Sala> sale = new ArrayList<>();
        SalaDAO cercaSaleDisponibili = new SalaImplementazionePostgresDAO(); //connessione al database
        try {
            cercaSaleDisponibili.getAllSale(idSale, nomeSale, indirizzoSale, capienzaSale); //ricerca delle sale
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaSaleDisponibili.close(); //chiusura della connessione
        }
        //per ogni sala trovata crea il relativo oggetto
        for (int i = 0; i < idSale.size(); i++) {
            Sala sala = new Sala(idSale.get(i), nomeSale.get(i), indirizzoSale.get(i), capienzaSale.get(i));
            sale.add(sala);
        }
        setSaleDisponibili(sale); //imposta le sale disponibili
        //per ogni sala disponibile, la visualizza nella lista delle sale disponibili
        for (Sala sala : saleDisponibili) {
            listaSaleDisponibili.getItems().add(sala.getNome() + " | " + sala.getIndirizzo());
        }
    }

    /**
     * Sul click di una delle sale associate al libro, lo rimuove da essa, e lo sposta nella lista
     * delle sale disponibili.
     */
    public void rimuoviEsposizione() {
        if (!listaSaleInserite.getSelectionModel().isEmpty()) { //se viene selezionato un elemento valido
            int indiceSalaSelezionata = listaSaleInserite.getSelectionModel().getSelectedIndex(); //ottiene l'indice della sala selezionata
            Sala salaRimossa = libro.getEsposizioni().get(indiceSalaSelezionata).getSala(); //ottiene la sala da rimuovere
            EsposizioneDAO rimuoviEsposizione = new EsposizioneImplementazionePostgresDAO(); //connessione al database
            try {
                rimuoviEsposizione.eliminaEsposizioneDB(libro.getIsbn(), salaRimossa.getIdsala()); //rimozione del libro dalla sala
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                rimuoviEsposizione.close(); //chiusura della connessione
            }
            //rimuove l'esposizione dal libro e dalla sala
            libro.getEsposizioni().remove(indiceSalaSelezionata);
            salaRimossa.getEsposizioni().removeIf(esposizione -> esposizione.getLibro().equals(libro));
            listaSaleInserite.getItems().remove(indiceSalaSelezionata); //rimuove l'esposizione dalla lista delle esposizioni del libro
        }
    }


    /**
     * Sul click di una delle sale disponibili, la aggiunge al libro, e la sposta nella lista
     * delle sale in cui è stato esposto il libro.
     */
    public void aggiungiSala() {
        if (!listaSaleDisponibili.getSelectionModel().isEmpty()) { //se viene selezionato un elemento valido
            int indiceSalaSelezionata = listaSaleDisponibili.getSelectionModel().getSelectedIndex(); //ottiene l'indice della sala selezionata
            //ottiene la data dell'esposizione da inserire e ne verifica la validità
            LocalDate dataEsposizioneValue = dataEsposizione.getValue();
            if (dataEsposizioneValue == null) {
                messaggioLabel.setTextFill(Color.web("#FF2E2E"));
                messaggioLabel.setText("INSERIRE UNA DATA PER L'AGGIUNTA");
                return;
            }
            Esposizione esposizioneAggiunta = new Esposizione(dataEsposizioneValue, libro, saleDisponibili.get(indiceSalaSelezionata)); //creazione della nuova esposizione
            EsposizioneDAO aggiungiEsposizione = new EsposizioneImplementazionePostgresDAO(); //connessione al database
            try {
                aggiungiEsposizione.aggiungiEsposizioneDB(esposizioneAggiunta.getSala().getIdsala(), libro.getIsbn(), dataEsposizioneValue); //inserimento dell'esposizione nel database
            } catch (SQLException ex) {
                //nel caso in cui viene inserita una esposizione per il libro, in una stessa sala, nello stesso giorno
                messaggioLabel.setText("NON POSSONO ESISTERE DUE PRESENTAZIONI NELLA STESSA SALA E NELLO STESSO GIORNO");
                messaggioLabel.setTextFill(Color.web("#FF2E2E"));
                return;
            } finally {
                aggiungiEsposizione.close(); //chiusura della connessione
            }
            listaSaleInserite.getItems().add(esposizioneAggiunta.getSala().getNome() + " | " + esposizioneAggiunta.getData()); //inserimento dell'esposizione nella lista delle esposizioni del libro
            libro.getEsposizioni().add(esposizioneAggiunta); //aggiunta dell'esposizione al libro
            esposizioneAggiunta.getSala().getEsposizioni().add(esposizioneAggiunta); //aggiunta dell'esposizione alla sala
            messaggioLabel.setText(""); //reset del messaggio di errore
            dataEsposizione.setValue(null); //reset del campo per la data
        }
    }

}

