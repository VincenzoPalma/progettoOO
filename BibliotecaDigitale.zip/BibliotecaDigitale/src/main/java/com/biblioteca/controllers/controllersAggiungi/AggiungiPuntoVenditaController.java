package com.biblioteca.controllers.controllersAggiungi;

import com.biblioteca.DAO.PuntoVenditaDAO;
import com.biblioteca.ImplementazioneDAO.PuntoVenditaImplementazionePostgresDAO;
import com.biblioteca.model.Negozio;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

import java.sql.SQLException;

/**
 * Controller dedicato alla gestione della pagina per l'inserimento di punti vendita.
 */
public class AggiungiPuntoVenditaController {
    @FXML
    private TextField nomePuntoVenditaField;
    @FXML
    private TextField nomeCittaField;
    @FXML
    private Label messaggioLabel;
    /**
     * Negozio a cui si attribuirà il punto vendita che verrà creato
     */
    private Negozio negozio;

    public Negozio getNegozio() {
        return negozio;
    }

    public void setNegozio(Negozio negozio) {
        this.negozio = negozio;
    }

    /**
     * Ottiene il negozio dal controller che chiama la pagina d'inserimento
     * di punti vendita, e lo imposta.
     *
     * @param negozio Il negozio a cui si vuole aggiungere un punto vendita
     */
    public void preparaPagina(Negozio negozio) {
        setNegozio(negozio);
    }

    /**
     * Sul click del tasto "Conferma", ottiene il contenuto dei campi, ne verifica la validità, e inserisce un punto vendita
     * per quel negozio con quei valori nel database.
     */
    public void confermaOnAction() {
        messaggioLabel.setTextFill(Color.web("#FF2E2E")); //imposta il messaggio in rosso, nell'eventualità di un errore
        //ottiene il contenuto dei campi
        String nomePuntovendita = nomePuntoVenditaField.getText();
        String citta = nomeCittaField.getText();
        //controlla che il nome sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (nomePuntovendita.isBlank()) {
            messaggioLabel.setText("ERRORE: AGGIUNGERE UN NOME");
            return;
        }
        //controlla che il nome della città sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (citta.isBlank()) {
            messaggioLabel.setText("ERRORE: AGGIUNGERE UNA CITTA'");
            return;
        }
        PuntoVenditaDAO aggiungiPuntoVendita = new PuntoVenditaImplementazionePostgresDAO(); //apertura della connessione col database
        try {
            aggiungiPuntoVendita.aggiungiPuntoVenditaDB(citta, nomePuntovendita, negozio.getIdnegozio()); //inserimento del nuovo punto vendita, e attribuzione al relativo negozio
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            aggiungiPuntoVendita.close(); //chiusura della connessione col database
        }
        //messaggio di avvenuto inserimento in verde
        messaggioLabel.setTextFill(Color.web("#00A300"));
        messaggioLabel.setText("PUNTO VENDITA AGGIUNTO");
        //pulizia dei campi dopo l'inserimento
        nomePuntoVenditaField.clear();
        nomeCittaField.clear();
    }
}
