package com.biblioteca.controllers.controllersAggiungi;

import com.biblioteca.DAO.ArticoloScientificoDAO;
import com.biblioteca.DAO.ConferenzaDAO;
import com.biblioteca.DAO.RivistaDAO;
import com.biblioteca.ImplementazioneDAO.ArticoloScientificoImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.ConferenzaImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.RivistaImplementazionePostgresDAO;
import com.biblioteca.model.Conferenza;
import com.biblioteca.model.Rivista;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Controller dedicato alla gestione della pagina per l'inserimento di articoli scientifici.
 */
public class AggiungiArticoloScientificoController {
    @FXML
    private TextField argomentoField;
    @FXML
    private TextField nomeArticoloField;
    @FXML
    private TextField annoPubblicazioneField;
    @FXML
    private TextField editoreField;
    @FXML
    private TextField temaField;
    /**
     * Lista delle riviste a cui può essere aggiunto l'articolo che si sta per inserire
     */
    @FXML
    private ListView<String> listaRivisteDisponibili;
    /**
     * Lista delle conferenze a cui può essere aggiunto l'articolo che si sta per inserire
     */
    @FXML
    private ListView<String> listaConferenzeDisponibili;
    @FXML
    private RadioButton checkDigitale;
    @FXML
    private RadioButton checkAudiolibro;
    @FXML
    private RadioButton checkCartaceo;
    @FXML
    private Label messaggioLabel;

    /**
     * ArrayList contenente gli oggetti di tipo Rivista relativi alle riviste a cui può essere aggiunto l'articolo
     * che si sta per inserire.
     */
    private ArrayList<Rivista> rivisteDisponibili = new ArrayList<>();

    /**
     * ArrayList contenente gli oggetti di tipo Conferenza relativi alle conferenze a cui può essere aggiunto l'articolo
     * che si sta per inserire.
     */
    private ArrayList<Conferenza> conferenzeDisponibili = new ArrayList<>();

    public ArrayList<Rivista> getRivisteDisponibili() {
        return rivisteDisponibili;
    }

    public void setRivisteDisponibili(ArrayList<Rivista> rivisteDisponibili) {
        this.rivisteDisponibili = rivisteDisponibili;
    }

    public ArrayList<Conferenza> getConferenzeDisponibili() {
        return conferenzeDisponibili;
    }

    public void setConferenzeDisponibili(ArrayList<Conferenza> conferenzeDisponibili) {
        this.conferenzeDisponibili = conferenzeDisponibili;
    }

    /**
     * Prepara la pagina d'inserimento di un articolo andando a visualizzare una lista
     * di riviste e una di conferenze ottenute da una ricerca nel database tramite {@link RivistaImplementazionePostgresDAO} e
     * {@link ConferenzaImplementazionePostgresDAO}.
     */
    public void preparaPagina() {
        //apertura connessione col database
        RivistaDAO cercaRiviste = new RivistaImplementazionePostgresDAO();
        ConferenzaDAO cercaConferenze = new ConferenzaImplementazionePostgresDAO();
        //creazione degli arraylist che conterranno le informazioni delle riviste trovate
        ArrayList<String> issnRiviste = new ArrayList<>();
        ArrayList<String> nomiRiviste = new ArrayList<>();
        ArrayList<Integer> numeriRiviste = new ArrayList<>();
        ArrayList<String> temiRiviste = new ArrayList<>();
        ArrayList<Integer> anniRiviste = new ArrayList<>();
        ArrayList<String> responsabiliRiviste = new ArrayList<>();
        //creazione degli arraylist che conterranno le informazioni delle conferenze trovate
        ArrayList<Integer> idConferenze = new ArrayList<>();
        ArrayList<String> cittaConferenze = new ArrayList<>();
        ArrayList<String> struttureConferenze = new ArrayList<>();
        ArrayList<LocalDate> dateInizioConferenze = new ArrayList<>();
        ArrayList<LocalDate> dateFineConferenze = new ArrayList<>();
        ArrayList<String> responsabileConferenza = new ArrayList<>();
        try {
            cercaRiviste.getAllRivisteDB(issnRiviste, nomiRiviste, numeriRiviste, temiRiviste, anniRiviste, responsabiliRiviste); //ricerca delle riviste
            cercaConferenze.getAllConferenzeDB(idConferenze, cittaConferenze, struttureConferenze, dateInizioConferenze, dateFineConferenze, responsabileConferenza); //ricerca delle conferenze
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            cercaConferenze.close(); //chiusura della connessione al database
        }
        //per ogni rivista trovata, crea un oggetto e lo aggiunge all'arraylist delle riviste disponibili
        for (int i = 0; i < issnRiviste.size(); i++) {
            Rivista rivista = new Rivista(issnRiviste.get(i), nomiRiviste.get(i), temiRiviste.get(i), anniRiviste.get(i), responsabiliRiviste.get(i), numeriRiviste.get(i));
            rivisteDisponibili.add(rivista);
        }
        //per ogni conferenza trovata, crea un oggetto e lo aggiunge all'arraylist delle conferenze disponibili
        for (int i = 0; i < idConferenze.size(); i++) {
            Conferenza conferenza = new Conferenza(idConferenze.get(i), cittaConferenze.get(i), struttureConferenze.get(i), dateInizioConferenze.get(i), dateFineConferenze.get(i), responsabileConferenza.get(i));
            conferenzeDisponibili.add(conferenza);
        }
        //per ogni rivista trovata, visualizza il nome, il numero, il tema e l'anno di pubblicazione
        for (Rivista rivista : rivisteDisponibili) {
            listaRivisteDisponibili.getItems().add(rivista.getNome() + " | n° " + rivista.getNumero() + " | " + rivista.getTema() + " | " + rivista.getAnno());
        }
        //per ogni conferenza trovata, visualizza la struttura, la città e la data d'inizio
        for (Conferenza conferenza : conferenzeDisponibili) {
            listaConferenzeDisponibili.getItems().add(conferenza.getStruttura() + " | " + conferenza.getCitta() + " | " + conferenza.getDatainizio());
        }
    }

    /**
     * Sul click del tasto "conferma", ottiene il contenuto dei campi, controlla la loro validità
     * e inserisce nel database un nuovo articolo con gli attributi inseriti tramite {@link ArticoloScientificoImplementazionePostgresDAO}.
     */
    public void confermaOnAction() {
        //ottiene il contenuto di tutti i campi e radiobutton
        String titolo = nomeArticoloField.getText();
        String editore = editoreField.getText();
        String tema = temaField.getText();
        String argomento = argomentoField.getText();
        Boolean digitale = checkDigitale.isSelected();
        Boolean cartaceo = checkCartaceo.isSelected();
        Boolean audiolibro = checkAudiolibro.isSelected();
        int annopubblicazione;
        //controlla che il contenuto dei campi sia valido
        try {
            checkDati(titolo, tema, editore, argomento, cartaceo, digitale);
        } catch (IllegalArgumentException ex) {
            return;
        }
        /* converte la stringa nel campo per l'anno di pubblicazione in un intero,
        la conversione non riesce, manda un messaggio di errore
         */
        try {
            annopubblicazione = Integer.parseInt(annoPubblicazioneField.getText());
        } catch (NumberFormatException ex) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("INSERIRE UN ANNO VALIDO");
            return;
        }
        //ottiene gli indici degli elementi selezionati nelle liste delle riviste e delle conferenze
        int indiceConferenzaScelta = listaConferenzeDisponibili.getSelectionModel().getSelectedIndex();
        int indiceRivistaScelta = listaRivisteDisponibili.getSelectionModel().getSelectedIndex();
        Rivista rivistaSelezionata = null;
        Conferenza conferenzaSelezionata = null;
        try {
            //se l'indice dell'elemento selezionato nelle riviste e nelle conferenze è uguale a -1, ovvero non è stato selezionato alcun elemento, manda un messaggio di errore in rosso
            if (indiceRivistaScelta == -1 && indiceConferenzaScelta == -1) {
                messaggioLabel.setTextFill(Color.web("#FF2E2E"));
                messaggioLabel.setText("SCEGLIERE UNA RIVISTA O UNA CONFERENZA");
                return;
            } else if (indiceRivistaScelta != -1 && indiceConferenzaScelta == -1) { //se è stata selezionata solo la rivista
                rivistaSelezionata = rivisteDisponibili.get(indiceRivistaScelta); //ottenimento della rivista selezionata
                controlloRivistaSelezionata(rivistaSelezionata, tema, annopubblicazione); //controllo della coerenza tra i dati della rivista selezionata e i dati del nuovo articolo
            } else if (indiceRivistaScelta == -1) { //se è stata selezionata solo la conferenza
                conferenzaSelezionata = conferenzeDisponibili.get(indiceConferenzaScelta); //ottenimento della conferenza selezionata
                controlloConferenzaSelezionata(conferenzaSelezionata, annopubblicazione); //controllo della coerenza tra i dati della conferenza selezionata e i dati del nuovo articolo
            } else { //se è stata selezionata una rivista e una conferenza
                rivistaSelezionata = rivisteDisponibili.get(indiceRivistaScelta); //ottenimento della rivista selezionata
                controlloRivistaSelezionata(rivistaSelezionata, tema, annopubblicazione); //controllo della coerenza tra i dati della rivista selezionata e i dati del nuovo articolo
                conferenzaSelezionata = conferenzeDisponibili.get(indiceConferenzaScelta); //ottenimento della conferenza selezionata
                controlloConferenzaSelezionata(conferenzaSelezionata, annopubblicazione); //controllo della coerenza tra i dati della conferenza selezionata e i dati del nuovo articolo
            }
        } catch (IllegalArgumentException ex) {
            return;
        }
        ArticoloScientificoDAO inserimentoArticolo = new ArticoloScientificoImplementazionePostgresDAO(); //apertura della connessione col database
        try {
            //inserimento dell'articolo nel database, con o senza rivista e/o conferenza in base alle selezioni dell'amministratore
            if (rivistaSelezionata == null) {
                inserimentoArticolo.aggiungiArticoloScientificoDB(titolo, tema, argomento, annopubblicazione, editore, cartaceo, digitale, audiolibro, null, null, conferenzaSelezionata.getIdconferenza());
            } else if (conferenzaSelezionata == null) {
                inserimentoArticolo.aggiungiArticoloScientificoDB(titolo, tema, argomento, annopubblicazione, editore, cartaceo, digitale, audiolibro, rivistaSelezionata.getIssn(), rivistaSelezionata.getNumero(), null);
            } else {
                inserimentoArticolo.aggiungiArticoloScientificoDB(titolo, tema, argomento, annopubblicazione, editore, cartaceo, digitale, audiolibro, rivistaSelezionata.getIssn(), rivistaSelezionata.getNumero(), conferenzaSelezionata.getIdconferenza());
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            inserimentoArticolo.close(); //chiusura della connessione col database
        }
        //messaggio di riuscito inserimento
        messaggioLabel.setTextFill(Color.web("#00A300"));
        messaggioLabel.setText("ARTICOLO INSERITO");
        resetCampi(); //pulisce i campi
    }

    /**
     * Controlla che i dati inseriti nei vari campi siano validi.
     *
     * @param titolo    Il titolo inserito
     * @param tema      Il tema inserito
     * @param editore   Il nome dell'editore inserito
     * @param argomento L'argomento inserito
     * @param cartaceo  Il valore del radiobutton del campo "cartaceo"
     * @param digitale  Il valore del radiobutton del campo "digitale"
     * @throws IllegalArgumentException Eccezione lanciata quando il contenuto di un campo non è valido
     */
    public void checkDati(String titolo, String tema, String editore, String argomento, Boolean cartaceo, Boolean digitale) throws IllegalArgumentException {
        messaggioLabel.setTextFill(Color.web("#FF2E2E")); //imposta il messaggio di errore in rosso
        //se non è stato inserito un titolo, o se contiene solo spazi, visualizza un messaggio di errore
        if (titolo.isBlank()) {
            messaggioLabel.setText("INSERIRE UN TITOLO VALIDO");
            throw new IllegalArgumentException();
        }
        //se non è stato inserito un tema, o se contiene solo spazi, visualizza un messaggio di errore
        if (tema.isBlank()) {
            messaggioLabel.setText("INSERIRE UN TEMA VALIDO");
            throw new IllegalArgumentException();
        }
        //se non è stato inserito un editore, o se contiene solo spazi, visualizza un messaggio di errore
        if (editore.isBlank()) {
            messaggioLabel.setText("INSERIRE UN EDITORE VALIDO");
            throw new IllegalArgumentException();
        }
        //se non è stato inserito un argomento, o se contiene solo spazi, visualizza un messaggio di errore
        if (argomento.isBlank()) {
            messaggioLabel.setText("INSERIRE UN ARGOMENTO VALIDO");
            throw new IllegalArgumentException();
        }
        //se non è stato scelto un formato tra cartaceo e digitale, visualizza un messaggio di errore
        if (!digitale && !cartaceo) {
            messaggioLabel.setText("INSERIRE UN FORMATO TRA 'CARTACEO' E 'DIGITALE'");
            throw new IllegalArgumentException();
        }
    }

    /**
     * Controlla che il tema e l'anno di pubblicazione del nuovo articolo e quello della rivista selezionata coincidano.
     *
     * @param rivistaSelezionata Oggetto che contiene i dati della rivista selezionata
     * @param tema               Il tema inserito del nuovo articolo
     * @param annopubblicazione  L'anno di pubblicazione inserito del nuovo articolo
     * @throws IllegalArgumentException Eccezione lanciata quando una delle informazioni confrontate tra il nuovo articolo e la rivista selezionata non coincidono.
     */
    public void controlloRivistaSelezionata(Rivista rivistaSelezionata, String tema, int annopubblicazione) throws IllegalArgumentException {
        //se il tema della rivista e dell'articolo non coincidono, viene visualizzato un messaggio di errore
        if (!tema.equals(rivistaSelezionata.getTema())) {
            messaggioLabel.setText("IL TEMA DELL'ARTICOLO E DELLA RIVISTA SCELTA DEVONO CORRISPONDERE");
            throw new IllegalArgumentException();
        }
        //se l'anno di pubblicazione della rivista e dell'articolo non coincidono, viene visualizzato un messaggio di errore
        if (annopubblicazione != rivistaSelezionata.getAnno()) {
            messaggioLabel.setText("L'ANNO DELL'ARTICOLO NON CORRISPONDE CON L'ANNO DI UNO DELLA RIVISTA");
            throw new IllegalArgumentException();
        }
    }

    /**
     * Controlla che l'anno di pubblicazione del nuovo articolo e quello della conferenza selezionata coincidano.
     *
     * @param conferenzaSelezionata Oggetto che contiene i dati della conferenza selezionata
     * @param annopubblicazione     L'anno di pubblicazione inserito del nuovo articolo
     * @throws IllegalArgumentException Eccezione lanciata quando una delle informazioni confrontate tra il nuovo articolo e la conferenza selezionata non coincidono.
     */
    public void controlloConferenzaSelezionata(Conferenza conferenzaSelezionata, int annopubblicazione) throws IllegalArgumentException {
        //se la data d'inizio della conferenza e di pubblicazione dell'articolo non coincidono, viene visualizzato un messaggio di errore
        if (annopubblicazione != conferenzaSelezionata.getDatainizio().getYear()) {
            messaggioLabel.setText("L'ANNO DELL'ARTICOLO NON CORRISPONDE CON L'ANNO DELLA CONFERENZA");
            throw new IllegalArgumentException();
        }
    }

    /**
     * Dopo un inserimento, pulisce tutti i campi e rimuove la selezione dalle
     * liste di riviste e conferenze.
     */
    public void resetCampi() {
        nomeArticoloField.clear();
        editoreField.clear();
        annoPubblicazioneField.clear();
        checkCartaceo.setSelected(false);
        checkAudiolibro.setSelected(false);
        checkDigitale.setSelected(false);
        argomentoField.clear();
        temaField.clear();
        listaConferenzeDisponibili.getSelectionModel().clearSelection();
        listaRivisteDisponibili.getSelectionModel().clearSelection();
    }
}
