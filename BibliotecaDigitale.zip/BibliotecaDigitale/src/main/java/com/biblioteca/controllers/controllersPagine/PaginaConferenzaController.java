package com.biblioteca.controllers.controllersPagine;

import com.biblioteca.DAO.ArticoloScientificoDAO;
import com.biblioteca.DAO.ConferenzaDAO;
import com.biblioteca.ImplementazioneDAO.ArticoloScientificoImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.ConferenzaImplementazionePostgresDAO;
import com.biblioteca.bibliotecadigitale.Main;
import com.biblioteca.controllers.controllersPaginaTesti.PaginaArticoloController;
import com.biblioteca.model.ArticoloScientifico;
import com.biblioteca.model.Conferenza;
import com.biblioteca.model.Utente;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Controller dedicato alla gestione della pagina delle conferenze.
 */
public class PaginaConferenzaController implements Initializable {


    @FXML
    private Label dataInizioLabel;
    @FXML
    private Label dataFineLabel;
    @FXML
    private Label strutturaLabel;
    @FXML
    private Label responsabileLabel;
    @FXML
    private ListView<String> listaArticoli;
    @FXML
    private Button modificaConferenzaButton;
    @FXML
    private Button confermaModifiche;
    @FXML
    private Button annullaModifiche;
    @FXML
    private Button eliminaButton;
    @FXML
    private TextField modificaResponsabile;
    @FXML
    private Label messaggioLabel;
    @FXML
    private DatePicker modificaDataFine;
    @FXML
    private ImageView sfondo;

    /**
     * Conferenza di cui si mostrano le informazioni.
     */
    private Conferenza conferenza;

    /**
     * Utente che apre la pagina.
     */
    private Utente utente;

    public Conferenza getConferenza() {
        return conferenza;
    }

    public void setConferenza(Conferenza conferenza) {
        this.conferenza = conferenza;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        File sfondoFile = new File("src/Images/paginaConferenza.png");
        Image sfondoImmagine = new Image(sfondoFile.toURI().toString());
        sfondo.setImage(sfondoImmagine);
    }

    /**
     * Imposta le informazione della conferenza nella pagina.
     *
     * @param conferenza La conferenza di cui si mostrano le informazioni.
     * @param utente     L'utente che ha aperto la pagina.
     */
    public void preparaPagina(Conferenza conferenza, Utente utente) {
        //imposta la conferenza e l'utente
        setConferenza(conferenza);
        setUtente(utente);
        setInformazioniBase(); //imposta le informazioni base della conferenza nella pagina
        //cerca gli articoli contenuti nella conferenza
        //creazione degli arraylist che conterranno le informazioni dei risultati dell'interrogazione
        ArrayList<String> titoli = new ArrayList<>();
        ArrayList<String> argomenti = new ArrayList<>();
        ArrayList<String> temi = new ArrayList<>();
        ArrayList<Integer> annoPubblicazione = new ArrayList<>();
        ArrayList<Integer> idArticoli = new ArrayList<>();
        ArrayList<String> editori = new ArrayList<>();
        ArrayList<Boolean> cartaceo = new ArrayList<>();
        ArrayList<Boolean> digitale = new ArrayList<>();
        ArrayList<Boolean> audiolibro = new ArrayList<>();
        //apre la connessione col database
        ArticoloScientificoDAO cercaArticoliConferenza = new ArticoloScientificoImplementazionePostgresDAO();
        ArrayList<ArticoloScientifico> risultatiArticoli = new ArrayList<>();
        try {
            cercaArticoliConferenza.cercaArticoloPerConferenza(conferenza.getIdconferenza(), idArticoli, titoli, temi, argomenti, annoPubblicazione, editori, cartaceo, digitale, audiolibro); //esegue la ricerca per gli articoli nel database
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaArticoliConferenza.close(); //chiusura della connessione al database
        }
        for (int i = 0; i < idArticoli.size(); i++) {
            //per ogni articolo trovato, crea il relativo oggetto di tipo ArticoloScientifico, lo aggiunge all'arraylist e lo visualizza nella lista degli articoli
            ArticoloScientifico articoloScientificoTrovato = new ArticoloScientifico(idArticoli.get(i), titoli.get(i), editori.get(i), cartaceo.get(i), digitale.get(i), audiolibro.get(i), annoPubblicazione.get(i), temi.get(i), argomenti.get(i), null, null);
            listaArticoli.getItems().add(articoloScientificoTrovato.getTitolo());
            risultatiArticoli.add(articoloScientificoTrovato);
        }
        conferenza.setArticoli(risultatiArticoli); //imposta gli articoli della rivista
        //se l'utente è un amministratore, mostra il bottone per modificare la pagina
        if (utente.getTipo().equals("Amministratore")) {
            modificaConferenzaButton.setVisible(true);
        }
    }

    /**
     * In base al contenuto degli attributi della conferenza, imposta i dati nella pagina.
     */
    public void setInformazioniBase() {
        //imposta le informazioni base della conferenza nella pagina
        strutturaLabel.setText(conferenza.getStruttura() + " | " + conferenza.getCitta());
        responsabileLabel.setText(conferenza.getResponsabile());
        dataInizioLabel.setText(String.valueOf(conferenza.getDatainizio()));
        if (conferenza.getDatafine() == null) {
            dataFineLabel.setText("nessuna");
        } else {
            dataFineLabel.setText(String.valueOf(conferenza.getDatafine()));
        }
    }

    /**
     * Apre la pagina dell'articolo selezionato.
     */
    public void visualizzaArticolo() throws IOException {
        try {
            int indiceArticoloSelezionato = listaArticoli.getSelectionModel().getSelectedIndex(); //ottiene l'indice dell'elemento selezionato nella lista degli articoli
            Stage stage = new Stage();
            FXMLLoader fxmlLoader;
            fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaArticolo.fxml"));
            Parent root = fxmlLoader.load();
            PaginaArticoloController paginaArticolo = fxmlLoader.getController();
            paginaArticolo.preparaPagina(conferenza.getArticoli().get(indiceArticoloSelezionato), utente); //passa l'oggetto dell'articolo selezionato e il tipo di utente al controller della pagina dell'articolo
            Scene scene = new Scene(root, 1300, 900);
            stage.setTitle(conferenza.getArticoli().get(indiceArticoloSelezionato).getTitolo());
            stage.setScene(scene);
            stage.show();
            stage.setResizable(false);
        } catch (IndexOutOfBoundsException ignored) {
        } //se viene cliccato uno spazio vuoto, ignora l'eccezione lanciata
    }

    /**
     * Sul click del tasto "modifica", visualizza i campi per la modifica della pagina.
     */
    public void modificaConferenzaOnAction() {
        //visualizza i campi per la modifica
        modificaConferenzaButton.setVisible(false);
        annullaModifiche.setVisible(true);
        confermaModifiche.setVisible(true);
        eliminaButton.setVisible(true);
        modificaResponsabile.setVisible(true);
        modificaResponsabile.setText(conferenza.getResponsabile());
        responsabileLabel.setText("");
        modificaDataFine.setVisible(true);
        dataFineLabel.setText("");
        if (conferenza.getDatafine() != null) {
            modificaDataFine.setValue(conferenza.getDatafine());
        }
    }

    /**
     * Sul click del tasto "conferma" nella modalità di modifica, esegue l'update della
     * relativa conferenza, con i nuovi dati inseriti, dopo averli controllati.
     */
    public void confermaModificheOnAction() {
        //ottenimento del contenuto dei campi
        String nuovoResponsabile = modificaResponsabile.getText();
        LocalDate nuovaDataFine = modificaDataFine.getValue();
        if (nuovoResponsabile.isBlank()) { //controlla che il nome del responsabile sia valido
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("INSERIRE UN RESPONSABILE VALIDO.");
            return;
        }
        if (nuovaDataFine != null && nuovaDataFine.isBefore(conferenza.getDatainizio())) { //controlla la validità della data di fine, se inserita
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("INSERIRE UNA DATA DI FINE SUCCESSIVA O UGUALE A QUELLA DI INIZIO.");
            return;
        }
        ConferenzaDAO modificaConferenza = new ConferenzaImplementazionePostgresDAO(); //connessione al database
        try {
            modificaConferenza.modificaConferenzaDB(conferenza.getIdconferenza(), conferenza.getCitta(), conferenza.getStruttura(), nuovoResponsabile, conferenza.getDatainizio(), nuovaDataFine); //esegue l'update della conferenza nel database
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            modificaConferenza.close(); //chiusura della connessione
        }
        //impostazione dei nuovi valori nella conferenza
        conferenza.setDatafine(nuovaDataFine);
        conferenza.setResponsabile(nuovoResponsabile);
        resetModificheOnAction(); //reimposta la pagina
    }

    /**
     * Sul click del tasto "annulla", chiude tutti i campi per la modifica della pagina
     */
    public void resetModificheOnAction() {
        //nasconde i campi per la modifica
        modificaConferenzaButton.setVisible(true);
        eliminaButton.setVisible(false);
        confermaModifiche.setVisible(false);
        annullaModifiche.setVisible(false);
        modificaResponsabile.setVisible(false);
        modificaDataFine.setVisible(false);
        messaggioLabel.setText("");
        setInformazioniBase(); //reimposta le informazioni
    }

    /**
     * Sul click del tasto "elimina", elimina la rivista dal database.
     */
    public void eliminaOnAction() {
        ConferenzaDAO eliminaConferenza = new ConferenzaImplementazionePostgresDAO(); //connessione al database
        try {
            eliminaConferenza.eliminaConferenzaDB(conferenza.getIdconferenza()); //elimina la conferenza
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            eliminaConferenza.close(); //chiude la connessione
        }
        Stage stage = ((Stage) eliminaButton.getScene().getWindow());
        stage.close(); //chiusura della pagina
    }
}
