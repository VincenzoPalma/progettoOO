package com.biblioteca.controllers.controllersPaginaTesti;


import com.biblioteca.DAO.RomanzoDAO;
import com.biblioteca.DAO.SerieDAO;
import com.biblioteca.ImplementazioneDAO.RomanzoImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.SerieImplementazionePostgresDAO;
import com.biblioteca.bibliotecadigitale.Main;
import com.biblioteca.controllers.controllersPagine.PaginaSerieController;
import com.biblioteca.model.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Controller dedicato alla gestione della pagina per i romanzi.
 */
public class PaginaRomanzoController implements Initializable {
    @FXML
    private Label titoloLabel;
    @FXML
    private Label editoreLabel;
    @FXML
    private Label dataUscitaLabel;
    @FXML
    private Label cartaceoLabel;
    @FXML
    private Label digitaleLabel;
    @FXML
    private Label audiolibroLabel;
    @FXML
    private Hyperlink nomeAutore;
    @FXML
    private Hyperlink nomeSerie;
    @FXML
    private Hyperlink nomeSeguito;
    @FXML
    private Hyperlink nomeCollana;
    @FXML
    private Label isbnLabel;
    @FXML
    private Label genereLabel;
    @FXML
    private Hyperlink nomeSala;
    @FXML
    private Button modificaRomanzoButton;
    @FXML
    private Label messaggioErroreIsbn;
    @FXML
    private Label messaggioErroreData;
    @FXML
    private TextField modificaEditore;
    @FXML
    private TextField modificaGenere;
    @FXML
    private DatePicker modificaData;
    @FXML
    private TextField modificaIsbn;
    @FXML
    private ListView<String> listaAutori;
    @FXML
    private Hyperlink nomeNegozi;
    @FXML
    private Button confermaModifiche;
    @FXML
    private ListView<String> listaSale;
    @FXML
    private ListView<String> listaCollane;
    @FXML
    private ListView<String> listaNegozi;
    @FXML
    private RadioButton checkDigitale;
    @FXML
    private RadioButton checkAudiolibro;
    @FXML
    private RadioButton checkCartaceo;
    @FXML
    private Label messaggioErroreFormato;
    @FXML
    private Button eliminaButton;
    @FXML
    private ImageView sfondo;


    /**
     * Romanzo che viene mostrato nella pagina.
     */
    private Romanzo romanzo;

    private Utente utente;

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    public Romanzo getRomanzo() {
        return romanzo;
    }

    public void setRomanzo(Romanzo romanzo) {
        this.romanzo = romanzo;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        File sfondoFile = new File("src/Images/paginaRomanzo.png");
        Image sfondoImmagine = new Image(sfondoFile.toURI().toString());
        sfondo.setImage(sfondoImmagine);

    }


    /**
     * Imposta le informazioni del libro nella pagina.
     * Utilizza le informazioni già presenti nell'oggetto "romanzo".
     * Per la serie, il seguito, le sale, le collane e gli autori effettua delle ricerche
     * nel database tramite diverse classi DAO.
     *
     * @param romanzoSelezionato L'oggetto che si riferisce al romanzo
     *                           di cui deve mostrare le informazioni.
     * @param utente             Oggetto contenente i dati dell'utente che ha aperto la pagina.
     *                           In base suo tipo verranno visualizzati o meno determinati
     *                           pulsanti per la modifica delle informazioni nella pagina.
     */
    public void preparaPagina(Romanzo romanzoSelezionato, Utente utente) {
        //imposta il romanzo della pagina e l'utente che l'ha aperta
        setRomanzo(romanzoSelezionato);
        setUtente(utente);
        //se l'utente è un amministratore, rende visibile il bottone per modificare le informazioni nella pagina
        if (utente.getTipo().equals("Amministratore")) {
            modificaRomanzoButton.setVisible(true);
            modificaRomanzoButton.setDisable(false);
        }
        //imposta le informazioni del romanzo nella pagina
        UtilControllerTesti.setInformazioniBase(romanzo.getTitolo(), romanzo.getEditore(), romanzo.getGenere(), romanzo.getIsbn(), romanzo.getGiornopubblicazione(), romanzo.getMesepubblicazione(), romanzo.getAnnopubblicazione(), editoreLabel, titoloLabel, genereLabel, isbnLabel, dataUscitaLabel);
        UtilControllerTesti.setFormati(romanzo.getCartaceo(), romanzo.getDigitale(), romanzo.getAudiolibro(), cartaceoLabel, digitaleLabel, audiolibroLabel);
        romanzo.setSeguito(cercaSeguito(romanzo.getIsbn())); //ricerca e impostazione del seguito del romanzo, se esiste
        romanzo.setSerie(cercaSerie(romanzo.getIsbn())); //ricerca e impostazione della serie del romanzo, se esiste
        romanzo.setAutori(UtilControllerTesti.cercaAutoriLibro(romanzo.getIsbn())); //ricerca e impostazione degli autori del libro
        romanzo.setEsposizioni(UtilControllerTesti.cercaEsposizioni(romanzo)); //ricerca e impostazione delle esposizioni del libro
        romanzo.setDisponibili(UtilControllerTesti.cercaDisponibilita(romanzo)); //ricerca e impostazione delle disponibilità del libro
        romanzo.setPartecipazioni(UtilControllerTesti.cercaPartecipazioni(romanzo)); //ricerca e impostazione delle partecipazioni del libro
        UtilControllerTesti.setInformazioniHyperLink(nomeCollana, nomeSala, nomeAutore, nomeNegozi, nomeSerie, nomeSeguito, romanzo); //imposta le informazioni con hyperlink del romanzo
    }

    /**
     * Cerca il seguito del romanzo della pagina nel database, se esiste crea un oggetto e lo
     * dà come valore di ritorno, altrimenti ritorna null.
     *
     * @param isbn L'isbn del romanzo di cui si vuole cercare il seguito.
     */
    public Romanzo cercaSeguito(String isbn) {
        //dichiarazione degli arraylist che conterranno i dati del risultato
        ArrayList<String> isbnSeguito = new ArrayList<>();
        ArrayList<String> titoloSeguito = new ArrayList<>();
        ArrayList<String> genereSeguito = new ArrayList<>();
        ArrayList<LocalDate> dataUscitaSeguito = new ArrayList<>();
        ArrayList<String> editoriSeguito = new ArrayList<>();
        ArrayList<Boolean> cartaceoSeguito = new ArrayList<>();
        ArrayList<Boolean> digitaleSeguito = new ArrayList<>();
        ArrayList<Boolean> audiolibroSeguito = new ArrayList<>();
        RomanzoDAO cercaSeguito = new RomanzoImplementazionePostgresDAO(); //connessione al database
        try {
            cercaSeguito.cercaSeguitoRomanzoDB(isbn, isbnSeguito, titoloSeguito, genereSeguito, dataUscitaSeguito, editoriSeguito, cartaceoSeguito, digitaleSeguito, audiolibroSeguito); //ricerca del seguito
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaSeguito.close(); //chiusura della connessione al database
        }
        if (isbnSeguito.isEmpty()) { //ritorna null se non ci sono risultati
            return null;
        } else { //altrimenti ritorna un oggetto Romanzo contenente le informazioni del seguito trovato
            return new Romanzo(titoloSeguito.get(0), editoriSeguito.get(0), cartaceoSeguito.get(0), digitaleSeguito.get(0), audiolibroSeguito.get(0), dataUscitaSeguito.get(0).getYear(), isbnSeguito.get(0), dataUscitaSeguito.get(0).getDayOfMonth(), dataUscitaSeguito.get(0).getMonthValue(), genereSeguito.get(0), null, null);
        }
    }

    /**
     * Cerca la serie del romanzo della pagina nel database, se esiste crea un oggetto e lo
     * dà come valore di ritorno, altrimenti ritorna null.
     *
     * @param isbn L'isbn del romanzo di cui si vuole cercare la serie.
     */
    public Serie cercaSerie(String isbn) {
        //dichiarazione degli arraylist che conterranno i dati del risultato
        ArrayList<Integer> idSerie = new ArrayList<>();
        ArrayList<String> titoloSerie = new ArrayList<>();
        SerieDAO cercaSerie = new SerieImplementazionePostgresDAO(); //connessione al database
        try {
            cercaSerie.cercaSeriePerLibro(isbn, idSerie, titoloSerie); //ricerca della serie
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaSerie.close(); //chiusura della connessione al database
        }
        if (idSerie.isEmpty()) { //ritorna null se non ci sono risultati
            return null;
        } else { //altrimenti ritorna un oggetto Romanzo contenente le informazioni del seguito trovato
            return new Serie(titoloSerie.get(0), idSerie.get(0));
        }
    }


    /**
     * Sul click del nome del seguito del libro mostrato nella pagina
     * apre la pagina che contiene le informazioni del seguito.
     */
    public void seguitoOnAction() throws IOException {
        Stage stage = (Stage) nomeSeguito.getScene().getWindow();
        Stage newStage = new Stage();
        //se viene cliccato il label quando contiene la stringa "Aggiungi seguito." allora apre la pagina per aggiungere un seguito
        if (nomeSeguito.getText().equals("Aggiungi seguito.")) {
            UtilControllerTesti.visualizzaGestioneSeguito(romanzo);
        } else if (nomeSeguito.getText().equals("Rimuovi seguito.")) { //se viene cliccato il label quando contiene la stringa "Rimuovi seguito." allora rimuove il seguito del libro
            RomanzoDAO rimuoviSeguito = new RomanzoImplementazionePostgresDAO(); //connessione al database
            try {
                rimuoviSeguito.modificaRomanzoDB(romanzo.getIsbn(), romanzo.getEditore(), romanzo.getGenere(), LocalDate.of(romanzo.getAnnopubblicazione(), romanzo.getMesepubblicazione(), romanzo.getGiornopubblicazione()), romanzo.getIsbn(), romanzo.getCartaceo(), romanzo.getDigitale(), romanzo.getAudiolibro(), null); //rimozione del seguito dal romanzo nel database
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                rimuoviSeguito.close(); //chiusura della connessione
            }
            romanzo.setSeguito(null); //rimozione del seguito
        } else { //se viene cliccato il label quando contiene il nome del seguito del romanzo, apre la pagina pe quel seguito
            stage.close();
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaRomanzo.fxml"));
            Parent root = fxmlLoader.load();
            PaginaRomanzoController paginaSeguito = fxmlLoader.getController();
            paginaSeguito.preparaPagina(romanzo.getSeguito(), utente); //prepara la pagina del seguito
            Scene scene = new Scene(root, 1300, 900);
            stage.setTitle("Pagina Libro");
            newStage.setScene(scene);
            newStage.show();
            stage.setResizable(true);
        }

    }

    /**
     * Sul click del tasto "Modifica" (visibile solo agli amministratori), visualizza dei text field
     * che contengono le informazioni attuali, e rende possibile la loro modifica.
     */
    public void modificaRomanzoOnAction() {
        UtilControllerTesti.disabilitaCampi(listaSale, listaCollane, listaNegozi, listaAutori, modificaRomanzoButton); //disabilita i label hyperlink
        //prepara la pagina per la modifica
        UtilControllerTesti.preparaModifica(dataUscitaLabel, isbnLabel, cartaceoLabel, audiolibroLabel, digitaleLabel, modificaEditore, romanzo.getEditore(), modificaGenere, genereLabel, romanzo.getGenere(),
                modificaData, modificaIsbn, romanzo.getIsbn(), romanzo.getGiornopubblicazione(), romanzo.getMesepubblicazione(), romanzo.getAnnopubblicazione(),
                confermaModifiche, checkCartaceo, checkDigitale, checkAudiolibro, editoreLabel, eliminaButton);
        //imposta i label per l'aggiunta e rimozione di elementi del romanzo
        UtilControllerTesti.setTastiModifica(nomeSala, nomeCollana, nomeAutore, nomeNegozi, nomeSeguito, nomeSerie);
        //imposta i formati in base ai valori attuali
        UtilControllerTesti.checkFormati(romanzo.getCartaceo(), romanzo.getDigitale(), romanzo.getAudiolibro(), checkCartaceo, checkDigitale, checkAudiolibro);
    }


    /**
     * Prende il contenuto dei textfield per modificare l'editore, il genere e la data
     * del romanzo. Esegue una query di update per modificare tali valori per quel romanzo
     * nel database. Se in uno o più campi non sono stati modificati i valori, la query di update
     * verrà comunque eseguita ma con quegli stessi valori.
     */
    public void confermaModificheOnAction() {
        //reset dei messaggi di errore
        messaggioErroreIsbn.setText("");
        messaggioErroreData.setText("");
        messaggioErroreFormato.setText("");
        //prende il contenuto dei campi
        String nuovoEditore = modificaEditore.getText();
        String nuovoGenere = modificaGenere.getText();
        LocalDate nuovaData = modificaData.getValue();
        String nuovoIsbn = modificaIsbn.getText();
        //controlla che l'editore inserito sia valido, in caso negativo lo imposta come l'editore già presente
        if (nuovoEditore.isBlank()) {
            nuovoEditore = romanzo.getEditore();
        }
        //controlla che il genere inserito sia valido, in caso negativo lo imposta come il genere già presente
        if (nuovoGenere.isBlank()) {
            nuovoGenere = romanzo.getGenere();
        }
        //controlla la validità dei dati inseriti
        if (!UtilControllerTesti.controlloDatiModifica(nuovaData, nuovoIsbn, romanzo.getAutori(), messaggioErroreIsbn, messaggioErroreData)) {
            return;
        }
        //ottiene il valore dei radiobutton per ogni formato
        Boolean nuovoFormatoCartaceo = UtilControllerTesti.modificaCartaceo(checkCartaceo);
        Boolean nuovoFormatoDigitale = UtilControllerTesti.modificaDigitale(checkDigitale);
        Boolean nuovoFormatoAudiolibro = UtilControllerTesti.modificaAudiolibro(checkAudiolibro);
        RomanzoDAO modificaRomanzo = new RomanzoImplementazionePostgresDAO(); //apertura della connessione col database
        try {
            //se il romanzo non ha seguito, esegue la query passando nessun seguito
            if (romanzo.getSeguito() == null) {
                modificaRomanzo.modificaRomanzoDB(romanzo.getIsbn(), nuovoEditore, nuovoGenere, nuovaData, nuovoIsbn, nuovoFormatoCartaceo, nuovoFormatoDigitale, nuovoFormatoAudiolibro, null);
            } else {
                modificaRomanzo.modificaRomanzoDB(romanzo.getIsbn(), nuovoEditore, nuovoGenere, nuovaData, nuovoIsbn, nuovoFormatoCartaceo, nuovoFormatoDigitale, nuovoFormatoAudiolibro, romanzo.getSeguito().getIsbn());
            }
        } catch (SQLException ex) {
            //messaggio di errore in caso di errore del database
            UtilControllerTesti.setMessaggioErrore(messaggioErroreFormato, messaggioErroreIsbn, nuovoFormatoCartaceo, nuovoFormatoDigitale);
            return;
        } finally {
            modificaRomanzo.close(); //chiusura della connessione
        }
        //imposta tutti i nuovi valori al romanzo
        romanzo.setEditore(nuovoEditore);
        romanzo.setData(nuovaData);
        romanzo.setGenere(nuovoGenere);
        romanzo.setIsbn(nuovoIsbn);
        romanzo.setCartaceo(nuovoFormatoCartaceo);
        romanzo.setDigitale(nuovoFormatoDigitale);
        romanzo.setAudiolibro(nuovoFormatoAudiolibro);
        resetModificheOnAction(); //esce dalla modalità di modifica
        preparaPagina(romanzo, utente); //ricarica le informazioni nella pagina
    }

    /**
     * Rimuove i text field che sono visualizzati quando viene premuto il tasto "Modifica".
     */
    public void resetModificheOnAction() {
        UtilControllerTesti.setInformazioniBase(romanzo.getTitolo(), romanzo.getEditore(), romanzo.getGenere(), romanzo.getIsbn(), romanzo.getGiornopubblicazione(), romanzo.getMesepubblicazione(), romanzo.getAnnopubblicazione(), editoreLabel, titoloLabel, genereLabel, isbnLabel, dataUscitaLabel);
        UtilControllerTesti.setInformazioniHyperLink(nomeCollana, nomeSala, nomeAutore, nomeNegozi, nomeSerie, nomeSeguito, romanzo);
        UtilControllerTesti.chiudiPannelliInformazioni(listaAutori, listaSale, listaCollane, listaNegozi);
        UtilControllerTesti.setFormati(romanzo.getCartaceo(), romanzo.getDigitale(), romanzo.getAudiolibro(), cartaceoLabel, digitaleLabel, audiolibroLabel);
        UtilControllerTesti.chiudiModifiche(modificaEditore, modificaGenere, modificaData, modificaRomanzoButton, confermaModifiche, modificaIsbn, checkCartaceo, checkDigitale, checkAudiolibro, messaggioErroreIsbn, messaggioErroreData, messaggioErroreFormato, eliminaButton);
    }

    /**
     * Se esistono più sale per il romanzo, apre una lista che contiene i loro nomi.
     * Altrimenti apre la pagina dell'unica sala del romanzo.
     * Se si è in modalità modifica, aprirà invece la pagina per aggiungere e/o
     * rimuovere esposizioni.
     */
    public void visualizzaSale() throws IOException {
        if (nomeSala.getText().equals("Aggiungi/Rimuovi esposizione.")) {
            UtilControllerTesti.visualizzaGestioneSala(romanzo);
        } else if (romanzo.getEsposizioni().size() > 1) {
            UtilControllerTesti.visualizzaSale(romanzo.getEsposizioni(), listaSale);
            UtilControllerTesti.gestisciVisualizzazioneListe(listaAutori, listaCollane, listaNegozi, listaSale, listaSale);
        } else if (romanzo.getEsposizioni().size() == 1) {
            UtilControllerTesti.visualizzaSalaSelezionata(romanzo.getEsposizioni().get(0).getSala(), utente);
        }
    }

    /**
     * Sul click di uno delle sale della lista, chiama il metodo per aprire la pagina
     * relativa a quella sala.
     */
    public void mostraSalaSelezionata() throws IOException {
        try {
            int elementoSelezionato = listaSale.getSelectionModel().getSelectedIndex();
            UtilControllerTesti.visualizzaSalaSelezionata(romanzo.getEsposizioni().get(elementoSelezionato).getSala(), utente);
        } catch (IndexOutOfBoundsException ignored) {
            //ignora l'eccezione nata dal click su uno spazio vuoto della lista
        }
    }


    /**
     * Se esistono più autori per il romanzo, apre una lista che contiene i loro nomi.
     * Altrimenti apre la pagina dell'unico autore del romanzo.
     * Se si è in modalità modifica, aprirà invece la pagina per aggiungere e/o
     * rimuovere autori.
     */
    public void visualizzaAutori() throws IOException {
        if (nomeAutore.getText().equals("Aggiungi/Rimuovi autore.")) {
            UtilControllerTesti.visualizzaGestioneAutore(romanzo);
        } else if (romanzo.getAutori().size() > 1) {
            listaAutori.getItems().clear();
            UtilControllerTesti.gestisciVisualizzazioneListe(listaAutori, listaCollane, listaNegozi, listaSale, listaAutori);
            for (Autore autore : romanzo.getAutori()) {
                listaAutori.getItems().addAll(autore.getNominativo());
            }
        } else if (romanzo.getAutori().size() == 1) {
            UtilControllerTesti.visualizzaAutore(romanzo.getAutori().get(0), utente);
        }

    }

    /**
     * Sul click di uno degli autori della lista, chiama il metodo per aprire la pagina
     * relativa a quell'autore.
     */
    public void mostraAutoreSelezionato() throws IOException {
        try {
            int elementoSelezionato = listaAutori.getSelectionModel().getSelectedIndex();
            UtilControllerTesti.visualizzaAutore(romanzo.getAutori().get(elementoSelezionato), utente);
        } catch (IndexOutOfBoundsException ignored) {
            //ignora l'eccezione nata dal click su uno spazio vuoto della lista
        }
    }


    /**
     * Se esistono più collane per il romanzo, apre una lista che contiene i loro nomi.
     * Altrimenti apre la pagina dell'unica collana del romanzo.
     * Se si è in modalità modifica, aprirà invece la pagina per aggiungere e/o
     * rimuovere collane.
     */
    public void visualizzaCollane() throws IOException {
        if (nomeCollana.getText().equals("Aggiungi/Rimuovi collana.")) {
            UtilControllerTesti.visualizzaGestioneCollana(romanzo);
        } else if (romanzo.getPartecipazioni().size() > 1) {
            listaCollane.getItems().clear();
            UtilControllerTesti.gestisciVisualizzazioneListe(listaAutori, listaCollane, listaNegozi, listaSale, listaCollane);
            for (Partecipazione partecipazione : romanzo.getPartecipazioni()) {
                listaCollane.getItems().addAll(partecipazione.collana.getNome());
            }
        } else if (romanzo.getPartecipazioni().size() == 1) {
            UtilControllerTesti.visualizzaCollana(romanzo.getPartecipazioni().get(0).getCollana(), utente);
        }
    }


    /**
     * Sul click di uno delle collane della lista, chiama il metodo per aprire la pagina
     * relativa a quella collana.
     */
    public void mostraCollanaSelezionata() throws IOException {
        try {
            int elementoSelezionato = listaCollane.getSelectionModel().getSelectedIndex();
            UtilControllerTesti.visualizzaCollana(romanzo.getPartecipazioni().get(elementoSelezionato).getCollana(), utente);
        } catch (IndexOutOfBoundsException ignored) {
            //ignora l'eccezione nata dal click su uno spazio vuoto della lista
        }
    }


    /**
     * Se esistono più negozi per il romanzo, apre una lista che contiene i loro nomi.
     * Altrimenti apre la pagina dell'unico negozio del romanzo.
     * Se si è in modalità modifica, aprirà invece la pagina per aggiungere e/o
     * rimuovere negozi.
     */
    public void visualizzaNegozi() throws IOException {
        if (nomeNegozi.getText().equals("Aggiungi/Rimuovi negozio.")) {
            UtilControllerTesti.visualizzaGestioneNegozio(romanzo);
        } else if (romanzo.getDisponibili().size() > 1) {
            listaNegozi.getItems().clear();
            UtilControllerTesti.gestisciVisualizzazioneListe(listaAutori, listaCollane, listaNegozi, listaSale, listaNegozi);
            for (Disponibilita disponibilita : romanzo.getDisponibili()) {
                listaNegozi.getItems().addAll(disponibilita.negozio.getNome() + " | €" + disponibilita.getPrezzo());
            }
        } else if (romanzo.getDisponibili().size() == 1) {
            UtilControllerTesti.visualizzaNegozio(romanzo.getDisponibili().get(0).getNegozio(), utente);
        }
    }


    /**
     * Sul click di uno dei negozi della lista, chiama il metodo per aprire la pagina
     * relativa a quel negozio.
     */
    public void mostraNegozioSelezionato() throws IOException {
        try {
            int elementoSelezionato = listaNegozi.getSelectionModel().getSelectedIndex();
            UtilControllerTesti.visualizzaNegozio(romanzo.getDisponibili().get(elementoSelezionato).getNegozio(), utente);
        } catch (IndexOutOfBoundsException ignored) {
            //ignora l'eccezione nata dal click su uno spazio vuoto della lista
        }
    }

    /**
     * Sul click del label della serie, apre la pagina della serie in questione, se esiste.
     * In modalità modifica apre la pagina per aggiungere una serie, nel caso il libro non ne abbia una.
     * Altrimenti rimuove il libro dalla serie attuale.
     */
    public void visualizzaSerie() throws IOException {
        //se non c'è una serie, apre un pagina per aggiungerla
        if (nomeSerie.getText().equals("Aggiungi serie.")) {
            UtilControllerTesti.visualizzaGestioneSerie(romanzo);
        } else if (nomeSerie.getText().equals("Rimuovi serie.")) { //altrimenti rimuove il libro dalla serie
            //connessione al database
            SerieDAO rimuoviSerieALibro = new SerieImplementazionePostgresDAO();
            RomanzoDAO rimuoviSeguito = new RomanzoImplementazionePostgresDAO();
            try {
                rimuoviSerieALibro.rimuoviSerieALibro(romanzo.getIsbn(), romanzo.getSerie().getIdserie()); //rimuove il libro dalla serie
                rimuoviSeguito.eliminaSeguitoDaLibro(romanzo.getIsbn()); //rimuove il seguito del libro che aveva il libro rimosso come seguito
                rimuoviSeguito.modificaRomanzoDB(romanzo.getIsbn(), romanzo.getEditore(), romanzo.getGenere(), LocalDate.of(romanzo.getAnnopubblicazione(), romanzo.getMesepubblicazione(), romanzo.getGiornopubblicazione()), romanzo.getIsbn(), romanzo.getCartaceo(), romanzo.getDigitale(), romanzo.getAudiolibro(), null); //rimuove il seguito del libro rimosso dalla serie
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                rimuoviSeguito.close(); //chiusura della connessione
            }
            romanzo.getSerie().getLibri().remove(romanzo); //rimozione del libro dalla serie
            //se la serie a cui è stato rimosso il libro, dopo la rimozione, è vuota, la serie viene eliminata e viene rimossa la preferenza dell'utente di quella serie (se esiste) e le eventuali notifiche
            if (romanzo.getSerie().getLibri().isEmpty()) {
                utente.getSerie().removeIf(serie -> serie.equals(romanzo.getSerie()));
                utente.getNotifiche().removeIf(notifica -> notifica.getSerie().equals(romanzo.getSerie()));
            }
            romanzo.setSerie(null); //rimozione della serie dal libro
            romanzo.setSeguito(null); //rimozione del seguito dal libro
        } else { //se si clicca sul nome della serie, apre la pagina relativa a quella serie
            Stage stage = new Stage();
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("PaginaSerie.fxml"));
            Parent root = fxmlLoader.load();
            PaginaSerieController paginaSerie = fxmlLoader.getController();
            paginaSerie.preparaPagina(romanzo.serie, utente);
            Scene scene = new Scene(root, 500, 500);
            stage.setTitle(romanzo.serie.getTitolo());
            stage.setScene(scene);
            stage.show();
            stage.setResizable(false);
        }
    }

    /**
     * Aggiorna le informazioni della pagina dopo aver premuto
     * il tasto F5.
     */
    public void refresh(KeyEvent keyEvent) {
        if (keyEvent.getCode() == KeyCode.F5) {
            UtilControllerTesti.chiudiPannelliInformazioni(listaAutori, listaSale, listaCollane, listaNegozi);
            preparaPagina(romanzo, utente);
        }
    }

    /**
     * Sul click del tasto "Elimina", cancella il romanzo della pagina.
     */
    public void eliminaOnAction() {
        UtilControllerTesti.eliminaLibro(romanzo);
        Stage stage = (Stage) eliminaButton.getScene().getWindow();
        stage.close(); //chiude la pagina
    }
}
