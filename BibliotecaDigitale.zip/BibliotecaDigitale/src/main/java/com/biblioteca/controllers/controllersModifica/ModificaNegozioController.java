package com.biblioteca.controllers.controllersModifica;

import com.biblioteca.DAO.DisponibilitaDAO;
import com.biblioteca.DAO.NegozioDAO;
import com.biblioteca.ImplementazioneDAO.DisponibilitaImplementazionePostgresDAO;
import com.biblioteca.ImplementazioneDAO.NegozioImplementazionePostgresDAO;
import com.biblioteca.model.Disponibilita;
import com.biblioteca.model.Libro;
import com.biblioteca.model.Negozio;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Controller dedicato alla gestione della pagina per l'aggiunta e la rimozione di negozi dal libro.
 */
public class ModificaNegozioController {


    private Libro libro;
    private ArrayList<Negozio> negoziDisponibili = new ArrayList<>();
    @FXML
    private ListView<String> listaNegoziDisponibili;
    @FXML
    private ListView<String> listaNegoziInseriti;
    @FXML
    private Label messaggioLabel;
    @FXML
    private TextField prezzoField;

    public Libro getLibro() {
        return libro;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }

    public ArrayList<Negozio> getNegoziDisponibili() {
        return negoziDisponibili;
    }

    public void setNegoziDisponibili(ArrayList<Negozio> negoziDisponibili) {
        this.negoziDisponibili = negoziDisponibili;
    }

    /**
     * Mostra tutti i negozi disponibili a cui aggiungere il libro, e tutti i negozi che dispongono del libro e che possono essere rimossi.
     *
     * @param libro Il testo di cui si gestiscono i negozi.
     */
    public void preparaPagina(Libro libro) {
        //imposta il testo
        setLibro(libro);
        //visualizza i negozi già associati al libro
        for (Disponibilita disponibilita : libro.getDisponibili()) {
            listaNegoziInseriti.getItems().add(disponibilita.getNegozio().getNome() + " | €" + disponibilita.getPrezzo());
        }
        //dichiarazione degli arraylist che conterranno i risultati
        ArrayList<Negozio> negozi = new ArrayList<>();
        ArrayList<Integer> idNegozi = new ArrayList<>();
        ArrayList<String> nomeNegozi = new ArrayList<>();
        ArrayList<String> sitoNegozi = new ArrayList<>();
        NegozioDAO cercaNegoziDisponibili = new NegozioImplementazionePostgresDAO(); //connessione al database
        try {
            cercaNegoziDisponibili.getAllNegozi(idNegozi, nomeNegozi, sitoNegozi); //ricerca di tutti i negozi
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            cercaNegoziDisponibili.close(); //chiusura della connessione
        }
        //per ogni negozio trovato, crea il relativo oggetto
        for (int i = 0; i < idNegozi.size(); i++) {
            Negozio negozio = new Negozio(idNegozi.get(i), nomeNegozi.get(i), sitoNegozi.get(i));
            negozi.add(negozio);
        }
        //scarta tutti i negozi che hanno già il libro disponibile
        for (Negozio negozio : negozi) {
            boolean contenuto = false;
            for (Disponibilita disponibilita : libro.getDisponibili()) {
                if (disponibilita.getNegozio().equals(negozio)) {
                    contenuto = true;
                    break;
                }
            }
            if (!contenuto) { //se il libro non è già disponibile nel negozio, il negozio viene aggiunto tra quelli disponibili
                negoziDisponibili.add(negozio);
                listaNegoziDisponibili.getItems().add(negozio.getNome());
            }
        }

    }

    /**
     * Sul click di uno dei negozi associati al testo, lo rimuove da esso, e lo sposta nella lista
     * dei negozi disponibili.
     */
    public void rimuoviNegozi() {
        if (!listaNegoziInseriti.getSelectionModel().isEmpty()) { //se viene selezionato un elemento valido
            int indiceNegozioSelezionato = listaNegoziInseriti.getSelectionModel().getSelectedIndex(); //ottenimento dell'indice del negozio selezionato nella lista
            Negozio negozioRimosso = libro.getDisponibili().get(indiceNegozioSelezionato).getNegozio(); //ottiene il negozio da inserire
            DisponibilitaDAO rimuoviNegozio = new DisponibilitaImplementazionePostgresDAO(); //connessione al database
            try {
                rimuoviNegozio.eliminaDisponibilitaDB(libro.getIsbn(), negozioRimosso.getIdnegozio()); //rimuove il libro dal negozio nel database
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                rimuoviNegozio.close(); //chiusura della connessione
            }
            negoziDisponibili.add(negozioRimosso); //aggiunta del negozio dai negozi disponibili
            listaNegoziInseriti.getItems().remove(indiceNegozioSelezionato); //rimozione del negozio dai negozi associati al libro
            listaNegoziDisponibili.getItems().add(negozioRimosso.getNome()); //aggiunta del negozio nella lista quelli disponibili
            //rimozione della disponibilità del libro dal negozio
            libro.getDisponibili().remove(indiceNegozioSelezionato);
            negozioRimosso.getDisponibili().removeIf(disponibilita -> disponibilita.getLibro().equals(libro));
        }
    }

    /**
     * Sul click di uno degli autori disponibili, lo aggiunge al testo, e lo sposta nella lista
     * degli autori associati.
     */
    public void aggiungiNegozi() {
        if (!listaNegoziDisponibili.getSelectionModel().isEmpty()) { //se viene selezionato un elemento valido
            int indiceNegozioSelezionato = listaNegoziDisponibili.getSelectionModel().getSelectedIndex(); //ottenimento dell'indice del negozio selezionato nella lista
            DisponibilitaDAO aggiungiNegozio = new DisponibilitaImplementazionePostgresDAO();
            //ottiene il prezzo inserito e verifica la sua validità
            BigDecimal prezzo;
            try {
                prezzo = new BigDecimal(prezzoField.getText());
                if (prezzo.compareTo(BigDecimal.ZERO) <= 0) {
                    throw new IllegalArgumentException();
                }
            } catch (NumberFormatException ex) {
                messaggioLabel.setTextFill(Color.web("#FF2E2E"));
                messaggioLabel.setText("INSERIRE UN PREZZO VALIDO");
                return;
            } catch (IllegalArgumentException ex) {
                messaggioLabel.setTextFill(Color.web("#FF2E2E"));
                messaggioLabel.setText("INSERIRE UN PREZZO MAGGIORE DI 0");
                return;
            }
            Negozio negozioAggiunto = negoziDisponibili.get(indiceNegozioSelezionato); //ottiene il negozio a cui inserire il libro
            try {
                aggiungiNegozio.aggiungiDisponibilitaDB(libro.getIsbn(), negozioAggiunto.getIdnegozio(), prezzo); //inserisce il libro nel negozio
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                aggiungiNegozio.close(); //chiusura della connessione al database
            }
            Disponibilita nuovaDisponiblita = new Disponibilita(prezzo, libro, negozioAggiunto); //crea la nuova disponiblità
            listaNegoziDisponibili.getItems().remove(indiceNegozioSelezionato); //rimuove il negozio dalla lista di negozi disponibili
            listaNegoziInseriti.getItems().add(negozioAggiunto.getNome() + " | €" + prezzo); //aggiunta della disponibilità del libro nella lista di negozi che lo hanno
            //aggiunta della disponibilità del libro al negozio
            libro.getDisponibili().add(nuovaDisponiblita);
            negozioAggiunto.getDisponibili().add(nuovaDisponiblita);
            negoziDisponibili.remove(negozioAggiunto); //rimozione del negozio tra quelli disponibili
            //reset del messaggio e del campo del prezzo
            messaggioLabel.setText("");
            prezzoField.setText("");
        }
    }
}
