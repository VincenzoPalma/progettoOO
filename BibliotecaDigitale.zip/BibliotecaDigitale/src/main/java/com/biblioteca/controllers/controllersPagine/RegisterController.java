package com.biblioteca.controllers.controllersPagine;

import com.biblioteca.DAO.UtenteDAO;
import com.biblioteca.ImplementazioneDAO.UtenteImplementazionePostgresDAO;
import com.biblioteca.bibliotecadigitale.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**
 * Controller dedicato alla gestione della pagina di registrazione.
 *
 * @see LoginController
 */
public class RegisterController implements Initializable {

    @FXML
    private Button loginButton;
    @FXML
    private ImageView sfondoPaginaRegistrazione;
    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private PasswordField confermaPasswordField;
    @FXML
    private Label messaggioLabel;

    /**
     * Carica l'immagine utilizzata per lo sfondo della
     * pagina di registrazione.
     *
     * @param url Un URL che indica la locazione dell'immagine
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        File registerFile = new File("src/Images/SfondoPaginaLogin.png");
        Image registerImage = new Image(registerFile.toURI().toString());
        sfondoPaginaRegistrazione.setImage(registerImage);
    }

    /**
     * Prende il contenuto dei campi nella pagina di registrazione e controlla che:
     * <ul>
     *     <li>l'username non sia vuoto e che non contenga spazi</li>
     *      <li>la password sia di almeno 5 caratteri e coincida con il campo per confermarla</li>
     * </ul>
     * Se una delle condizioni non è soddisfatta mostra uno specifico messaggio rosso di errore, altrimenti
     * prova a inserire nel database un nuovo utente con quelle credenziali tramite la classe {@link UtenteImplementazionePostgresDAO}.
     * Se un utente con l'username inserito è già presente nel database mostra un messaggio rosso di errore,
     * altrimenti mostra un messaggio verde di avvenuta registrazione.
     */
    public void registerOnAction() {
        //ottiene il contenuto dei text-fields
        String username = usernameField.getText();
        String password = passwordField.getText();
        String confermaPassword = confermaPasswordField.getText();

        //controlla che l'username non sia vuoto e che non contenga spazi
        if (username.isBlank()) {
            messaggioLabel.setText("INSERIRE UN USERNAME VALIDO");
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            return;
        }
        //controlla che la password contenga almeno CINQUE caratteri
        if (password.length() < 5) {
            messaggioLabel.setText("LA PASSWORD DEVE CONTENERE ALMENO 5 CARATTERI");
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            return;
        }
        if (!password.equals(confermaPassword)) { //controlla che le stringhe nel text-field password e in conferma password coincidano
            messaggioLabel.setText("LE DUE PASSWORD NON COINCIDONO");
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            return;
        }
        UtenteDAO user = new UtenteImplementazionePostgresDAO(); //apre la connessione col database
        try {
            user.registraUtenteDB(username, password); //inserimento del nuovo utente nel database
        } catch (SQLException ex) {
            //se il nuovo utente ha inserito un username già in uso, visualizza un messaggio di errore
            messaggioLabel.setText("USERNAME GIA' IN USO");
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            return;
        } finally {
            user.close(); //chiude la connessione
        }
        messaggioLabel.setTextFill(Color.web("#00A300")); //imposta il colore del messaggio
        messaggioLabel.setText("REGISTRAZIONE RIUSCITA"); //messaggio per confermare la registrazione
    }

    /**
     * Esegue il metodo RegisterOnAction dopo aver premuto il tasto
     * "Invio".
     */
    public void invioPremuto(KeyEvent e) {
        if (e.getCode().equals(KeyCode.ENTER)) {
            registerOnAction();
        }
    }

    /**
     * Sul click del tasto "Accedi" richiama la pagina di login
     * e passa il controllo al controller dedicato a essa.
     *
     * @see LoginController
     */
    public void accediOnAction() throws IOException {
        Stage stage = (Stage) loginButton.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 400, 500);
        stage.setTitle("Accedi");
        stage.setScene(scene);
        stage.centerOnScreen();
        stage.show();
        stage.setResizable(false);
    }
}
