package com.biblioteca.controllers.controllersAggiungi;

import com.biblioteca.DAO.LibroDAO;
import com.biblioteca.ImplementazioneDAO.LibroImplementazionePostgresDAO;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.paint.Color;

import java.sql.SQLException;
import java.time.LocalDate;

/**
 * Controller dedicato alla gestione della pagina per l'inserimento di libri.
 */
public class AggiungiLibroController {
    ToggleGroup selezionaTipo = new ToggleGroup();
    @FXML
    private TextField editoreField;
    @FXML
    private TextField nomeTestoField;
    @FXML
    private DatePicker dataDiPubblicazioneField;
    @FXML
    private RadioButton checkDigitale;
    @FXML
    private RadioButton checkAudiolibro;
    @FXML
    private RadioButton checkCartaceo;
    @FXML
    private RadioButton checkRomanzo;
    @FXML
    private RadioButton checkDidattico;
    @FXML
    private TextField isbnField;
    @FXML
    private TextField genereAmbitoField;
    @FXML
    private Label messaggioLabel;

    /**
     * Sul click del tasto "Conferma", ottiene il contenuto dei campi, ne verifica la validità, e inserisce un libro
     * con quei valori nel database.
     */
    public void confermaOnAction() {
        //prende il contenuto dei campi
        String isbn = isbnField.getText();
        String titolo = nomeTestoField.getText();
        String genere = genereAmbitoField.getText();
        String editore = editoreField.getText();
        LocalDate dataPubblicazione = dataDiPubblicazioneField.getValue();
        Boolean digitale = checkDigitale.isSelected();
        Boolean cartaceo = checkCartaceo.isSelected();
        Boolean audiolibro = checkAudiolibro.isSelected();
        String tipo = null;
        //controlla che un radiobutton tra "romanzo" e "didattico" sia selezionato e assegna il valore alla stringa "tipo"
        if (checkRomanzo.isSelected()) {
            tipo = "Romanzo";
        } else if (checkDidattico.isSelected()) {
            tipo = "Didattico";
        }
        //controlla la validità dei dati inseriti nei campi
        try {
            checkDati(tipo, isbn, editore, dataPubblicazione, titolo, cartaceo, digitale, genere);
        } catch (IllegalArgumentException ex) {
            return;
        }
        LibroDAO inserisciLibro = new LibroImplementazionePostgresDAO(); //apertura della connessione col database
        try {
            inserisciLibro.aggiungiLibroDB(isbn, titolo, genere, editore, dataPubblicazione, digitale, cartaceo, audiolibro, tipo); //inserimento del libro nel database
        } catch (SQLException ex) {
            messaggioLabel.setText("ERRORE: ISBN GIA' IN USO"); //errore dato quando viene inserito un libro con isbn già in uso
            return;
        } finally {
            inserisciLibro.close();//chiusura della connessione col database
        }
        resetCampi(); //pulisce i campi
        //messaggio di avvenuto inserimento in verde
        messaggioLabel.setTextFill(Color.web("#00A300"));
        messaggioLabel.setText("LIBRO INSERITO");
    }

    /**
     * Permette la selezione di un solo radiobutton per il tipo del libro
     */
    public void checkTipo() {
        checkRomanzo.setToggleGroup(selezionaTipo);
        checkDidattico.setToggleGroup(selezionaTipo);
    }

    /**
     * Controlla la validità dei dati inseriti.
     *
     * @param tipo              Il tipo di libro inserito
     * @param isbn              L'isbn del libro inserito
     * @param editore           L'editore del libro inserito
     * @param dataPubblicazione La data di pubblicazione del libro inserito
     * @param titolo            Il titolo del libro inserito
     * @param cartaceo          Boolean per la presenza del formato cartaceo del libro inserito
     * @param digitale          Boolean per la presenza del formato digitale del libro inserito
     * @param genere            Il genere o ambito del libro inserito
     * @throws IllegalArgumentException Eccezione lanciata quando uno dei valori inseriti non è valido.
     */
    public void checkDati(String tipo, String isbn, String editore, LocalDate dataPubblicazione, String titolo, Boolean cartaceo, Boolean digitale, String genere) throws IllegalArgumentException {
        messaggioLabel.setTextFill(Color.web("#FF2E2E")); //imposta il messaggio in rosso, nell'eventualità di un errore
        //controlla che l'isbn inserito sia di 13 caratteri e sia composto da soli caratteri numerici, in caso negativo visualizza un apposito messaggio di errore
        if (!isbn.matches("[0-9]{13}") || isbn.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERIRE UN ISBN DI 13 CARATTERI E DI SOLE CIFRE");
            throw new IllegalArgumentException();
        }
        //controlla che il titolo inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (titolo.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERIRE UN TITOLO VALIDO");
            throw new IllegalArgumentException();
        }
        //controlla che il genere inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (genere.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERIRE UN GENERE O AMBITO VALIDO");
            throw new IllegalArgumentException();
        }
        //controlla che sia stato selezionato almeno un formato tra "digitale" e "cartaceo", in caso negativo visualizza un apposito messaggio di errore
        if (!digitale && !cartaceo) {
            messaggioLabel.setText("ERRORE: INSERIRE UN FORMATO TRA 'CARTACEO' E 'DIGITALE'");
            throw new IllegalArgumentException();
        }
        //controlla che l'editore inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (editore.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERIRE UN EDITORE VALIDO");
            throw new IllegalArgumentException();
        }
        //controlla che sia stato scelto un tipo di libro, in caso negativo visualizza un apposito messaggio di errore
        if (tipo == null) {
            messaggioLabel.setText("ERRORE: SCEGLIERE UN TIPO DI LIBRO");
            throw new IllegalArgumentException();
        }
        //controlla che la data di pubblicazione inserita sia valida, in caso negativo visualizza un apposito messaggio di errore
        if (dataPubblicazione == null) {
            messaggioLabel.setText("ERRORE: INSERIRE UNA DATA VALIDA");
            throw new IllegalArgumentException();
        }
    }

    /**
     * Pulisce i campi dopo l'inserimento di un libro
     */
    public void resetCampi() {
        isbnField.clear();
        nomeTestoField.clear();
        genereAmbitoField.clear();
        editoreField.clear();
        checkDidattico.setSelected(false);
        checkRomanzo.setSelected(false);
        checkAudiolibro.setSelected(false);
        checkDigitale.setSelected(false);
        checkCartaceo.setSelected(false);
        dataDiPubblicazioneField.setValue(null);
    }
}










