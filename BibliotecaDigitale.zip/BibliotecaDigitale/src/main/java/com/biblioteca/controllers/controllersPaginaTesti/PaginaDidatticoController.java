package com.biblioteca.controllers.controllersPaginaTesti;

import com.biblioteca.DAO.LibroDidatticoDAO;
import com.biblioteca.ImplementazioneDAO.LibroDidatticoImplementazionePostgresDAO;
import com.biblioteca.model.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

/**
 * Controller dedicato alla gestione della pagina per i libri didattici.
 */
public class PaginaDidatticoController implements Initializable {
    @FXML
    private Label titoloLabel;
    @FXML
    private Label editoreLabel;
    @FXML
    private Label dataUscitaLabel;
    @FXML
    private Label cartaceoLabel;
    @FXML
    private Label digitaleLabel;
    @FXML
    private Label audiolibroLabel;
    @FXML
    private Hyperlink nomeAutore;
    @FXML
    private Hyperlink nomeCollana;
    @FXML
    private Label isbnLabel;
    @FXML
    private Label ambitoLabel;
    @FXML
    private Hyperlink nomeSala;
    @FXML
    private Button modificaLibroDidatticoButton;
    @FXML
    private Label messaggioErroreIsbn;
    @FXML
    private Label messaggioErroreData;
    @FXML
    private TextField modificaEditore;
    @FXML
    private TextField modificaAmbito;
    @FXML
    private DatePicker modificaData;
    @FXML
    private TextField modificaIsbn;
    @FXML
    private ListView<String> listaAutori;
    @FXML
    private Hyperlink nomeNegozi;
    @FXML
    private Button confermaModifiche;
    @FXML
    private ListView<String> listaSale;
    @FXML
    private ListView<String> listaCollane;
    @FXML
    private ListView<String> listaNegozi;
    @FXML
    private RadioButton checkDigitale;
    @FXML
    private RadioButton checkAudiolibro;
    @FXML
    private RadioButton checkCartaceo;
    @FXML
    private Label messaggioErroreFormato;
    @FXML
    private Button elimina;
    @FXML
    private ImageView sfondo;


    /**
     * Libro didattico che viene mostrato nella pagina.
     */
    private LibroDidattico libroDidattico;

    /**
     * Utente che ha aperto la pagina, utilizzato per
     * decidere se l'utente in questione può o meno modificare i
     * dati della pagina.
     */
    private Utente utente;

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    public LibroDidattico getLibroDidattico() {
        return libroDidattico;
    }

    public void setLibroDidattico(LibroDidattico libroDidattico) {
        this.libroDidattico = libroDidattico;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        File sfondoFile = new File("src/Images/paginaDidattico.png");
        Image sfondoImmagine = new Image(sfondoFile.toURI().toString());
        sfondo.setImage(sfondoImmagine);

    }

    /**
     * Imposta le informazioni del libro nella pagina.
     * Utilizza le informazioni già presenti nell'oggetto "libroDidattico".
     * Per le sale, le collane e gli autori effettua delle ricerche
     * nel database tramite diverse classi DAO.
     *
     * @param libroDidatticoSelezionato L'oggetto che si riferisce al libro didattico
     *                                  di cui deve mostrare le informazioni.
     * @param utente                    Oggetto contenente i dati dell'utente che ha aperto la pagina.
     *                                  In base suo tipo verranno visualizzati o meno determinati
     *                                  pulsanti per la modifica delle informazioni nella pagina.
     */
    public void preparaPagina(LibroDidattico libroDidatticoSelezionato, Utente utente) {
        //imposta il romanzo della pagina e l'utente che l'ha aperta
        setLibroDidattico(libroDidatticoSelezionato);
        setUtente(utente);
        //se l'utente è un amministratore, rende visibile il bottone per modificare le informazioni nella pagina
        if (utente.getTipo().equals("Amministratore")) {
            modificaLibroDidatticoButton.setVisible(true);
            modificaLibroDidatticoButton.setDisable(false);
        }
        //imposta le informazioni del romanzo nella pagina
        UtilControllerTesti.setInformazioniBase(libroDidattico.getTitolo(), libroDidattico.getEditore(), libroDidattico.getAmbito(), libroDidattico.getIsbn(), libroDidattico.getGiornopubblicazione(), libroDidattico.getMesepubblicazione(), libroDidattico.getAnnopubblicazione(), editoreLabel, titoloLabel, ambitoLabel, isbnLabel, dataUscitaLabel);
        UtilControllerTesti.setFormati(libroDidattico.getCartaceo(), libroDidattico.getDigitale(), libroDidattico.getAudiolibro(), cartaceoLabel, digitaleLabel, audiolibroLabel);
        libroDidattico.setAutori(UtilControllerTesti.cercaAutoriLibro(libroDidattico.getIsbn())); //ricerca e impostazione degli autori del libro
        libroDidattico.setEsposizioni(UtilControllerTesti.cercaEsposizioni(libroDidattico)); //ricerca e impostazione delle esposizioni del libro
        libroDidattico.setDisponibili(UtilControllerTesti.cercaDisponibilita(libroDidattico)); //ricerca e impostazione delle disponibilità del libro
        libroDidattico.setPartecipazioni(UtilControllerTesti.cercaPartecipazioni(libroDidattico)); //ricerca e impostazione delle partecipazioni del libro
        UtilControllerTesti.setInformazioniHyperLink(nomeCollana, nomeSala, nomeAutore, nomeNegozi, null, null, libroDidattico); //imposta le informazioni con hyperlink del romanzo
    }

    /**
     * Sul click del tasto "Modifica" (visibile solo agli amministratori), visualizza dei text field
     * che contengono le informazioni attuali, e rende possibile la loro modifica.
     */
    public void modificaDidatticoOnAction() {
        UtilControllerTesti.disabilitaCampi(listaSale, listaCollane, listaNegozi, listaAutori, modificaLibroDidatticoButton); //disabilita i label hyperlink
        ambitoLabel.setText("Ambito:");
        //prepara la pagina per la modifica
        UtilControllerTesti.preparaModifica(dataUscitaLabel, isbnLabel, cartaceoLabel, audiolibroLabel, digitaleLabel, modificaEditore, libroDidattico.getEditore(), modificaAmbito, ambitoLabel,
                libroDidattico.getAmbito(), modificaData, modificaIsbn, libroDidattico.getIsbn(), libroDidattico.getGiornopubblicazione(), libroDidattico.getMesepubblicazione(), libroDidattico.getAnnopubblicazione(),
                confermaModifiche, checkCartaceo, checkDigitale, checkAudiolibro, editoreLabel, elimina);
        //imposta i label per l'aggiunta e rimozione di elementi del libro
        UtilControllerTesti.setTastiModifica(nomeSala, nomeCollana, nomeAutore, nomeNegozi, null, null);
        //imposta i formati in base ai valori attuali
        UtilControllerTesti.checkFormati(libroDidattico.getCartaceo(), libroDidattico.getDigitale(), libroDidattico.getAudiolibro(), checkCartaceo, checkDigitale, checkAudiolibro);
    }

    /**
     * Prende il contenuto dei textfield per modificare l'editore, l'ambito e la data
     * del libro didattico. Esegue una query di update per modificare tali valori per quel libro
     * nel database. Se in uno o più campi non sono stati modificati i valori, la query di update
     * verrà comunque eseguita ma con quegli stessi valori.
     */
    public void confermaModificheOnAction() {
        //reset dei messaggi di errore
        messaggioErroreIsbn.setText("");
        messaggioErroreData.setText("");
        messaggioErroreFormato.setText("");
        //prende il contenuto dei campi
        String nuovoEditore = modificaEditore.getText();
        String nuovoAmbito = modificaAmbito.getText();
        LocalDate nuovaData = modificaData.getValue();
        String nuovoIsbn = modificaIsbn.getText();
        //controlla che l'editore inserito sia valido, in caso negativo lo imposta come l'editore già presente
        if (nuovoEditore.isBlank()) {
            nuovoEditore = libroDidattico.getEditore();
        }
        //controlla che il genere inserito sia valido, in caso negativo lo imposta come il genere già presente
        if (nuovoAmbito.isBlank()) {
            nuovoAmbito = libroDidattico.getAmbito();
        }
        if (!UtilControllerTesti.controlloDatiModifica(nuovaData, nuovoIsbn, libroDidattico.getAutori(), messaggioErroreIsbn, messaggioErroreData)) {
            return;
        }
        //ottiene il valore dei radiobutton per ogni formato
        Boolean nuovoFormatoCartaceo = UtilControllerTesti.modificaCartaceo(checkCartaceo);
        Boolean nuovoFormatoDigitale = UtilControllerTesti.modificaDigitale(checkDigitale);
        Boolean nuovoFormatoAudiolibro = UtilControllerTesti.modificaAudiolibro(checkAudiolibro);
        LibroDidatticoDAO modificaLibroDidattico = new LibroDidatticoImplementazionePostgresDAO(); //apertura della connessione col database
        try {
            modificaLibroDidattico.modificaLibroDidatticoDB(libroDidattico.getIsbn(), nuovoEditore, nuovoAmbito, nuovaData, nuovoIsbn, nuovoFormatoCartaceo, nuovoFormatoDigitale, nuovoFormatoAudiolibro);
        } catch (SQLException ex) {
            //messaggio di errore in caso di errore del database
            UtilControllerTesti.setMessaggioErrore(messaggioErroreFormato, messaggioErroreIsbn, nuovoFormatoCartaceo, nuovoFormatoDigitale);
            return;
        } finally {
            modificaLibroDidattico.close(); //chiusura della connessione
        }
        //imposta tutti i nuovi valori al libro
        libroDidattico.setEditore(nuovoEditore);
        libroDidattico.setData(nuovaData);
        libroDidattico.setAmbito(nuovoAmbito);
        libroDidattico.setIsbn(nuovoIsbn);
        libroDidattico.setCartaceo(nuovoFormatoCartaceo);
        libroDidattico.setDigitale(nuovoFormatoDigitale);
        libroDidattico.setAudiolibro(nuovoFormatoAudiolibro);
        resetModificheOnAction(); //esce dalla modalità di modifica
        preparaPagina(libroDidattico, utente); //ricarica le informazioni nella pagina
    }

    /**
     * Sul click del tasto "Annulla", rimuove gli elementi che sono visualizzati quando viene premuto il tasto "Modifica".
     */
    public void resetModificheOnAction() {
        UtilControllerTesti.setInformazioniHyperLink(nomeCollana, nomeSala, nomeAutore, nomeNegozi, null, null, libroDidattico);
        UtilControllerTesti.setInformazioniBase(libroDidattico.getTitolo(), libroDidattico.getEditore(), libroDidattico.getAmbito(), libroDidattico.getIsbn(), libroDidattico.getGiornopubblicazione(), libroDidattico.getMesepubblicazione(), libroDidattico.getAnnopubblicazione(), editoreLabel, titoloLabel, ambitoLabel, isbnLabel, dataUscitaLabel);
        UtilControllerTesti.setFormati(libroDidattico.getCartaceo(), libroDidattico.getDigitale(), libroDidattico.getAudiolibro(), cartaceoLabel, digitaleLabel, audiolibroLabel);
        UtilControllerTesti.chiudiPannelliInformazioni(listaAutori, listaSale, listaCollane, listaNegozi);
        UtilControllerTesti.chiudiModifiche(modificaEditore, modificaAmbito, modificaData, modificaLibroDidatticoButton, confermaModifiche, modificaIsbn, checkCartaceo, checkDigitale, checkAudiolibro, messaggioErroreIsbn, messaggioErroreData, messaggioErroreFormato, elimina);
    }


    /**
     * Se esistono più sale per il libro, apre una lista che contiene i loro nomi.
     * Altrimenti apre la pagina dell'unica sala del libro.
     * Se si è in modalità modifica, aprirà invece la pagina per aggiungere e/o
     * rimuovere esposizioni.
     */
    public void visualizzaSale() throws IOException {
        if (nomeSala.getText().equals("Aggiungi/Rimuovi esposizione.")) {
            UtilControllerTesti.visualizzaGestioneSala(libroDidattico);
        } else if (libroDidattico.getEsposizioni().size() > 1) {
            UtilControllerTesti.visualizzaSale(libroDidattico.getEsposizioni(), listaSale);
            UtilControllerTesti.gestisciVisualizzazioneListe(listaAutori, listaCollane, listaNegozi, listaSale, listaSale);
        } else if (libroDidattico.getEsposizioni().size() == 1) {
            UtilControllerTesti.visualizzaSalaSelezionata(libroDidattico.getEsposizioni().get(0).getSala(), utente);
        }
    }

    /**
     * Sul click di uno delle sale della lista, chiama il metodo per aprire la pagina
     * relativa a quella sala.
     */
    public void mostraSalaSelezionata() throws IOException {
        try {
            int elementoSelezionato = listaSale.getSelectionModel().getSelectedIndex();
            UtilControllerTesti.visualizzaSalaSelezionata(libroDidattico.getEsposizioni().get(elementoSelezionato).getSala(), utente);

        } catch (IndexOutOfBoundsException ignored) {
            //ignora l'eccezione nata dal click su uno spazio vuoto della lista
        }
    }

    /**
     * Se esistono più autori per il libro, apre una lista che contiene i loro nomi.
     * Altrimenti apre la pagina dell'unico autore del libro.
     * * Se si è in modalità modifica, aprirà invece la pagina per aggiungere e/o
     * rimuovere autori.
     */
    public void visualizzaAutori() throws IOException {
        if (nomeAutore.getText().equals("Aggiungi/Rimuovi autore.")) {
            UtilControllerTesti.visualizzaGestioneAutore(libroDidattico);
        } else if (libroDidattico.getAutori().size() > 1) {
            listaAutori.getItems().clear();
            UtilControllerTesti.gestisciVisualizzazioneListe(listaAutori, listaCollane, listaNegozi, listaSale, listaAutori);
            for (Autore autore : libroDidattico.getAutori()) {
                listaAutori.getItems().addAll(autore.getNominativo());
            }
        } else if (libroDidattico.getAutori().size() == 1) {
            UtilControllerTesti.visualizzaAutore(libroDidattico.getAutori().get(0), utente);
        }

    }


    /**
     * Sul click di uno degli autori della lista, chiama il metodo per aprire la pagina
     * relativa a quell'autore.
     */
    public void mostraAutoreSelezionato() throws IOException {
        try {
            int elementoSelezionato = listaAutori.getSelectionModel().getSelectedIndex();
            UtilControllerTesti.visualizzaAutore(libroDidattico.getAutori().get(elementoSelezionato), utente);
        } catch (IndexOutOfBoundsException ignored) {
            //ignora l'eccezione nata dal click su uno spazio vuoto della lista
        }
    }

    /**
     * Se esistono più collane per il libro, apre una lista che contiene i loro nomi.
     * Altrimenti apre la pagina dell'unica collana del romanzo.
     * Se si è in modalità modifica, aprirà invece la pagina per aggiungere e/o
     * rimuovere collane.
     */
    public void visualizzaCollane() throws IOException {
        if (nomeCollana.getText().equals("Aggiungi/Rimuovi collana.")) {
            UtilControllerTesti.visualizzaGestioneCollana(libroDidattico);
        } else if (libroDidattico.getPartecipazioni().size() > 1) {
            listaCollane.getItems().clear();
            UtilControllerTesti.gestisciVisualizzazioneListe(listaAutori, listaCollane, listaNegozi, listaSale, listaCollane);
            for (Partecipazione partecipazione : libroDidattico.getPartecipazioni()) {
                listaCollane.getItems().addAll(partecipazione.collana.getNome());
            }
        } else if (libroDidattico.getPartecipazioni().size() == 1) {
            UtilControllerTesti.visualizzaCollana(libroDidattico.getPartecipazioni().get(0).getCollana(), utente);
        }

    }


    /**
     * Sul click di uno delle collane della lista, chiama il metodo per aprire la pagina
     * relativa a quella collana.
     */
    public void mostraCollanaSelezionata() throws IOException {
        try {
            int elementoSelezionato = listaCollane.getSelectionModel().getSelectedIndex();
            UtilControllerTesti.visualizzaCollana(libroDidattico.getPartecipazioni().get(elementoSelezionato).getCollana(), utente);
        } catch (IndexOutOfBoundsException ignored) {
            //ignora l'eccezione nata dal click su uno spazio vuoto della lista
        }
    }

    /**
     * Se esistono più negozi per il libro, apre una lista che contiene i loro nomi.
     * Altrimenti apre la pagina dell'unico negozio del romanzo.
     * Se si è in modalità modifica, aprirà invece la pagina per aggiungere e/o
     * rimuovere negozi.
     */
    public void visualizzaNegozi() throws IOException {
        if (nomeNegozi.getText().equals("Aggiungi/Rimuovi negozio.")) {
            UtilControllerTesti.visualizzaGestioneNegozio(libroDidattico);
        } else if (libroDidattico.getDisponibili().size() > 1) {
            listaNegozi.getItems().clear();
            UtilControllerTesti.gestisciVisualizzazioneListe(listaAutori, listaCollane, listaNegozi, listaSale, listaNegozi);
            for (Disponibilita disponibilita : libroDidattico.getDisponibili()) {
                listaNegozi.getItems().addAll(disponibilita.negozio.getNome() + " | €" + disponibilita.getPrezzo());
            }
        } else if (libroDidattico.getDisponibili().size() == 1) {
            UtilControllerTesti.visualizzaNegozio(libroDidattico.getDisponibili().get(0).getNegozio(), utente);
        }
    }

    /**
     * Sul click di uno dei negozi della lista, chiama il metodo per aprire la pagina
     * relativa a quel negozio.
     */
    public void mostraNegozioSelezionato() throws IOException {
        try {
            int elementoSelezionato = listaNegozi.getSelectionModel().getSelectedIndex();
            UtilControllerTesti.visualizzaNegozio(libroDidattico.getDisponibili().get(elementoSelezionato).getNegozio(), utente);
        } catch (IndexOutOfBoundsException ignored) {
            //ignora l'eccezione nata dal click su uno spazio vuoto della lista
        }
    }

    /**
     * Aggiorna le informazioni della pagina dopo aver premuto
     * il tasto F5.
     */
    public void refresh(KeyEvent keyEvent) {
        if (keyEvent.getCode() == KeyCode.F5) {
            UtilControllerTesti.chiudiPannelliInformazioni(listaAutori, listaSale, listaCollane, listaNegozi);
            preparaPagina(libroDidattico, utente);
        }
    }

    /**
     * Sul click del tasto "Elimina", cancella il libro della pagina.
     */
    public void eliminaOnAction() {
        UtilControllerTesti.eliminaLibro(libroDidattico);
        Stage stage = (Stage) elimina.getScene().getWindow(); //chiude la pagina
        stage.close();
    }


}
