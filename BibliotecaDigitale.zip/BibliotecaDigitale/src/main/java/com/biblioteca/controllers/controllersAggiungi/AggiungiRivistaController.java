package com.biblioteca.controllers.controllersAggiungi;

import com.biblioteca.DAO.RivistaDAO;
import com.biblioteca.ImplementazioneDAO.RivistaImplementazionePostgresDAO;
import com.biblioteca.model.Rivista;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Controller dedicato alla gestione della pagina per l'inserimento di riviste.
 */
public class AggiungiRivistaController {
    @FXML
    private TextField issnField;
    @FXML
    private TextField nomeRivistaField;
    @FXML
    private TextField annoPubblicazioneField;
    @FXML
    private TextField numeroField;
    @FXML
    private TextField temaField;

    @FXML
    private TextField responsabileField;
    @FXML
    private Label messaggioLabel;


    /**
     * Sul click del tasto "Conferma", ottiene il contenuto dei campi, ne verifica la validità, e inserisce una rivista
     * con quei valori nel database.
     */
    public void confermaOnAction() {
        //ottiene il contenuto dei campi
        String issn = issnField.getText();
        String nome = nomeRivistaField.getText();
        int numero;
        String tema = temaField.getText();
        String responsabile = responsabileField.getText();
        int annopubblicazione;
        //controlla che il numero e l'anno di pubblicazione siano validi
        try {
            numero = Integer.parseInt(numeroField.getText());
        } catch (NumberFormatException ex) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("ERRORE: INSERIRE UN NUMERO VALIDO");
            return;
        }
        try {
            annopubblicazione = Integer.parseInt(annoPubblicazioneField.getText());
        } catch (NumberFormatException ex) {
            messaggioLabel.setTextFill(Color.web("#FF2E2E"));
            messaggioLabel.setText("ERRORE: INSERIRE UN ANNO VALIDO");
            return;
        }
        //controlla che i dati inseriti siano validi
        try {
            CheckDati(issn, nome, tema, responsabile, numero, annopubblicazione);

        } catch (IllegalArgumentException ex) {
            return;
        }
        RivistaDAO aggiungiRivista = new RivistaImplementazionePostgresDAO(); //apertura della connessione col database
        ArrayList<Rivista> rivisteTrovate = new ArrayList<>();
        ArrayList<Integer> numeriRiviste = new ArrayList<>();
        ArrayList<String> nomiRiviste = new ArrayList<>();
        ArrayList<String> temiRiviste = new ArrayList<>();
        ArrayList<Integer> anniPubblicazioneRiviste = new ArrayList<>();
        ArrayList<String> responsabiliRiviste = new ArrayList<>();
        //cerca tutte le riviste con issn uguale a quello inserito, e controlla che le date di pubblicazione e i numeri di uscita siano coerenti cronologicamente
        try {
            aggiungiRivista.cercaRivistaPerIssn(issn, nomiRiviste, numeriRiviste, temiRiviste, anniPubblicazioneRiviste, responsabiliRiviste);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        //per ogni rivista trovata, crea un oggetto e lo aggiunge all'arraylist di riviste trovate
        for (int i = 0; i < numeriRiviste.size(); i++) {
            Rivista rivista = new Rivista(issn, nomiRiviste.get(i), temiRiviste.get(i), anniPubblicazioneRiviste.get(i), responsabiliRiviste.get(i), numeriRiviste.get(i));
            rivisteTrovate.add(rivista);
        }
        //per ogni rivista trovata effettua il controllo
        for (Rivista rivista : rivisteTrovate) {
            if (rivista.getNumero() > numero && rivista.getAnno() < annopubblicazione) {
                messaggioLabel.setText("ERRORE: LA RIVISTA INSERITA NON PUO ESSERE ANTECEDENTE AD UNA RIVISTA DI UN NUMERO PRECEDENTE");
                return;
            } else if (rivista.getNumero() < numero && rivista.getAnno() > annopubblicazione) {
                messaggioLabel.setText("ERRORE: LA RIVISTA INSERITA NON PUO ESSERE PRECEDENTE AD UNA RIVISTA DI UN NUMERO ANTECEDENTE");
                return;
            }
        }
        try {
            aggiungiRivista.aggiungiRivistaDB(issn, numero, nome, tema, responsabile, annopubblicazione); //inserimento della rivista nel database
        } catch (SQLException ex) {
            messaggioLabel.setText("ERRORE: ISSN E NUMERO GIA' IN USO"); //errore dato quando viene inserito una rivista con issn e numero già in uso
            return;
        } finally {
            aggiungiRivista.close(); //chiusura della connessione col database
        }
        //messaggio di avvenuto inserimento
        messaggioLabel.setTextFill(Color.web("#00A300"));
        messaggioLabel.setText("RIVISTA AGGIUNTA");
        resetCampi();
    }


    /**
     * Verifica la validità delle informazioni inserite
     *
     * @param issn              Issn della rivista che si vuole inserire
     * @param numero            Numero della rivista che si vuole inserire
     * @param nome              Nome della rivista che si vuole inserire
     * @param tema              Tema della rivista che si vuole inserire
     * @param responsabile      Nome del responsabile della rivista che si vuole inserire
     * @param annoPubblicazione Anno di pubblicazione della rivista che si vuole inserire
     */
    public void CheckDati(String issn, String nome, String tema, String responsabile, int numero, int annoPubblicazione) {
        messaggioLabel.setTextFill(Color.web("#FF2E2E")); //imposta il messaggio in rosso, nell'eventualità di un errore
        //controlla che l'issn inserito sia nel formato dell'espressione regolare nella condizione, in caso negativo visualizza un apposito messaggio di errore
        if (issn.isBlank() || !issn.matches("[0-9]{4}-[0-9]{4}")) {
            messaggioLabel.setText("ERRORE: INSERISCI UN ISSN VALIDO");
            throw new IllegalArgumentException();
        }
        //controlla che il nome inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (nome.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERISCI UN NOME");
            throw new IllegalArgumentException();
        }
        //controlla che il tema inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (tema.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERISCI UN TEMA");
            throw new IllegalArgumentException();
        }
        //controlla che il numero inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (numero <= 0) {
            messaggioLabel.setText("ERRORE: NUMERO NON VALIDO");
            throw new IllegalArgumentException();
        }
        //controlla che l'anno di pubblicazione inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (annoPubblicazione <= 0) {
            messaggioLabel.setText("ERRRORE: INSERISCI UN ANNO VALIDO");
            throw new IllegalArgumentException();
        }
        //controlla che il nome del responsabile inserito sia valido, in caso negativo visualizza un apposito messaggio di errore
        if (responsabile.isBlank()) {
            messaggioLabel.setText("ERRORE: INSERISCI UN RESPONSABILE");
            throw new IllegalArgumentException();
        }
    }

    /**
     * Pulisce i campi dopo l'inserimento di una rivista
     */
    public void resetCampi() {
        issnField.clear();
        numeroField.clear();
        nomeRivistaField.clear();
        annoPubblicazioneField.clear();
        responsabileField.clear();
        temaField.clear();
    }
}
