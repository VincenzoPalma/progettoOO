package com.biblioteca.controllers.controllersPaginaLibri;

import com.biblioteca.DAO.LibroDidatticoDAO;
import com.biblioteca.ImplementazioneDAO.LibroDidatticoImplementazionePostgresDAO;
import com.biblioteca.model.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;

/**
 * Controller dedicato alla gestione della pagina per i libri didattici.
 */
public class PaginaDidatticoController {
    @FXML
    private Label titoloLabel;
    @FXML
    private Label editoreLabel;
    @FXML
    private Label dataUscitaLabel;
    @FXML
    private Label cartaceoLabel;
    @FXML
    private Label digitaleLabel;
    @FXML
    private Label audiolibroLabel;
    @FXML
    private Hyperlink nomeAutore;
    @FXML
    private Hyperlink nomeCollana;
    @FXML
    private Label isbnLabel;
    @FXML
    private Label ambitoLabel;
    @FXML
    private Hyperlink nomeSala;
    @FXML
    private Button modificaLibroDidattico;
    @FXML
    private Label messaggioErroreIsbn;
    @FXML
    private Label messaggioErroreData;
    @FXML
    private TextField modificaEditore;
    @FXML
    private TextField modificaAmbito;
    @FXML
    private DatePicker modificaData;
    @FXML
    private TextField modificaIsbn;
    @FXML
    private ListView<String> listView;
    @FXML
    private Hyperlink nomeNegozi;
    @FXML
    private Button confermaModifiche;
    @FXML
    private ListView<String> listaSale;
    @FXML
    private ListView<String> listaCollane;
    @FXML
    private ListView<String> listaNegozi;
    @FXML
    private Button annullaModifiche;
    @FXML
    private RadioButton checkDigitale;
    @FXML
    private RadioButton checkAudiolibro;
    @FXML
    private RadioButton checkCartaceo;
    @FXML
    private Label messaggioErroreFormatoLabel;
    @FXML
    private Button elimina;


    /**
     * Libro didattico che viene mostrato nella pagina.
     */
    private LibroDidattico libroDidattico;

    /**
     * Utente che ha aperto la pagina, utilizzato per
     * decidere se l'utente in questione può o meno modificare i
     * dati della pagina.
     */
    private Utente utente;

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    public LibroDidattico getLibroDidattico() {
        return libroDidattico;
    }

    public void setLibroDidattico(LibroDidattico libroDidattico) {
        this.libroDidattico = libroDidattico;
    }

    /**
     * Imposta le informazioni del libro nella pagina.
     * Utilizza le informazioni già presenti nell'oggetto "libroDidattico".
     * Per le sale, le collane e gli autori effettua delle ricerche
     * nel database tramite diverse classi DAO.
     *
     * @param libroDidatticoSelezionato L'oggetto che si riferisce al libro didattico
     *                                  di cui deve mostrare le informazioni.
     * @param utente                    Oggetto contenente i dati dell'utente che ha aperto la pagina.
     *                                  In base suo tipo verranno visualizzati o meno determinati
     *                                  pulsanti per la modifica delle informazioni nella pagina.
     */
    public void preparaPagina(LibroDidattico libroDidatticoSelezionato, Utente utente) {
        //imposta il romanzo della pagina e l'utente che l'ha aperta
        setLibroDidattico(libroDidatticoSelezionato);
        setUtente(utente);
        //se l'utente è un amministratore, rende visibile il bottone per modificare le informazioni nella pagina
        if (utente.getTipo().equals("Amministratore")) {
            modificaLibroDidattico.setVisible(true);
            modificaLibroDidattico.setDisable(false);
        }
        //imposta le informazioni del romanzo nella pagina
        UtilControllerLibri.setInformazioniBase("Didattico", libroDidattico.getTitolo(), libroDidattico.getEditore(), libroDidattico.getAmbito(), libroDidattico.getIsbn(), libroDidattico.getGiornopubblicazione(), libroDidattico.getMesepubblicazione(), libroDidattico.getAnnopubblicazione(), editoreLabel, titoloLabel, ambitoLabel, isbnLabel, dataUscitaLabel);
        UtilControllerLibri.setFormati(libroDidattico.getCartaceo(), libroDidattico.getDigitale(), libroDidattico.getAudiolibro(), cartaceoLabel, digitaleLabel, audiolibroLabel);
        libroDidattico.setAutori(UtilControllerLibri.cercaAutori(libroDidattico.getIsbn())); //ricerca e impostazione degli autori del libro
        libroDidattico.setEsposizioni(UtilControllerLibri.cercaEsposizioni(libroDidattico)); //ricerca e impostazione delle esposizioni del libro
        libroDidattico.setDisponibili(UtilControllerLibri.cercaDisponibilita(libroDidattico)); //ricerca e impostazione delle disponibilità del libro
        libroDidattico.setPartecipazioni(UtilControllerLibri.cercaPartecipazioni(libroDidattico)); //ricerca e impostazione delle partecipazioni del libro
        UtilControllerLibri.setInformazioniHyperLink(nomeCollana, nomeSala, nomeAutore, nomeNegozi, null, null, libroDidattico); //imposta le informazioni con hyperlink del romanzo
    }

    /**
     * Sul click del tasto "Modifica" (visibile solo agli amministratori), visualizza dei text field
     * che contengono le informazioni attuali, e rende possibile la loro modifica.
     */
    public void modificaDidatticoOnAction() {
        UtilControllerLibri.disabilitaCampi(listaSale, listaCollane, listaNegozi, listView, modificaLibroDidattico); //disabilita i label hyperlink
        ambitoLabel.setText("Ambito:");
        //prepara la pagina per la modifica
        UtilControllerLibri.preparaModifica(dataUscitaLabel, isbnLabel, cartaceoLabel, audiolibroLabel, digitaleLabel, modificaEditore, libroDidattico.getEditore(), modificaAmbito,
                libroDidattico.getAmbito(), modificaData, modificaIsbn, libroDidattico.getIsbn(), libroDidattico.getGiornopubblicazione(), libroDidattico.getMesepubblicazione(), libroDidattico.getAnnopubblicazione(),
                confermaModifiche, checkCartaceo, checkDigitale, checkAudiolibro, editoreLabel, elimina);
        //imposta i label per l'aggiunta e rimozione di elementi del libro
        UtilControllerLibri.setTastiModifica(nomeSala, nomeCollana, nomeAutore, nomeNegozi, null, null);
        //imposta i formati in base ai valori attuali
        UtilControllerLibri.checkFormati(libroDidattico.getCartaceo(), libroDidattico.getDigitale(), libroDidattico.getAudiolibro(), checkCartaceo, checkDigitale, checkAudiolibro);
    }

    /**
     * Prende il contenuto dei textfield per modificare l'editore, l'ambito e la data
     * del libro didattico. Esegue una query di update per modificare tali valori per quel libro
     * nel database. Se in uno o più campi non sono stati modificati i valori, la query di update
     * verrà comunque eseguita ma con quegli stessi valori.
     */
    public void confermaModificheOnAction() {
        //prende il contenuto dei campi
        String nuovoEditore = modificaEditore.getText();
        String nuovoAmbito = modificaAmbito.getText();
        LocalDate nuovaData = modificaData.getValue();
        String nuovoIsbn = modificaIsbn.getText();
        //controlla che l'editore inserito sia valido, in caso negativo lo imposta come l'editore già presente
        if (nuovoEditore.isBlank()) {
            nuovoEditore = libroDidattico.getEditore();
        }
        //controlla che il genere inserito sia valido, in caso negativo lo imposta come il genere già presente
        if (nuovoAmbito.isBlank()) {
            nuovoAmbito = libroDidattico.getAmbito();
        }
        if (!UtilControllerLibri.controlloDatiModifica(nuovaData, nuovoIsbn, libroDidattico.getAutori(), messaggioErroreIsbn, messaggioErroreData)) {
            return;
        }
        //ottiene il valore dei radiobutton per ogni formato
        Boolean nuovoFormatoCartaceo = UtilControllerLibri.modificaCartaceo(checkCartaceo);
        Boolean nuovoFormatoDigitale = UtilControllerLibri.modificaDigitale(checkDigitale);
        Boolean nuovoFormatoAudiolibro = UtilControllerLibri.modificaAudiolibro(checkAudiolibro);
        LibroDidatticoDAO modificaLibroDidattico = new LibroDidatticoImplementazionePostgresDAO(); //apertura della connessione col database
        try {
            modificaLibroDidattico.modificaLibroDidatticoDB(libroDidattico.getIsbn(), nuovoEditore, nuovoAmbito, nuovaData, nuovoIsbn, nuovoFormatoCartaceo, nuovoFormatoDigitale, nuovoFormatoAudiolibro);
        } catch (SQLException ex) {
            //messaggio di errore in caso di errore del database
            UtilControllerLibri.setMessaggioErrore(messaggioErroreFormatoLabel, messaggioErroreIsbn, nuovoFormatoCartaceo, nuovoFormatoDigitale);
            return;
        } finally {
            modificaLibroDidattico.close(); //chiusura della connessione
        }
        //imposta tutti i nuovi valori al libro
        libroDidattico.setEditore(nuovoEditore);
        libroDidattico.setData(nuovaData);
        libroDidattico.setAmbito(nuovoAmbito);
        libroDidattico.setIsbn(nuovoIsbn);
        libroDidattico.setCartaceo(nuovoFormatoCartaceo);
        libroDidattico.setDigitale(nuovoFormatoDigitale);
        libroDidattico.setAudiolibro(nuovoFormatoAudiolibro);
        resetModificheOnAction(); //esce dalla modalità di modifica
        preparaPagina(libroDidattico, utente); //ricarica le informazioni nella pagina
    }

    /**
     * Sul click del tasto "Annulla", rimuove gli elementi che sono visualizzati quando viene premuto il tasto "Modifica".
     */
    public void resetModificheOnAction() {
        UtilControllerLibri.setInformazioniHyperLink(nomeCollana, nomeSala, nomeAutore, nomeNegozi, null, null, libroDidattico);
        UtilControllerLibri.setInformazioniBase("Didattico", libroDidattico.getTitolo(), libroDidattico.getEditore(), libroDidattico.getAmbito(), libroDidattico.getIsbn(), libroDidattico.getGiornopubblicazione(), libroDidattico.getMesepubblicazione(), libroDidattico.getAnnopubblicazione(), editoreLabel, titoloLabel, ambitoLabel, isbnLabel, dataUscitaLabel);
        UtilControllerLibri.setFormati(libroDidattico.getCartaceo(), libroDidattico.getDigitale(), libroDidattico.getAudiolibro(), cartaceoLabel, digitaleLabel, audiolibroLabel);
        UtilControllerLibri.chiudiPannelliInformazioni(listView, listaSale, listaCollane, listaNegozi);
        UtilControllerLibri.chiudiModifiche(modificaEditore, modificaAmbito, modificaData, modificaLibroDidattico, confermaModifiche, modificaIsbn, checkCartaceo, checkDigitale, checkAudiolibro, messaggioErroreIsbn, messaggioErroreData, messaggioErroreFormatoLabel, elimina);
    }


    /**
     * Se esistono più sale per il libro, apre una lista che contiene i loro nomi.
     * Altrimenti apre la pagina dell'unica sala del libro.
     * Se si è in modalità modifica, aprirà invece la pagina per aggiungere e/o
     * rimuovere esposizioni.
     */
    public void visualizzaSale() throws IOException {
        if (nomeSala.getText().equals("Aggiungi/Rimuovi esposizione.")) {
            UtilControllerLibri.visualizzaGestioneSala(libroDidattico);
        } else if (libroDidattico.getEsposizioni().size() > 1) {
            UtilControllerLibri.visualizzaSale(libroDidattico.getEsposizioni(), listaSale);
            UtilControllerLibri.gestisciVisualizzazioneListe(listView, listaCollane, listaNegozi, listaSale, listaSale);
        } else if (libroDidattico.getEsposizioni().size() == 1) {
            UtilControllerLibri.visualizzaSalaSelezionata(libroDidattico.getEsposizioni().get(0).getSala(), utente);
        }
    }

    /**
     * Sul click di uno delle sale della lista, chiama il metodo per aprire la pagina
     * relativa a quella sala.
     */
    public void mostraSalaSelezionata() throws IOException {
        try {
            int elementoSelezionato = listaSale.getSelectionModel().getSelectedIndex();
            UtilControllerLibri.visualizzaSalaSelezionata(libroDidattico.getEsposizioni().get(elementoSelezionato).getSala(), utente);

        } catch (IndexOutOfBoundsException ignored) {
            //ignora l'eccezione nata dal click su uno spazio vuoto della lista
        }
    }

    /**
     * Se esistono più autori per il libro, apre una lista che contiene i loro nomi.
     * Altrimenti apre la pagina dell'unico autore del libro.
     * * Se si è in modalità modifica, aprirà invece la pagina per aggiungere e/o
     * rimuovere autori.
     */
    public void visualizzaAutori() throws IOException {
        if (nomeAutore.getText().equals("Aggiungi/Rimuovi autore.")) {
            UtilControllerLibri.visualizzaGestioneAutore(libroDidattico);
        } else if (libroDidattico.getAutori().size() > 1) {
            listView.getItems().clear();
            UtilControllerLibri.gestisciVisualizzazioneListe(listView, listaCollane, listaNegozi, listaSale, listView);
            for (Autore autore : libroDidattico.getAutori()) {
                listView.getItems().addAll(autore.getNominativo());
            }
        } else if (libroDidattico.getAutori().size() == 1) {
            UtilControllerLibri.visualizzaAutore(libroDidattico.getAutori().get(0), utente, libroDidattico);
        }

    }


    /**
     * Sul click di uno degli autori della lista, chiama il metodo per aprire la pagina
     * relativa a quell'autore.
     */
    public void mostraAutoreSelezionato() throws IOException {
        try {
            int elementoSelezionato = listView.getSelectionModel().getSelectedIndex();
            UtilControllerLibri.visualizzaAutore(libroDidattico.getAutori().get(elementoSelezionato), utente, libroDidattico);
        } catch (IndexOutOfBoundsException ignored) {
            //ignora l'eccezione nata dal click su uno spazio vuoto della lista
        }
    }

    /**
     * Se esistono più collane per il libro, apre una lista che contiene i loro nomi.
     * Altrimenti apre la pagina dell'unica collana del romanzo.
     * Se si è in modalità modifica, aprirà invece la pagina per aggiungere e/o
     * rimuovere collane.
     */
    public void visualizzaCollane() throws IOException {
        if (nomeCollana.getText().equals("Aggiungi/Rimuovi collana.")) {
            UtilControllerLibri.visualizzaGestioneCollana(libroDidattico);
        } else if (libroDidattico.getPartecipazioni().size() > 1) {
            listaCollane.getItems().clear();
            UtilControllerLibri.gestisciVisualizzazioneListe(listView, listaCollane, listaNegozi, listaSale, listaCollane);
            for (Partecipazione partecipazione : libroDidattico.getPartecipazioni()) {
                listaCollane.getItems().addAll(partecipazione.collana.getNome());
            }
        } else if (libroDidattico.getPartecipazioni().size() == 1) {
            UtilControllerLibri.visualizzaCollana(libroDidattico.getPartecipazioni().get(0).getCollana(), utente);
        }

    }


    /**
     * Sul click di uno delle collane della lista, chiama il metodo per aprire la pagina
     * relativa a quella collana.
     */
    public void mostraCollanaSelezionata() throws IOException {
        try {
            int elementoSelezionato = listaCollane.getSelectionModel().getSelectedIndex();
            UtilControllerLibri.visualizzaCollana(libroDidattico.getPartecipazioni().get(elementoSelezionato).getCollana(), utente);
        } catch (IndexOutOfBoundsException ignored) {
            //ignora l'eccezione nata dal click su uno spazio vuoto della lista
        }
    }

    /**
     * Se esistono più negozi per il libro, apre una lista che contiene i loro nomi.
     * Altrimenti apre la pagina dell'unico negozio del romanzo.
     * Se si è in modalità modifica, aprirà invece la pagina per aggiungere e/o
     * rimuovere negozi.
     */
    public void visualizzaNegozi() throws IOException {
        if (nomeNegozi.getText().equals("Aggiungi/Rimuovi negozio.")) {
            UtilControllerLibri.visualizzaGestioneNegozio(libroDidattico);
        } else if (libroDidattico.getDisponibili().size() > 1) {
            listaNegozi.getItems().clear();
            UtilControllerLibri.gestisciVisualizzazioneListe(listView, listaCollane, listaNegozi, listaSale, listaNegozi);
            for (Disponibilita disponibilita : libroDidattico.getDisponibili()) {
                listaNegozi.getItems().addAll(disponibilita.negozio.getNome());
            }
        } else if (libroDidattico.getDisponibili().size() == 1) {
            UtilControllerLibri.visualizzaNegozio(libroDidattico.getDisponibili().get(0).getNegozio(), utente);
        }
    }

    /**
     * Sul click di uno dei negozi della lista, chiama il metodo per aprire la pagina
     * relativa a quel negozio.
     */
    public void mostraNegozioSelezionato() throws IOException {
        try {
            int elementoSelezionato = listaNegozi.getSelectionModel().getSelectedIndex();
            UtilControllerLibri.visualizzaNegozio(libroDidattico.getDisponibili().get(elementoSelezionato).getNegozio(), utente);
        } catch (IndexOutOfBoundsException ignored) {
            //ignora l'eccezione nata dal click su uno spazio vuoto della lista
        }
    }

    /**
     * Aggiorna le informazioni della pagina dopo aver premuto
     * il tasto F5.
     */
    public void refresh(KeyEvent keyEvent) {
        if (keyEvent.getCode() == KeyCode.F5) {
            UtilControllerLibri.chiudiPannelliInformazioni(listView, listaSale, listaCollane, listaNegozi);
            preparaPagina(libroDidattico, utente);
        }
    }

    /**
     * Sul click del tasto "Elimina", cancella il libro della pagina.
     */
    public void eliminaOnAction() {
        UtilControllerLibri.eliminaLibro(libroDidattico);
        Stage stage = (Stage) elimina.getScene().getWindow(); //chiude la pagina
        stage.close();
    }


}
