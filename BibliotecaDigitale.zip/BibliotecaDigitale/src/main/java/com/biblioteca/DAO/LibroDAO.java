package com.biblioteca.DAO;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

public interface LibroDAO extends CloseableDAO {

    void aggiungiLibroDB(String isbn, String titolo, String genere, String editore, LocalDate datapubblicazione, Boolean cartaceo, Boolean digitale, Boolean audiolibro, String tipo) throws SQLException;

    void eliminaLibroDB(String isbn) throws SQLException;

    void cercaLibroPerNegozio(int idNegozio, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> generi, ArrayList<LocalDate> dateUscita, ArrayList<String> tipi, ArrayList<String> editore, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException;

    void cercaLibriPerAutore(int idAutore, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> generi, ArrayList<LocalDate> dateUscita, ArrayList<String> tipi, ArrayList<String> editore, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException;

    void cercaLibroPerSala(int idSala, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> generi, ArrayList<LocalDate> dateUscita, ArrayList<String> tipoLibri, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException;

    void cercaLibroPerCollana(String issnCollana, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> generi, ArrayList<LocalDate> dateUscita, ArrayList<String> tipoLibri, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException;
}
