package com.biblioteca.DAO;

import java.sql.SQLException;
import java.util.ArrayList;

public interface SalaDAO extends CloseableDAO {

    void aggiungiSalaDB(String nome, String indirizzo, int capienza) throws SQLException;

    void modificaSalaDB(int idSala, String nome, String indirizzo, int capienza) throws SQLException;

    void eliminaSalaDB(int idsala) throws SQLException;

    void cercaSalaPerIdDB(int idSala, ArrayList<String> nomeSale, ArrayList<String> indirizziSale, ArrayList<Integer> capienzaSale) throws SQLException;

    void getAllSale(ArrayList<Integer> idSale, ArrayList<String> nomeSale, ArrayList<String> indirizziSale, ArrayList<Integer> capienzaSale) throws SQLException;
}
