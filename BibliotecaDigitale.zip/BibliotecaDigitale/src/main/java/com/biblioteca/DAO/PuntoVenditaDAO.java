package com.biblioteca.DAO;

import java.sql.SQLException;
import java.util.ArrayList;

public interface PuntoVenditaDAO extends CloseableDAO {

    void aggiungiPuntoVenditaDB(String citta, String nome, int idnegozio) throws SQLException;

    void cercaPuntoVenditaPerIdNegozio(int idNegozio, ArrayList<Integer> idPuntiVendita, ArrayList<String> nomiPuntoVendita, ArrayList<String> cittaPuntoVendita) throws SQLException;
}
