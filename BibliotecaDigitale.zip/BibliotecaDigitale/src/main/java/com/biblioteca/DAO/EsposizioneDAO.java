package com.biblioteca.DAO;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

public interface EsposizioneDAO extends CloseableDAO {

    void aggiungiEsposizioneDB(int idSala, String isbn, LocalDate dataEsposizione) throws SQLException;

    void eliminaEsposizioneDB(String isbn, int idsala) throws SQLException;

    void cercaEsposizioniPerIsbnDB(String isbn, ArrayList<Integer> idSale, ArrayList<LocalDate> dateEsposizioni) throws SQLException;

    void cercaEsposizioniPerIdSala(int idSala, ArrayList<String> isbnLibriEsposti, ArrayList<LocalDate> dateEsposizioni) throws SQLException;
}
