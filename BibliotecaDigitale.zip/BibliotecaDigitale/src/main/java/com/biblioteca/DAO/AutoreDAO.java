package com.biblioteca.DAO;

import org.jetbrains.annotations.Nullable;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

public interface AutoreDAO extends CloseableDAO {

    void aggiungiAutoreDB(String nominativo, @Nullable String istituto, @Nullable LocalDate datanascita) throws SQLException;

    void eliminaAutoreDB(int idautore) throws SQLException;

    void modificaAutoreDB(int idAutore, String nominativo, @Nullable String istituto, @Nullable LocalDate datanascita) throws SQLException;

    void cercaAutorePerLibroDB(String isbn, ArrayList<Integer> idAutori, ArrayList<String> nominativoAutori, ArrayList<LocalDate> dataNascitaAutori, ArrayList<String> istitutoAutori) throws SQLException;

    void cercaAutorePerArticoloDB(int idArticolo, ArrayList<Integer> idAutori, ArrayList<String> nominativoAutori, ArrayList<LocalDate> dataNascitaAutori, ArrayList<String> istitutoAutori) throws SQLException;

    void getAllAutori(ArrayList<Integer> idAutori, ArrayList<String> nominativoAutori, ArrayList<String> istitutoAutori, ArrayList<LocalDate> dataDiNascitaAutori) throws SQLException;

    void rimuoviAutoreDaLibro(int idautore, String isbn) throws SQLException;

    void rimuoviAutoreDaArticolo(int idautore, int idarticolo) throws SQLException;

    void aggiungiAutoreALibro(int idautore, String isbn) throws SQLException;

    void aggiungiAutoreAdArticolo(int idautore, int idarticolo) throws SQLException;
}
