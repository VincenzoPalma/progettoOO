package com.biblioteca.DAO;

import org.jetbrains.annotations.Nullable;

import java.sql.SQLException;
import java.util.ArrayList;

public interface ArticoloScientificoDAO extends CloseableDAO {

    void aggiungiArticoloScientificoDB(String titolo, String tema, String argomento, int annoPubblicazione, String editore, Boolean cartaceo, Boolean digitale, Boolean audiolibro, String issnRivista, Integer numeroRivista, Integer idConferenza) throws SQLException;

    void modificaArticoloScientificoDB(int idArticolo, String titolo, String tema, String argomento, int annopubblicazione, String editore, Boolean cartaceo, Boolean digitale, Boolean audiolibro, @Nullable Integer idconferenza, @Nullable String issnrivista, @Nullable Integer numerorivista) throws SQLException;

    void eliminaArticoloScientificoDB(int idarticolo) throws SQLException;

    void cercaArticoloDB(String ricerca, ArrayList<Integer> idArticoli, ArrayList<String> titoli, ArrayList<String> tema, ArrayList<String> argomenti, ArrayList<Integer> annoPubblicazione, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException;

    void cercaArticoloPerAutore(int idautore, ArrayList<Integer> idArticoli, ArrayList<String> titoli, ArrayList<String> tema, ArrayList<String> argomenti, ArrayList<Integer> annoPubblicazione, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException;

    void cercaArticoloPerRivista(String issnRivista, int numeroRivista, ArrayList<Integer> idArticoli, ArrayList<String> titoli, ArrayList<String> tema, ArrayList<String> argomenti, ArrayList<Integer> annoPubblicazione, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException;

    void cercaArticoloPerConferenza(int idConferenza, ArrayList<Integer> idArticoli, ArrayList<String> titoli, ArrayList<String> tema, ArrayList<String> argomenti, ArrayList<Integer> annoPubblicazione, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException;
}
