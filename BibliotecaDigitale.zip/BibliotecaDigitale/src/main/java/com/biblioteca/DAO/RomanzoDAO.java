package com.biblioteca.DAO;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

public interface RomanzoDAO extends CloseableDAO {

    void cercaRomanzoDB(String ricerca, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> generi, ArrayList<LocalDate> dateUscita, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException;

    void modificaRomanzoDB(String vecchioIsbn, String nuovoEditore, String nuovoGenere, LocalDate nuovaData, String nuovoIsbn, Boolean nuovocartaceo, Boolean nuovodigitale, Boolean nuovoaudlolibro, String isbnSeguito) throws SQLException;

    void cercaRomanzoPerSerie(int idSerie, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> generi, ArrayList<LocalDate> dateUscita, ArrayList<String> tipi, ArrayList<String> editore, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException;

    void eliminaSeguito(int idserie) throws SQLException;

    void eliminaSeguitoDaLibro(String isbnLibroRimosso) throws SQLException;

    void cercaSeguitoRomanzoDB(String isbn, ArrayList<String> isbnSeguito, ArrayList<String> titoloSeguito, ArrayList<String> genereSeguito, ArrayList<LocalDate> dataUscitaSeguito, ArrayList<String> editoreSeguito, ArrayList<Boolean> cartaceoSeguito, ArrayList<Boolean> digitaleSeguito, ArrayList<Boolean> audiolibroSeguito) throws SQLException;

    void cercaRomanziPerSerieSenzaSeguito(int idserie, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> generi, ArrayList<LocalDate> dateUscita, ArrayList<String> tipi, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro, ArrayList<String> isbnSeguiti) throws SQLException;
}
