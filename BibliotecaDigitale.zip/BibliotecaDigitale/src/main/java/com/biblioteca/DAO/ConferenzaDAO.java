package com.biblioteca.DAO;

import org.jetbrains.annotations.Nullable;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

public interface ConferenzaDAO extends CloseableDAO {

    void aggiungiConferenzaDB(String citta, String struttura, String responsabile, LocalDate datainizio, @Nullable LocalDate datafine) throws SQLException;

    void modificaConferenzaDB(int idconferenza, String citta, String struttura, String responsabile, LocalDate datainizio, @Nullable LocalDate datafine) throws SQLException;

    void eliminaConferenzaDB(int idconferenza) throws SQLException;

    void getAllConferenzeDB(ArrayList<Integer> idConferenze, ArrayList<String> cittaConferenze, ArrayList<String> strutturaConferenze, ArrayList<LocalDate> dateInizioConferenze, ArrayList<LocalDate> dateFineConferenze, ArrayList<String> responsabileConferenze) throws SQLException;

    void cercaConferenzaPerArticoloDB(int idArticolo, ArrayList<Integer> idConferenze, ArrayList<String> cittaConferenze, ArrayList<String> strutturaConferenze, ArrayList<LocalDate> dateInizioConferenze, ArrayList<LocalDate> dateFineConferenze, ArrayList<String> responsabileConferenze) throws SQLException;
}
