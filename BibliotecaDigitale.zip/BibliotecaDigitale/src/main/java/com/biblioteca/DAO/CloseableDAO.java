package com.biblioteca.DAO;

public interface CloseableDAO {

    void close();
}
