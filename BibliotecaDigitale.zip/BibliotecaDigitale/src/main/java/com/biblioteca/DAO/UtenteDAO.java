package com.biblioteca.DAO;

import java.sql.SQLException;
import java.util.ArrayList;

public interface UtenteDAO extends CloseableDAO {

    void registraUtenteDB(String username, String password) throws SQLException;

    void modificaUsernameUtenteDB(String nuovoUsername, String vecchioUsername) throws SQLException;

    void eliminaUtenteDB(String username) throws SQLException;

    boolean aggiungiPreferenzaSerieDB(String username, int idSerie) throws SQLException;

    void eliminaPreferenzaSerieDB(String username, int idSerie) throws SQLException;

    void cercaUtenteDB(String username, String password, ArrayList<String> usernameTrovato, ArrayList<String> passwordTrovata, ArrayList<String> tipoUtenteTrovato) throws SQLException;


}
