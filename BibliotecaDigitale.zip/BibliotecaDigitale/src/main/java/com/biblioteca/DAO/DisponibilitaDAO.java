package com.biblioteca.DAO;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;

public interface DisponibilitaDAO extends CloseableDAO {

    void aggiungiDisponibilitaDB(String isbn, int idnegozio, BigDecimal prezzo) throws SQLException;

    void eliminaDisponibilitaDB(String isbn, int idnegozio) throws SQLException;

    void cercaDisponibilitaPerIsbnDB(String isbn, ArrayList<Integer> idNegozi, ArrayList<BigDecimal> prezziLibro) throws SQLException;

    void cercaDisponibilitaPerIdNegozioDB(int idNegozio, ArrayList<String> isbnLibri, ArrayList<BigDecimal> prezziLibri) throws SQLException;
}
