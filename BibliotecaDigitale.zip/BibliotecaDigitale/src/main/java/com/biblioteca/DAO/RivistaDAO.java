package com.biblioteca.DAO;

import java.sql.SQLException;
import java.util.ArrayList;

public interface RivistaDAO extends CloseableDAO {

    void aggiungiRivistaDB(String issn, int numero, String nome, String tema, String responsabile, int annopubblicazione) throws SQLException;

    void modificaRivista(String issn, int numero, String nome, String tema, String responsabile, int annopubblicazione, String nuovoIssn, int nuovoNumero) throws SQLException;

    void modificaIssnRiviste(String nuovoIssn, String vecchioIssn) throws SQLException;

    void eliminaRivista(String issn, int numero) throws SQLException;

    void getAllRivisteDB(ArrayList<String> issn, ArrayList<String> titoli, ArrayList<Integer> numeri, ArrayList<String> tema, ArrayList<Integer> anniPubblicazione, ArrayList<String> responsabili) throws SQLException;

    void cercaRivistaPerIssn(String issn, ArrayList<String> titoliRiviste, ArrayList<Integer> numeriRiviste, ArrayList<String> temaRiviste, ArrayList<Integer> anniPubblicazioneRiviste, ArrayList<String> responsabiliRiviste) throws SQLException;

    void cercaRivistaPerArticolo(int idArticolo, ArrayList<String> issnRivista, ArrayList<String> titoliRiviste, ArrayList<Integer> numeriRiviste, ArrayList<String> temaRiviste, ArrayList<Integer> anniPubblicazioneRiviste, ArrayList<String> responsabiliRiviste) throws SQLException;
}
