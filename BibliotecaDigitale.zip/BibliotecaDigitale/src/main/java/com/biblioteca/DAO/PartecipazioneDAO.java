package com.biblioteca.DAO;

import com.biblioteca.model.Partecipazione;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

public interface PartecipazioneDAO extends CloseableDAO {

    void aggiungiPartecipazoneDB(Partecipazione partecipazioneAggiunta) throws SQLException;

    void eliminaPartecipazioneDB(String isbn, String issnCollana) throws SQLException;

    void cercaPartecipazionePerIsbnDB(String isbn, ArrayList<String> issnCollanaPartecipazioni, ArrayList<LocalDate> datePartecipazioni) throws SQLException;

    void cercaPartecipazionePerIssnCollana(String issnCollana, ArrayList<String> isbnLibri, ArrayList<LocalDate> datePartecipazioni) throws SQLException;

}
