package com.biblioteca.DAO;

import org.jetbrains.annotations.Nullable;

import java.sql.SQLException;
import java.util.ArrayList;

public interface NegozioDAO extends CloseableDAO {

    void aggiungiNegozioDB(String nome, @Nullable String sito) throws SQLException;

    void modificaNegozioDB(int idNegozio, @Nullable String nuovoSito, String nuovoNome) throws SQLException;

    void eliminaNegozioDB(int idnegozio) throws SQLException;

    void cercaNegozioPerID(int idnegozio, ArrayList<String> nomeNegozi, ArrayList<String> sitoNegozi) throws SQLException;

    void getaAllNegozi(ArrayList<Integer> idNegozi, ArrayList<String> nomeNegozi, ArrayList<String> sitoNegozi) throws SQLException;
}
