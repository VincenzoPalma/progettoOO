package com.biblioteca.DAO;

import org.jetbrains.annotations.Nullable;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

public interface CollanaDAO extends CloseableDAO {

    void aggiungiCollanaDB(String issn, String nome, String editore, String direttore, String caratteristica, @Nullable String descrizione, LocalDate datapubblicazione) throws SQLException;

    void eliminaCollanaDB(String issn) throws SQLException;

    void cercaCollanaPerIdDB(String issnCollana, ArrayList<String> nomeCollana, ArrayList<String> caratteristicaCollana, ArrayList<String> descrizioneCollana, ArrayList<LocalDate> dataPubblicazioneCollana, ArrayList<String> direttoreCollana, ArrayList<String> editoreCollana) throws SQLException;

    void modificaCollanaDB(String issnVecchio, String issn, String caratteristica, LocalDate datapubblicazione, String direttore, String descrizione) throws SQLException;

    void getAllCollane(ArrayList<String> issnCollane, ArrayList<String> nomeCollana, ArrayList<String> caratteristicaCollana, ArrayList<String> descrizioneCollana, ArrayList<LocalDate> dataPubblicazioneCollana, ArrayList<String> direttoreCollana, ArrayList<String> editoreCollana) throws SQLException;
}
