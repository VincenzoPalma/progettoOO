package com.biblioteca.DAO;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public interface NotificaDAO extends CloseableDAO {

    void cercaNotificheUtente(String username, ArrayList<Integer> serieNotifica, ArrayList<LocalDate> dataNotifiche, ArrayList<LocalTime> orarioNotifiche) throws SQLException;

    void cercaNotificaPreferenzaUtente(String username, int idSerie, ArrayList<LocalDate> dataNotifiche, ArrayList<LocalTime> orarioNotifiche) throws SQLException;
}
