package com.biblioteca.DAO;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

public interface LibroDidatticoDAO extends CloseableDAO {

    void cercaLibroDidatticoDB(String ricerca, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> ambiti, ArrayList<LocalDate> dateUscita, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException;

    void modificaLibroDidatticoDB(String vecchioIsbn, String nuovoEditore, String nuovoAmbito, LocalDate nuovaData, String nuovoIsbn, Boolean nuovocartaceo, Boolean nuovodigitale, Boolean nuovoaudlolibro) throws SQLException;

}
