package com.biblioteca.DAO;

import java.sql.SQLException;
import java.util.ArrayList;

public interface SerieDAO extends CloseableDAO {

    void aggiungiSerieDB(String titolo) throws SQLException;

    void eliminaSerieDB(int idserie) throws SQLException;

    void modificaSerieDB(int idSerie, String titolo) throws SQLException;

    void cercaSeriePerLibro(String isbn, ArrayList<Integer> idSerie, ArrayList<String> titoloSerie) throws SQLException;

    void cercaSeriePerUtente(String username, ArrayList<String> titoliSerie, ArrayList<Integer> idSerie) throws SQLException;

    void getAllSerie(ArrayList<Integer> idSerie, ArrayList<String> nomeSerie) throws SQLException;

    void aggiungiSerieALibro(String isbn, int idserie) throws SQLException;

    void rimuoviSerieALibro(String isbn, int idserie) throws SQLException;
}
