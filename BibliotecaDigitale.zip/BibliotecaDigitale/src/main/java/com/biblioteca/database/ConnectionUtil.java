package com.biblioteca.database;

import java.sql.Connection;
import java.sql.DriverManager;


public class ConnectionUtil {
    private static ConnectionUtil instance;
    private final String dbname = "biblioteca_object";
    private final String username = "postgres";
    private final String password = "26102002";

    /**
     * Ottiene la connessione già esistente se esiste, altrimenti
     * ne crea una nuova.
     */
    public static ConnectionUtil getInstance() {
        if (instance == null) {
            instance = new ConnectionUtil();
        }
        return instance;
    }

    /**
     * Ottiene la connessione al database, manda un messaggio di errore in caso di connessione
     * non riuscita.
     */
    public Connection GetConnection() {
        try {
            Class.forName("org.postgresql.Driver");
            return DriverManager.getConnection("jdbc:postgresql://localhost:5432/" + dbname, username, password);
        } catch (Exception ex) {
            System.out.println("Database Connection Creation Failed : " + ex.getMessage());
            ex.printStackTrace();
            return null;
        }
    }
}

