package com.biblioteca.Exceptions;

public class StringNoMatchEx extends Exception {

    public StringNoMatchEx() {
        super();
    }

}
