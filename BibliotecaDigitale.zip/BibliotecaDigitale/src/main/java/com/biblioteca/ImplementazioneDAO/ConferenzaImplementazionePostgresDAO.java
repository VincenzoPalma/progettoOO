package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.ConferenzaDAO;
import com.biblioteca.database.ConnectionUtil;
import org.jetbrains.annotations.Nullable;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Classe DAO che implementa la rispettiva interfaccia ConferenzaDAO, gestisce
 * la connessione al database e le interrogazioni, inserimenti e modifiche per
 * quanto riguarda la classe Conferenza.
 */
public class ConferenzaImplementazionePostgresDAO implements ConferenzaDAO {

    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public ConferenzaImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Inserisce nel database un autore con attributi uguali ai valori
     * passati come parametro.
     *
     * @param struttura    Nome della struttura che ospita la conferenza da inserire
     * @param responsabile Nome del responsabile della conferenza da inserire
     * @param citta        Nome della città della conferenza da inserire
     * @param dataInizio   Data d'inizio della conferenza da inserire
     * @param dataFine     Data di fine della conferenza da inserire
     */
    @Override
    public void aggiungiConferenzaDB(String citta, String struttura, String responsabile, LocalDate dataInizio, @Nullable LocalDate dataFine) throws SQLException {
        //prepara il comando d'inserimento
        PreparedStatement aggiungiConferenza = connection.prepareStatement("INSERT INTO conferenza VALUES (default,?,?,?,?,?)");
        //imposta i parametri del comando
        aggiungiConferenza.setString(1, citta);
        aggiungiConferenza.setString(2, struttura);
        aggiungiConferenza.setDate(3, Date.valueOf(dataInizio));
        //se la data di fine non è stata inserita, la imposta a null
        if (dataFine == null) {
            aggiungiConferenza.setDate(4, null);
        } else {
            aggiungiConferenza.setDate(4, Date.valueOf(dataFine));
        }
        aggiungiConferenza.setString(5, responsabile);
        try {
            aggiungiConferenza.executeUpdate(); //esegue l'inserimento
        } finally {
            aggiungiConferenza.close();
        }


    }

    /**
     * Modifica la conferenza con id passato come parametro, con i valori passati come parametri.
     *
     * @param idconferenza L'id della conferenza da modificare.
     */
    @Override
    public void modificaConferenzaDB(int idconferenza, String citta, String struttura, String responsabile, LocalDate datainizio, @Nullable LocalDate datafine) throws SQLException {
        //preparazione del comando
        PreparedStatement modificaConferenza = connection.prepareStatement("UPDATE conferenza SET citta = ?, struttura = ?, responsabile = ?, datainizio = ?, datafine = ? WHERE idconferenza = ?;");
        //impostazione dei parametri
        modificaConferenza.setString(1, citta);
        modificaConferenza.setString(2, struttura);
        modificaConferenza.setString(3, responsabile);
        modificaConferenza.setDate(4, Date.valueOf(datainizio));
        if (datafine == null) {
            modificaConferenza.setDate(5, null);
        } else {
            modificaConferenza.setDate(5, Date.valueOf(datafine));
        }
        modificaConferenza.setInt(6, idconferenza);
        try {
            modificaConferenza.executeUpdate(); //esecuzione dell'update
        } finally {
            modificaConferenza.close();
        }
    }

    /**
     * Elimina dal database la conferenza con id come quello passato come parametro.
     *
     * @param idconferenza L'id della conferenza da eliminare.
     */
    @Override
    public void eliminaConferenzaDB(int idconferenza) throws SQLException {
        //preparazione del comando
        PreparedStatement eliminaRivista = connection.prepareStatement("DELETE FROM conferenza WHERE idconferenza = ?");
        //impostazione dei parametri
        eliminaRivista.setInt(1, idconferenza);
        try {
            eliminaRivista.executeUpdate(); //esecuzione del comando
        } finally {
            eliminaRivista.close();
        }
    }

    /**
     * Cerca nel database tutti le conferenze.
     *
     * @param idConferenze           ArrayList che conterrà gli id delle conferenze trovate
     * @param cittaConferenze        ArrayList che conterrà le città delle conferenze trovate
     * @param strutturaConferenze    ArrayList che conterrà le strutture delle conferenze trovate
     * @param dateInizioConferenze   ArrayList che conterrà le date d'inizio delle conferenze trovate
     * @param dateFineConferenze     ArrayList che conterrà le date di fine delle conferenze trovate
     * @param responsabileConferenze ArratList che conterrà i nomi dei responsabili delle conferenze trovate.
     */
    @Override
    public void getAllConferenzeDB(ArrayList<Integer> idConferenze, ArrayList<String> cittaConferenze, ArrayList<String> strutturaConferenze, ArrayList<LocalDate> dateInizioConferenze, ArrayList<LocalDate> dateFineConferenze, ArrayList<String> responsabileConferenze) throws SQLException {
        //preparazione della query
        PreparedStatement cercaConferenze = connection.prepareStatement("SELECT * FROM conferenza");
        try {
            //esegue la query
            ResultSet conferenzeTrovate = cercaConferenze.executeQuery();
            while (conferenzeTrovate.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                idConferenze.add(conferenzeTrovate.getInt(1));
                cittaConferenze.add(conferenzeTrovate.getString(2));
                strutturaConferenze.add(conferenzeTrovate.getString(3));
                dateInizioConferenze.add(conferenzeTrovate.getDate(4).toLocalDate());
                responsabileConferenze.add(conferenzeTrovate.getString(6));
                //se la data di fine non esiste, aggiunge null, altrimenti aggiunge la data trovata
                if (conferenzeTrovate.getDate(5) == null) {
                    dateFineConferenze.add(null);
                } else {
                    dateFineConferenze.add(conferenzeTrovate.getDate(5).toLocalDate());
                }
            }
            conferenzeTrovate.close(); //chiusura del resultset
        } finally {
            cercaConferenze.close(); //chiusura del PreparedStatement
        }
    }

    /**
     * Cerca nel database la conferenza dov'è stato pubblicato
     * l'articolo con id uguale a quello passato come parametro.
     *
     * @param idArticolo           L'id dell'articolo di cui si cerca la conferenza.
     * @param idConferenze         ArrayList che conterrà gli id delle conferenze trovate
     * @param cittaConferenze      ArrayList che conterrà le città delle conferenze trovate
     * @param strutturaConferenze  ArrayList che conterrà le strutture delle conferenze trovate
     * @param dateInizioConferenze ArrayList che conterrà le date d'inizio delle conferenze trovate
     * @param dateFineConferenze   ArrayList che conterrà le date di fine delle conferenze trovate
     */
    @Override
    public void cercaConferenzaPerArticoloDB(int idArticolo, ArrayList<Integer> idConferenze, ArrayList<String> cittaConferenze, ArrayList<String> strutturaConferenze, ArrayList<LocalDate> dateInizioConferenze, ArrayList<LocalDate> dateFineConferenze, ArrayList<String> responsabileConferenze) throws SQLException {
        //preparazione della query
        PreparedStatement cercaConferenze = connection.prepareStatement("SELECT * FROM conferenza as c JOIN articoloscientifico as a ON a.idconferenza = c.idconferenza WHERE a.idarticolo = ?");
        //impostazione del parametro
        cercaConferenze.setInt(1, idArticolo);
        try {
            //esegue la query
            ResultSet conferenzeTrovate = cercaConferenze.executeQuery();
            while (conferenzeTrovate.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                idConferenze.add(conferenzeTrovate.getInt(1));
                cittaConferenze.add(conferenzeTrovate.getString(2));
                strutturaConferenze.add(conferenzeTrovate.getString(3));
                dateInizioConferenze.add(conferenzeTrovate.getDate(4).toLocalDate());
                responsabileConferenze.add(conferenzeTrovate.getString(6));
                //se la data di fine non esiste, aggiunge null, altrimenti aggiunge la data trovata
                if (conferenzeTrovate.getDate(5) == null) {
                    dateFineConferenze.add(null);
                } else {
                    dateFineConferenze.add(conferenzeTrovate.getDate(5).toLocalDate());
                }
            }
            conferenzeTrovate.close(); //chiusura del resultset
        } finally {
            cercaConferenze.close(); //chiusura del PreparedStatement
        }
    }
}

