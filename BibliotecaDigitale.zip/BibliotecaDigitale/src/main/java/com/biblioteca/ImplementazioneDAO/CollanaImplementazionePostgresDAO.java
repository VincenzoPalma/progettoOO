package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.CollanaDAO;
import com.biblioteca.database.ConnectionUtil;
import org.jetbrains.annotations.Nullable;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Classe DAO che implementa la rispettiva interfaccia CollanaDAO, gestisce
 * la connessione al database e le interrogazioni, inserimenti e modifiche per
 * quanto riguarda la classe Collana.
 */
public class CollanaImplementazionePostgresDAO implements CollanaDAO {

    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public CollanaImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Inserisce nel database una collana con attributi uguali ai valori
     * passati come parametro.
     *
     * @param issn              L'issn della collana da inserire
     * @param nome              Il nome della collana da inserire
     * @param editore           L'editore della collana da inserire
     * @param direttore         Il direttore della collana da inserire
     * @param caratteristica    La caratteristica della collana da inserire
     * @param descrizione       La descrizione della collana da inserire
     * @param dataPubblicazione La data di pubblicazione della collana da inserire
     */
    @Override
    public void aggiungiCollanaDB(String issn, String nome, String editore, String direttore, String caratteristica, @Nullable String descrizione, LocalDate dataPubblicazione) throws SQLException {
        //prepara il comando di inserimento
        PreparedStatement inserisciCollana = connection.prepareStatement("INSERT INTO collana VALUES (?, ?, ?, ?, ?, ?, ?)");
        //imposta i parametri del comando
        inserisciCollana.setString(1, issn);
        inserisciCollana.setString(2, nome);
        inserisciCollana.setString(3, caratteristica);
        inserisciCollana.setString(4, descrizione);
        inserisciCollana.setString(7, editore);
        inserisciCollana.setString(6, direttore);
        inserisciCollana.setDate(5, Date.valueOf(dataPubblicazione));
        try {
            inserisciCollana.executeUpdate(); //esegue l'inserimento
        } finally {
            inserisciCollana.close();
        }
    }


    @Override
    public void eliminaCollanaDB(String issn) throws SQLException {

        PreparedStatement eliminaCollana = connection.prepareStatement("DELETE FROM collana WHERE issn = ?");
        eliminaCollana.setString(1, issn);
        try {
            eliminaCollana.executeUpdate();
        } finally {
            eliminaCollana.close();
        }


    }

    /**
     * Cerca nel database le informazioni della collana con id uguale all'id collana
     * passato come parametro.
     *
     * @param issnCollana           Issn della collana di cui si vogliono cercare le informazioni.
     * @param nomeCollana           ArrayList che conterrà il nome della collana trovata.
     * @param caratteristicaCollana ArrayList che conterrà la caratteristica della collana trovata.
     * @param descrizioneCollana    ArrayList che conterrà la descrizione della collana trovata.
     * @param direttoreCollana      ArrayList che conterrà la data di pubblicazione della collana trovata.
     * @param editoreCollana        ArrayList che conterrà il nome dell'editore della collana trovata.
     */
    @Override
    public void cercaCollanaPerIdDB(String issnCollana, ArrayList<String> nomeCollana, ArrayList<String> caratteristicaCollana, ArrayList<String> descrizioneCollana, ArrayList<LocalDate> dataPubblicazioneCollana, ArrayList<String> direttoreCollana, ArrayList<String> editoreCollana) throws SQLException {
        //preparazione della query
        PreparedStatement cercaCollana = connection.prepareStatement("SELECT * FROM collana as c WHERE c.issn = ?;");
        //impostazione del parametro della query
        cercaCollana.setString(1, issnCollana);
        try {
            ResultSet risultatiCollana = cercaCollana.executeQuery(); //esecuzione della query
            while (risultatiCollana.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                nomeCollana.add(risultatiCollana.getString(2));
                caratteristicaCollana.add(risultatiCollana.getString(3));
                descrizioneCollana.add(risultatiCollana.getString(4));
                dataPubblicazioneCollana.add(risultatiCollana.getDate(5).toLocalDate());
                direttoreCollana.add(risultatiCollana.getString(6));
                editoreCollana.add(risultatiCollana.getString(7));
            }
            risultatiCollana.close(); //chiusura del resultset
        } finally {
            cercaCollana.close();
        }
    }

    /**
     * Modifica la collana con issn uguale a "issnVecchio", con i valori passati come parametro.
     *
     * @param issnVecchio Issn della collana da modificare.
     */
    @Override
    public void modificaCollanaDB(String issnVecchio, String issnNuovo, String caratteristica, LocalDate datapubblicazione, String direttore, String descrizione) throws SQLException {
        //preparazione del comando
        PreparedStatement modificaCollana = connection.prepareStatement("UPDATE collana SET issn = ?, caratteristica = ?, datapubblicazione = ?, direttore = ?, descrizione = ? WHERE issn = ?");
        //impostazione dei parametri
        modificaCollana.setString(1, issnNuovo);
        modificaCollana.setString(2, caratteristica);
        modificaCollana.setDate(3, Date.valueOf(datapubblicazione));
        modificaCollana.setString(5, descrizione);
        modificaCollana.setString(4, direttore);
        modificaCollana.setString(6, issnVecchio);
        try {
            modificaCollana.executeUpdate(); //esecuzione del comando
        } finally {
            modificaCollana.close();
        }
    }

    /**
     * Cerca tutte le collane nel database.
     */
    @Override
    public void getAllCollane(ArrayList<String> issnCollane, ArrayList<String> nomeCollana, ArrayList<String> caratteristicaCollana, ArrayList<String> descrizioneCollana, ArrayList<LocalDate> dataPubblicazioneCollana, ArrayList<String> direttoreCollana, ArrayList<String> editoreCollana) throws SQLException {
        //preparazione della query
        PreparedStatement cercaCollane = connection.prepareStatement("SELECT * FROM collana");
        try {
            ResultSet collaneTrovate = cercaCollane.executeQuery(); //esecuzione della query
            while (collaneTrovate.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                issnCollane.add(collaneTrovate.getString(1));
                nomeCollana.add(collaneTrovate.getString(2));
                caratteristicaCollana.add(collaneTrovate.getString(3));
                descrizioneCollana.add(collaneTrovate.getString(4));
                dataPubblicazioneCollana.add(collaneTrovate.getDate(5).toLocalDate());
                direttoreCollana.add(collaneTrovate.getString(6));
                editoreCollana.add(collaneTrovate.getString(7));
            }
            collaneTrovate.close(); //chiusura del resultset
        } finally {
            cercaCollane.close();
        }
    }
}
