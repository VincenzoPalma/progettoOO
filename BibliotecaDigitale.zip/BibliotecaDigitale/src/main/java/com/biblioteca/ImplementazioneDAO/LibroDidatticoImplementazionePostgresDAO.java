package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.LibroDidatticoDAO;
import com.biblioteca.database.ConnectionUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Classe DAO che implementa la rispettiva interfaccia LibroDidatticoDAO, gestisce
 * la connessione al database e le interrogazioni, inserimenti e modifiche per
 * quanto riguarda la classe LibroDidattico.
 */
public class LibroDidatticoImplementazionePostgresDAO implements LibroDidatticoDAO {

    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public LibroDidatticoImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Cerca nel database tutti i libri didattici che contengono nel loro titolo,
     * ambito o editore la stringa "ricerca".
     *
     * @param ricerca    La stringa scritta dall'utente nella barra di ricerca della homepage.
     * @param isbn       ArrayList che conterrà gli isbn dei libri trovati
     * @param titoli     ArrayList che conterrà i titoli dei libri trovati
     * @param ambiti     ArrayList che conterrà gli ambiti dei libri trovati
     * @param dateUscita ArrayList che conterrà le date di uscita dei libri trovati
     * @param editori    ArrayList che conterrà gli editori dei libri trovati
     * @param cartaceo   ArrayList che conterrà un boolean per la presenza del formato cartaceo dei libri trovati
     * @param digitale   ArrayList che conterrà un boolean per la presenza del formato digitale dei libri trovati
     * @param audiolibro ArrayList che conterrà un boolean per la presenza del formato audiolibro dei libri trovati
     */
    @Override
    public void cercaLibroDidatticoDB(String ricerca, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> ambiti, ArrayList<LocalDate> dateUscita, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException {
        //prepara la query
        PreparedStatement cercaLibriDidattici = connection.prepareStatement("SELECT * FROM libro as l WHERE (l.titolo like '%" + ricerca + "%' OR l.genere like '%" + ricerca + "%' OR l.editore like '%" + ricerca + "%') AND l.tipo = 'Didattico';");
        try {
            //esegue il comando
            ResultSet libriDidatticiTrovati = cercaLibriDidattici.executeQuery();
            while (libriDidatticiTrovati.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                isbn.add(libriDidatticiTrovati.getString(1));
                titoli.add(libriDidatticiTrovati.getString(2));
                ambiti.add(libriDidatticiTrovati.getString(3));
                dateUscita.add((libriDidatticiTrovati.getDate(4).toLocalDate()));
                editori.add(libriDidatticiTrovati.getString(6));
                cartaceo.add(libriDidatticiTrovati.getBoolean(7));
                digitale.add(libriDidatticiTrovati.getBoolean(8));
                audiolibro.add(libriDidatticiTrovati.getBoolean(9));
            }
            libriDidatticiTrovati.close(); //chiude il resultset
        } finally {
            cercaLibriDidattici.close(); //chiude il PreparedStatement
        }
    }


    /**
     * Esegue una modifica al libro con isbn uguale a "vecchioIsbn" con i valori
     * passati come parametro.
     *
     * @param vecchioIsbn Isbn del libro di cui si vogliono modificare i dati
     */
    @Override
    public void modificaLibroDidatticoDB(String vecchioIsbn, String nuovoEditore, String nuovoAmbito, LocalDate nuovaData, String nuovoIsbn, Boolean nuovoCartaceo, Boolean nuovoDigitale, Boolean nuovoAudiolibro) throws SQLException {
        //preparazione del comando di update
        PreparedStatement modificaLibro = connection.prepareStatement("UPDATE libro SET editore = ?, genere = ?, datauscita = ?, isbn = ?, digitale = ?, cartaceo = ?, audiolibro= ? WHERE isbn = ?");
        //impostazione dei parametri del comando
        modificaLibro.setString(1, nuovoEditore);
        modificaLibro.setString(2, nuovoAmbito);
        modificaLibro.setDate(3, Date.valueOf(nuovaData));
        modificaLibro.setString(4, nuovoIsbn);
        modificaLibro.setBoolean(5, nuovoDigitale);
        modificaLibro.setBoolean(6, nuovoCartaceo);
        modificaLibro.setBoolean(7, nuovoAudiolibro);
        modificaLibro.setString(8, vecchioIsbn);
        try {
            modificaLibro.executeUpdate(); //esecuzione dell'update
        } finally {
            modificaLibro.close();
        }
    }
}
