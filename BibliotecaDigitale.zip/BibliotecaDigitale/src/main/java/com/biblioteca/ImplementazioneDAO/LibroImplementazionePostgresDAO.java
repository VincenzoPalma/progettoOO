package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.LibroDAO;
import com.biblioteca.database.ConnectionUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Classe DAO che implementa la rispettiva interfaccia LibroDAO, gestisce
 * la connessione al database e le interrogazioni, inserimenti e modifiche per
 * quanto riguarda la classe Libro.
 */
public class LibroImplementazionePostgresDAO implements LibroDAO {

    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public LibroImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Aggiunge un libro nel database con gli attributi uguali ai valori
     * presi come parametro.
     *
     * @param isbn              L'isbn del libro da inserire
     * @param titolo            Il titolo del libro da inserire
     * @param genere            Il genere del libro da inserire
     * @param editore           L'editore del libro da inserire
     * @param datapubblicazione La data di pubblicazione del libro da inserire
     * @param cartaceo          Boolean per la presenza del formato cartaceo del libro da inserire
     * @param digitale          Boolean per la presenza del formato digitale del libro da inserire
     * @param audiolibro        Boolean per la presenza del formato audiolibro del libro da inserire
     * @param tipo              Il tipo del libro da inserire, sarà "Romanzo" o "Didattico"
     */
    @Override
    public void aggiungiLibroDB(String isbn, String titolo, String genere, String editore, LocalDate datapubblicazione, Boolean cartaceo, Boolean digitale, Boolean audiolibro, String tipo) throws SQLException {
        //preparazione del comando d'inserimento
        PreparedStatement inserimentoLibro = connection.prepareStatement("INSERT INTO libro VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, null)");
        //impostazione dei parametri del comando d'inserimento
        inserimentoLibro.setString(1, isbn);
        inserimentoLibro.setString(2, titolo);
        inserimentoLibro.setString(3, genere);
        inserimentoLibro.setDate(4, Date.valueOf(datapubblicazione));
        inserimentoLibro.setString(5, tipo);
        inserimentoLibro.setString(6, editore);
        inserimentoLibro.setBoolean(7, cartaceo);
        inserimentoLibro.setBoolean(8, digitale);
        inserimentoLibro.setBoolean(9, audiolibro);
        try {
            inserimentoLibro.executeUpdate(); //esecuzione dell'inserimento
        } finally {
            inserimentoLibro.close(); //chiusura del PreparedStatement
        }
    }

    /**
     * Elimina il libro dal database con isbn uguale a quello passato come parametro.
     *
     * @param isbn L'isbn del libro da eliminare.
     */
    @Override
    public void eliminaLibroDB(String isbn) throws SQLException {
        //prepara il comando
        PreparedStatement eliminaLibro = connection.prepareStatement("DELETE FROM libro WHERE isbn = ?");
        eliminaLibro.setString(1, isbn); //imposta il parametro
        try {
            eliminaLibro.executeUpdate(); //esegue il comando
        } finally {
            eliminaLibro.close();
        }
    }


    /**
     * Cerca i libri disponibili nel negozio con id uguale a quello passato come parametro.
     */
    @Override
    public void cercaLibroPerNegozio(int idNegozio, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> generi, ArrayList<LocalDate> dateUscita, ArrayList<String> tipi, ArrayList<String> editore, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException {
        //preparazione della query
        PreparedStatement cercaLibri = connection.prepareStatement("SELECT * FROM libro as l JOIN rel_libro_negozio as r ON r.isbn = l.isbn WHERE r.idnegozio= ?");
        cercaLibri.setInt(1, idNegozio); //impostazione del parametro della query
        try {
            ResultSet risultatiLibri = cercaLibri.executeQuery(); //esecuzione della query
            while (risultatiLibri.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                isbn.add(risultatiLibri.getString(1));
                titoli.add(risultatiLibri.getString(2));
                generi.add(risultatiLibri.getString(3));
                dateUscita.add(risultatiLibri.getDate(4).toLocalDate());
                tipi.add(risultatiLibri.getString(5));
                editore.add(risultatiLibri.getString(6));
                cartaceo.add(risultatiLibri.getBoolean(7));
                digitale.add(risultatiLibri.getBoolean(8));
                audiolibro.add(risultatiLibri.getBoolean(9));
            }
            risultatiLibri.close(); //chiusura del result set
        } finally {
            cercaLibri.close();
        }
    }

    /**
     * Cerca i libri scritti dall'autore con id uguale a quello passato come parametro.
     */
    @Override
    public void cercaLibriPerAutore(int idAutore, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> generi, ArrayList<LocalDate> dateUscita, ArrayList<String> tipi, ArrayList<String> editore, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException {
        //preparazione della query
        PreparedStatement cercaLibri = connection.prepareStatement("SELECT * FROM libro as l JOIN rel_autore_libro as r ON r.isbn = l.isbn WHERE r.idautore = ?");
        cercaLibri.setInt(1, idAutore); //impostazione del parametro della query
        try {
            ResultSet risultatiLibri = cercaLibri.executeQuery();
            while (risultatiLibri.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                isbn.add(risultatiLibri.getString(1));
                titoli.add(risultatiLibri.getString(2));
                generi.add(risultatiLibri.getString(3));
                dateUscita.add(risultatiLibri.getDate(4).toLocalDate());
                tipi.add(risultatiLibri.getString(5));
                editore.add(risultatiLibri.getString(6));
                cartaceo.add(risultatiLibri.getBoolean(7));
                digitale.add(risultatiLibri.getBoolean(8));
                audiolibro.add(risultatiLibri.getBoolean(9));
            }
            risultatiLibri.close(); //chiusura del result set
        } finally {
            cercaLibri.close();
        }
    }

    /**
     * Cerca i libri esposti nella sala con id uguale a quello passato come parametro.
     */
    @Override
    public void cercaLibroPerSala(int idSala, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> generi, ArrayList<LocalDate> dateUscita, ArrayList<String> tipoLibri, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException {
        //preparazione della query
        PreparedStatement cercaLibri = connection.prepareStatement("SELECT * FROM libro as l JOIN rel_libro_sala as r ON r.isbn = l.isbn WHERE r.idsala = ?");
        cercaLibri.setInt(1, idSala); //impostazione del parametro della query
        try {
            ResultSet risultatiLibri = cercaLibri.executeQuery();
            while (risultatiLibri.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                isbn.add(risultatiLibri.getString(1));
                titoli.add(risultatiLibri.getString(2));
                generi.add(risultatiLibri.getString(3));
                dateUscita.add(risultatiLibri.getDate(4).toLocalDate());
                tipoLibri.add(risultatiLibri.getString(5));
                editori.add(risultatiLibri.getString(6));
                cartaceo.add(risultatiLibri.getBoolean(7));
                digitale.add(risultatiLibri.getBoolean(8));
                audiolibro.add(risultatiLibri.getBoolean(9));
            }
            risultatiLibri.close(); //chiusura del result set
        } finally {
            cercaLibri.close();
        }
    }

    /**
     * Cerca i libri nella collana con id uguale a quello passato come parametro.
     */
    @Override
    public void cercaLibroPerCollana(String issnCollana, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> generi, ArrayList<LocalDate> dateUscita, ArrayList<String> tipoLibri, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException {
        //preparazione della query
        PreparedStatement cercaLibri = connection.prepareStatement("SELECT * FROM libro as l JOIN rel_libro_collana as r ON r.isbn = l.isbn WHERE r.issn = ?");
        cercaLibri.setString(1, issnCollana); //impostazione del parametro della query
        try {
            ResultSet risultatiLibri = cercaLibri.executeQuery();
            while (risultatiLibri.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                isbn.add(risultatiLibri.getString(1));
                titoli.add(risultatiLibri.getString(2));
                generi.add(risultatiLibri.getString(3));
                dateUscita.add(risultatiLibri.getDate(4).toLocalDate());
                tipoLibri.add(risultatiLibri.getString(5));
                editori.add(risultatiLibri.getString(6));
                cartaceo.add(risultatiLibri.getBoolean(7));
                digitale.add(risultatiLibri.getBoolean(8));
                audiolibro.add(risultatiLibri.getBoolean(9));
            }
            risultatiLibri.close(); //chiusura del result set
        } finally {
            cercaLibri.close();
        }
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
