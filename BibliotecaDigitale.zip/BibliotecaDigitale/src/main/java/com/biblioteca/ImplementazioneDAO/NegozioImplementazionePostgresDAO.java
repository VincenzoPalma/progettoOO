package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.NegozioDAO;
import com.biblioteca.database.ConnectionUtil;
import org.jetbrains.annotations.Nullable;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class NegozioImplementazionePostgresDAO implements NegozioDAO {
    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public NegozioImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Inserisce nel database un negozio con attributi uguali ai valori
     * passati come parametro.
     *
     * @param nome Il nome del negozio da inserire
     * @param sito Il sito del negozio da inserire, può essere null
     */
    @Override
    public void aggiungiNegozioDB(String nome, @Nullable String sito) throws SQLException {
        //preparazione del comando d'inserimento
        PreparedStatement aggiungiNegozio = connection.prepareStatement("INSERT INTO negozio VALUES (default, ?, ?)");
        //impostazione dei parametri del comando
        aggiungiNegozio.setString(1, nome);
        aggiungiNegozio.setString(2, sito);
        try {
            aggiungiNegozio.executeUpdate(); //esecuzione del comando
        } finally {
            aggiungiNegozio.close();
        }

    }

    /**
     * Modifica il negozio con id uguale a quello passato come parametro, con i valori dei parametri.
     *
     * @param idNegozio Id del negozio da modificare.
     */
    @Override
    public void modificaNegozioDB(int idNegozio, @Nullable String nuovoSito, String nuovoNome) throws SQLException {
        //preparazione del comando
        PreparedStatement modificaNegozio = connection.prepareStatement("UPDATE negozio SET sito = ?, nome = ? WHERE idnegozio = ?");
        //impostazione dei parametri
        modificaNegozio.setString(1, nuovoSito);
        modificaNegozio.setString(2, nuovoNome);
        modificaNegozio.setInt(3, idNegozio);
        try {
            modificaNegozio.executeUpdate(); //esecuzione del comando
        } finally {
            modificaNegozio.close();
        }
    }

    /**
     * Elimina il negozio con id uguale a quello come parametro.
     *
     * @param idnegozio Id del negozio da eliminare.
     */
    @Override
    public void eliminaNegozioDB(int idnegozio) throws SQLException {
        //preparazione del comando
        PreparedStatement eliminaNegozio = connection.prepareStatement("DELETE FROM negozio WHERE idnegozio = ?");
        eliminaNegozio.setInt(1, idnegozio); //impostazione dei parametri
        try {
            eliminaNegozio.executeUpdate(); //esecuzione del comando
        } finally {
            eliminaNegozio.close();
        }

    }

    /**
     * Cerca le informazioni del negozio con id uguale a quello passato come parametro.
     *
     * @param idNegozio  Id del negozio di cui si vogliono cercare le informazioni
     * @param nomeNegozi ArrayList che conterrà il nome del negozio trovato
     * @param sitoNegozi ArrayList che conterrà il sito del negozio trovato
     */
    @Override
    public void cercaNegozioPerID(int idNegozio, ArrayList<String> nomeNegozi, ArrayList<String> sitoNegozi) throws SQLException {
        //preparazione della query
        PreparedStatement cercaNegozio = connection.prepareStatement("SELECT * FROM negozio as n WHERE n.idnegozio = ?");
        //impostazione del parametro della query
        cercaNegozio.setInt(1, idNegozio);
        try {
            ResultSet risultatiNegozio = cercaNegozio.executeQuery(); //esecuzione della query
            while (risultatiNegozio.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                nomeNegozi.add(risultatiNegozio.getString(2));
                sitoNegozi.add(risultatiNegozio.getString(3));
            }
            risultatiNegozio.close(); //chiusura del resultset
        } finally {
            cercaNegozio.close();
        }
    }

    /**
     * Cerca tutti i negozi nel database.
     */
    @Override
    public void getAllNegozi(ArrayList<Integer> idNegozi, ArrayList<String> nomeNegozi, ArrayList<String> sitoNegozi) throws SQLException {
        //preparazione della query
        PreparedStatement cercaNegozio = connection.prepareStatement("SELECT * FROM negozio");
        try {
            ResultSet negoziTrovati = cercaNegozio.executeQuery(); //esecuzione della query
            while (negoziTrovati.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                idNegozi.add(negoziTrovati.getInt(1));
                nomeNegozi.add(negoziTrovati.getString(2));
                sitoNegozi.add(negoziTrovati.getString(3));
            }
            negoziTrovati.close(); //chiusura del resultset
        } finally {
            cercaNegozio.close();
        }
    }
}

