package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.PartecipazioneDAO;
import com.biblioteca.database.ConnectionUtil;
import com.biblioteca.model.Partecipazione;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Classe DAO che implementa la rispettiva interfaccia PartecipazioneDAO, gestisce
 * la connessione al database e le interrogazioni, inserimenti e modifiche per
 * quanto riguarda la classe Partecipazione.
 */
public class PartecipazioneImplementazionePostgresDAO implements PartecipazioneDAO {

    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public PartecipazioneImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void aggiungiPartecipazoneDB(Partecipazione partecipazioneAggiunta) throws SQLException {
        PreparedStatement aggiungiPartecipazione = connection.prepareStatement("INSERT INTO rel_libro_collana VALUES (?, ?, ?);");
        aggiungiPartecipazione.setString(1, partecipazioneAggiunta.getLibro().getIsbn());
        aggiungiPartecipazione.setString(2, partecipazioneAggiunta.getCollana().getIssn());
        aggiungiPartecipazione.setDate(3, Date.valueOf(partecipazioneAggiunta.getData()));
        try {
            aggiungiPartecipazione.executeUpdate();
        } finally {
            aggiungiPartecipazione.close();
        }
    }

    @Override
    public void eliminaPartecipazioneDB(String isbn, String issnCollana) throws SQLException {
        PreparedStatement eliminaPartecipazione = connection.prepareStatement("DELETE FROM rel_libro_collana WHERE isbn = ? AND issn = ?;");
        eliminaPartecipazione.setString(1, isbn);
        eliminaPartecipazione.setString(2, issnCollana);
        try {
            eliminaPartecipazione.executeUpdate();
        } finally {
            eliminaPartecipazione.close();
        }
    }

    /**
     * Cerca nel database le partecipazioni relative al libro con isbn uguale a
     * quello passato come parametro.
     *
     * @param isbn                      Isbn del libro di cui si vogliono cercare le partecipazioni alle collane.
     * @param issnCollanaPartecipazioni ArrayList che contiene gli issn delle collane relative alle partecipazioni trovate
     * @param datePartecipazioni        ArrayList che contiene le date di partecipazione del libro nelle partecipazioni trovate
     */
    @Override
    public void cercaPartecipazionePerIsbnDB(String isbn, ArrayList<String> issnCollanaPartecipazioni, ArrayList<LocalDate> datePartecipazioni) throws SQLException {
        //preparazione della query
        PreparedStatement cercaPartecipazioni = connection.prepareStatement("SELECT * FROM rel_libro_collana as r WHERE r.isbn = ?");
        //impostazione del parametro della query
        cercaPartecipazioni.setString(1, isbn);
        try {
            ResultSet risultatiPartecipazioni = cercaPartecipazioni.executeQuery(); //esecuzione della query
            while (risultatiPartecipazioni.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                issnCollanaPartecipazioni.add(risultatiPartecipazioni.getString(2));
                datePartecipazioni.add(risultatiPartecipazioni.getDate(3).toLocalDate());
            }
            risultatiPartecipazioni.close(); //chiusura del resultset
        } finally {
            cercaPartecipazioni.close();
        }
    }

    /**
     * Cerca le partecipazioni dei libri della collana con issn uguale a quello passato come parametro.
     *
     * @param issnCollana Issn della collana di cui si cercano le partecipazioni.
     */
    @Override
    public void cercaPartecipazionePerIssnCollana(String issnCollana, ArrayList<String> isbnLibri, ArrayList<LocalDate> datePartecipazioni) throws SQLException {
        //preparazione della query
        PreparedStatement cercaPartecipazioni = connection.prepareStatement("SELECT * FROM rel_libro_collana as r WHERE r.issn = ?");
        cercaPartecipazioni.setString(1, issnCollana); //impostazione del parametro
        try {
            ResultSet risultatiPartecipazioni = cercaPartecipazioni.executeQuery(); //esecuzione della query
            while (risultatiPartecipazioni.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                isbnLibri.add(risultatiPartecipazioni.getString(1));
                datePartecipazioni.add(risultatiPartecipazioni.getDate(3).toLocalDate());
            }
            risultatiPartecipazioni.close(); //chiusura resultset
        } finally {
            cercaPartecipazioni.close();
        }
    }

}
