package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.SerieDAO;
import com.biblioteca.database.ConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Classe DAO che implementa la rispettiva interfaccia SerieDAO, gestisce
 * la connessione al database e le interrogazioni, inserimenti e modifiche per
 * quanto riguarda la classe Serie.
 */
public class SerieImplementazionePostgresDAO implements SerieDAO {

    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public SerieImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Inserisce nel database una serie con attributi uguali ai valori
     * passati come parametro.
     *
     * @param titolo Il titolo della serie da inserire
     */
    @Override
    public void aggiungiSerieDB(String titolo) throws SQLException {
        //preparazione del comando d'inserimento
        PreparedStatement aggiungiSerie = connection.prepareStatement("INSERT INTO serie values (default,?)");
        //impostazione del parametro del comando
        aggiungiSerie.setString(1, titolo);
        try {
            aggiungiSerie.executeUpdate(); //esecuzione dell'inserimento
        } finally {
            aggiungiSerie.close();
        }

    }

    /**
     * Elimina la serie con id passato come parametro dal database.
     *
     * @param idserie L'id della serie che si vuole eliminare.
     */
    @Override
    public void eliminaSerieDB(int idserie) throws SQLException {
        //prepara il comando
        PreparedStatement eliminaSerie = connection.prepareStatement("DELETE FROM serie WHERE idserie = ?");
        eliminaSerie.setInt(1, idserie); //imposta il parametro
        try {
            eliminaSerie.executeUpdate(); //esegue il comando
        } finally {
            eliminaSerie.close();
        }
    }

    /**
     * Modifica le informazioni della serie con id passato come parametro.
     *
     * @param idSerie L'id della serie da modificare.
     */
    @Override
    public void modificaSerieDB(int idSerie, String titolo) throws SQLException {
        //prepara il comando
        PreparedStatement modificaSerie = connection.prepareStatement("UPDATE serie SET titolo = ? WHERE idserie = ?");
        //imposta i parametri
        modificaSerie.setString(1, titolo);
        modificaSerie.setInt(2, idSerie);
        try {
            modificaSerie.executeUpdate(); //esegue il comando
        } finally {
            modificaSerie.close();
        }
    }


    /**
     * Cerca la serie che contiene il libro con isbn uguale a quello passato come parametro.
     *
     * @param isbn        L'isbn del libro di cui si vuole ottenere la serie.
     * @param idSerie     ArrayList che contiene l'id della serie trovata
     * @param titoloSerie ArrayList che contiene il titolo della serie trovata
     */
    @Override
    public void cercaSeriePerLibro(String isbn, ArrayList<Integer> idSerie, ArrayList<String> titoloSerie) throws SQLException {
        //preparazione della query
        PreparedStatement cercaSerie = connection.prepareStatement("SELECT * FROM serie as s WHERE s.idserie = (SELECT r.idserie FROM rel_libro_serie as r WHERE r.isbn = ?)");
        cercaSerie.setString(1, isbn);
        try {
            ResultSet risultatoSerie = cercaSerie.executeQuery();
            while (risultatoSerie.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                idSerie.add(risultatoSerie.getInt(1));
                titoloSerie.add(risultatoSerie.getString(2));
            }
            risultatoSerie.close(); //chiusura del result set
        } finally {
            cercaSerie.close();
        }
    }

    /**
     * Effettua una ricerca nel database per le serie per cui esiste una preferenza di un utente
     * con l'username dato come parametro.
     *
     * @param username    L'utente di cui si vogliono cercare le preferenze.
     * @param titoliSerie ArrayList che conterrà i titoli delle serie trovate
     * @param idSerie     ArrayList che conterrà gli id delle serie trovate
     */
    @Override
    public void cercaSeriePerUtente(String username, ArrayList<String> titoliSerie, ArrayList<Integer> idSerie) throws SQLException {
        //preparazione della query di ricerca dell'utente
        PreparedStatement ricercaPreferenze = connection.prepareStatement("SELECT * FROM serie as s JOIN rel_serie_utente as r ON s.idserie = r.idserie WHERE r.username = ?");
        //impostazione del parametro della query
        ricercaPreferenze.setString(1, username);
        try {
            //esecuzione della query
            ResultSet preferenzeTrovate = ricercaPreferenze.executeQuery();
            while (preferenzeTrovate.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                titoliSerie.add(preferenzeTrovate.getString(2));
                idSerie.add(preferenzeTrovate.getInt(1));
            }
            preferenzeTrovate.close(); //chiusura del resultset
        } finally {
            ricercaPreferenze.close(); //chiusura del prepared statement
        }
    }

    /**
     * Cerca tutte le serie nel database.
     */
    @Override
    public void getAllSerie(ArrayList<Integer> idSerie, ArrayList<String> nomeSerie) throws SQLException {
        //preparazione del comando
        PreparedStatement cercaSerie = connection.prepareStatement("SELECT * FROM serie");
        try {
            ResultSet serieTrovate = cercaSerie.executeQuery(); //esegue la query
            while (serieTrovate.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                idSerie.add(serieTrovate.getInt(1));
                nomeSerie.add(serieTrovate.getString(2));
            }
            serieTrovate.close(); //chiusura del resultset
        } finally {
            cercaSerie.close();
        }
    }

    /**
     * Rimuove un libro da una serie nel database.
     *
     * @param isbn    Isbn del libro da rimuovere dalla serie.
     * @param idserie Id della serie da cui si vuole rimuovere il libro.
     */
    @Override
    public void aggiungiSerieALibro(String isbn, int idserie) throws SQLException {
        //preparazione del comando di eliminazione
        PreparedStatement aggiungiSerie = connection.prepareStatement("INSERT INTO  rel_libro_serie values (?,?)");
        //impostazione dei parametri del comando
        aggiungiSerie.setString(1, isbn);
        aggiungiSerie.setInt(2, idserie);
        try {
            aggiungiSerie.executeUpdate(); //esecuzione del comando
        } finally {
            aggiungiSerie.close();
        }
    }

    /**
     * Rimuove un libro dalla serie nel database.
     *
     * @param isbn    L'isbn del libro che si vuole rimuovere dalla serie.
     * @param idserie L'id della serie da cui si vuole rimuovere il libro.
     */
    @Override
    public void rimuoviSerieALibro(String isbn, int idserie) throws SQLException {
        //prepara il comando
        PreparedStatement rimuoviSerie = connection.prepareStatement("DELETE FROM  rel_libro_serie WHERE isbn = ? AND idserie = ?");
        //imposta i parametri
        rimuoviSerie.setString(1, isbn);
        rimuoviSerie.setInt(2, idserie);
        try {
            rimuoviSerie.executeUpdate(); //esegue il comando
        } finally {
            rimuoviSerie.close();
        }
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
