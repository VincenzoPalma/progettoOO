package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.RomanzoDAO;
import com.biblioteca.database.ConnectionUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Classe DAO che implementa la rispettiva interfaccia RomanzoDAO, gestisce
 * la connessione al database e le interrogazioni, inserimenti e modifiche per
 * quanto riguarda la classe Romanzo.
 */
public class RomanzoImplementazionePostgresDAO implements RomanzoDAO {

    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public RomanzoImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Cerca nel database tutti i libri didattici che contengono nel loro titolo,
     * ambito o editore la stringa "ricerca".
     *
     * @param ricerca    La stringa scritta dall'utente nella barra di ricerca della homepage.
     * @param isbn       ArrayList che conterrà gli isbn dei libri trovati
     * @param titoli     ArrayList che conterrà i titoli dei libri trovati
     * @param generi     ArrayList che conterrà i generi dei libri trovati
     * @param dateUscita ArrayList che conterrà le date di uscita dei libri trovati
     * @param editori    ArrayList che conterrà gli editori dei libri trovati
     * @param cartaceo   ArrayList che conterrà un boolean per la presenza del formato cartaceo dei libri trovati
     * @param digitale   ArrayList che conterrà un boolean per la presenza del formato digitale dei libri trovati
     * @param audiolibro ArrayList che conterrà un boolean per la presenza del formato audiolibro dei libri trovati
     */
    @Override
    public void cercaRomanzoDB(String ricerca, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> generi, ArrayList<LocalDate> dateUscita, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException {
        //prepara la query
        PreparedStatement cercaRomanzi = connection.prepareStatement("SELECT * FROM libro as l WHERE (l.titolo like '%" + ricerca + "%' OR l.genere like '%" + ricerca + "%' OR l.editore like '%" + ricerca + "%') AND l.tipo = 'Romanzo';");
        try {
            //esegue il comando
            ResultSet romanziTrovati = cercaRomanzi.executeQuery();
            while (romanziTrovati.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                isbn.add(romanziTrovati.getString(1));
                titoli.add(romanziTrovati.getString(2));
                generi.add(romanziTrovati.getString(3));
                dateUscita.add((romanziTrovati.getDate(4).toLocalDate()));
                editori.add(romanziTrovati.getString(6));
                cartaceo.add(romanziTrovati.getBoolean(7));
                digitale.add(romanziTrovati.getBoolean(8));
                audiolibro.add(romanziTrovati.getBoolean(9));
            }
            romanziTrovati.close(); //chiude il resultset
        } finally {
            cercaRomanzi.close(); //chiude il PreparedStatement
        }
    }

    /**
     * Cerca nel database le informazioni sul seguito del romanzo con isbn uguale a
     * quello passato come parametro.
     *
     * @param isbn              Isbn del romanzo di cui si vuole ottenere il seguito.
     * @param isbnSeguito       ArrayList che conterrà gli isbn dei libri trovati
     * @param titoloSeguito     ArrayList che conterrà il titolo dei libri trovati
     * @param genereSeguito     ArrayList che conterrà i generi dei libri trovati
     * @param digitaleSeguito   ArrayList che conterrà le date di uscita dei libri trovati
     * @param editoreSeguito    ArrayList che conterrà gli editori dei libri trovati
     * @param cartaceoSeguito   ArrayList che conterrà un boolean per la presenza del formato cartaceo dei libri trovati
     * @param dataUscitaSeguito ArrayList che conterrà un boolean per la presenza del formato digitale dei libri trovati
     * @param audiolibroSeguito ArrayList che conterrà un boolean per la presenza del formato audiolibro dei libri trovati
     */
    @Override
    public void cercaSeguitoRomanzoDB(String isbn, ArrayList<String> isbnSeguito, ArrayList<String> titoloSeguito, ArrayList<String> genereSeguito, ArrayList<LocalDate> dataUscitaSeguito, ArrayList<String> editoreSeguito, ArrayList<Boolean> cartaceoSeguito, ArrayList<Boolean> digitaleSeguito, ArrayList<Boolean> audiolibroSeguito) throws SQLException {
        //prepara la query
        PreparedStatement cercaSeguito = connection.prepareStatement("SELECT * FROM libro as l WHERE l.isbn = (SELECT l2.seguito FROM libro as l2 WHERE l2.isbn = ?)");
        //imposta i parametri della query
        cercaSeguito.setString(1, isbn);
        try {
            ResultSet seguitoTrovato = cercaSeguito.executeQuery(); //esegue la ricerca
            while (seguitoTrovato.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                isbnSeguito.add(seguitoTrovato.getString(1));
                titoloSeguito.add(seguitoTrovato.getString(2));
                genereSeguito.add(seguitoTrovato.getString(3));
                dataUscitaSeguito.add((seguitoTrovato.getDate(4).toLocalDate()));
                editoreSeguito.add(seguitoTrovato.getString(6));
                cartaceoSeguito.add(seguitoTrovato.getBoolean(7));
                digitaleSeguito.add(seguitoTrovato.getBoolean(8));
                audiolibroSeguito.add(seguitoTrovato.getBoolean(9));
            }
            seguitoTrovato.close(); //chiude il resultset
        } finally {
            cercaSeguito.close();
        }
    }

    /**
     * Esegue una modifica al romanzo con isbn uguale a "vecchioIsbn" con i valori
     * passati come parametro.
     *
     * @param vecchioIsbn Isbn originale del romanzo, utilizzato per identificare il romanzo nel database prima della modifica.
     */
    @Override
    public void modificaRomanzoDB(String vecchioIsbn, String nuovoEditore, String nuovoGenere, LocalDate nuovaData, String nuovoIsbn, Boolean nuovoCartaceo, Boolean nuovoDigitale, Boolean nuovoAudiolibro, String isbnSeguito) throws SQLException {
        //preparazione del comando di update
        PreparedStatement modificaLibro = connection.prepareStatement("UPDATE libro SET editore = ?, genere = ?, datauscita = ?, isbn = ?, digitale = ?, cartaceo = ?, audiolibro= ?, seguito = ? WHERE isbn = ?");
        //impostazione dei parametri del comando
        modificaLibro.setString(1, nuovoEditore);
        modificaLibro.setString(2, nuovoGenere);
        modificaLibro.setDate(3, Date.valueOf(nuovaData));
        modificaLibro.setString(4, nuovoIsbn);
        modificaLibro.setBoolean(5, nuovoDigitale);
        modificaLibro.setBoolean(6, nuovoCartaceo);
        modificaLibro.setBoolean(7, nuovoAudiolibro);
        modificaLibro.setString(8, isbnSeguito);
        modificaLibro.setString(9, vecchioIsbn);
        try {
            modificaLibro.executeUpdate(); //esecuzione del comando
        } finally {
            modificaLibro.close();
        }
    }

    /**
     * Cerca i libri della serie con id uguale a quello passato come parametro.
     */
    @Override
    public void cercaRomanzoPerSerie(int idSerie, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> generi, ArrayList<LocalDate> dateUscita, ArrayList<String> tipi, ArrayList<String> editore, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException {
        //preparazione della query
        PreparedStatement cercaLibri = connection.prepareStatement("SELECT * FROM libro as l JOIN rel_libro_serie as r ON r.isbn = l.isbn WHERE r.idserie= ?");
        cercaLibri.setInt(1, idSerie); //impostazione del parametro della query
        try {
            ResultSet risultatiLibri = cercaLibri.executeQuery(); //esecuzione della query
            while (risultatiLibri.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                isbn.add(risultatiLibri.getString(1));
                titoli.add(risultatiLibri.getString(2));
                generi.add(risultatiLibri.getString(3));
                dateUscita.add(risultatiLibri.getDate(4).toLocalDate());
                tipi.add(risultatiLibri.getString(5));
                editore.add(risultatiLibri.getString(6));
                cartaceo.add(risultatiLibri.getBoolean(7));
                digitale.add(risultatiLibri.getBoolean(8));
                audiolibro.add(risultatiLibri.getBoolean(9));
            }
            risultatiLibri.close(); //chiusura del result set
        } finally {
            cercaLibri.close();
        }
    }

    @Override
    public void eliminaSeguito(int idserie) throws SQLException {
        PreparedStatement eliminaSeguiti = connection.prepareStatement("UPDATE libro SET seguito = null WHERE isbn IN (SELECT r.isbn FROM rel_libro_serie as r WHERE r.idserie = ?);");
        eliminaSeguiti.setInt(1, idserie);
        try {
            eliminaSeguiti.executeUpdate();
        } finally {
            eliminaSeguiti.close();
        }
    }

    /**
     * Rimuove il seguito del libro che ha come seguito il libro con isbn
     * uguale a quello passato come parametro.
     *
     * @param isbnLibroRimosso Isbn del libro da rimuovere come seguito.
     */
    @Override
    public void eliminaSeguitoDaLibro(String isbnLibroRimosso) throws SQLException {
        //preparazione del comando
        PreparedStatement eliminaSeguito = connection.prepareStatement("UPDATE libro SET seguito = null WHERE isbn = (SELECT l.isbn FROM libro as l WHERE l.seguito = ?);");
        //impostazione del parametro del comando
        eliminaSeguito.setString(1, isbnLibroRimosso);
        try {
            eliminaSeguito.executeUpdate(); //esecuzione dell'update
        } finally {
            eliminaSeguito.close();
        }
    }

    @Override
    public void cercaRomanziPerSerieSenzaSeguito(int idserie, ArrayList<String> isbn, ArrayList<String> titoli, ArrayList<String> generi, ArrayList<LocalDate> dateUscita, ArrayList<String> tipi, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro, ArrayList<String> isbnSeguiti) throws SQLException {
        PreparedStatement cercaRomanzi = connection.prepareStatement("SELECT * FROM libro as l JOIN rel_libro_serie as r ON r.isbn = l.isbn WHERE r.idserie = ? AND l.isbn NOT IN (SELECT l2.seguito FROM libro as l2 WHERE l2.seguito IS NOT NULL)");
        cercaRomanzi.setInt(1, idserie);
        try {
            ResultSet romanziTrovati = cercaRomanzi.executeQuery();
            while (romanziTrovati.next()) {
                isbn.add(romanziTrovati.getString(1));
                titoli.add(romanziTrovati.getString(2));
                generi.add(romanziTrovati.getString(3));
                dateUscita.add((romanziTrovati.getDate(4).toLocalDate()));
                tipi.add(romanziTrovati.getString(5));
                editori.add(romanziTrovati.getString(6));
                cartaceo.add(romanziTrovati.getBoolean(7));
                digitale.add(romanziTrovati.getBoolean(8));
                audiolibro.add(romanziTrovati.getBoolean(9));
                isbnSeguiti.add(romanziTrovati.getString(10));
            }
            romanziTrovati.close();
        } finally {
            cercaRomanzi.close();
        }
    }

}
