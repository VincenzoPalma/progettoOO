package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.ArticoloScientificoDAO;
import com.biblioteca.database.ConnectionUtil;
import org.jetbrains.annotations.Nullable;

import java.sql.*;
import java.util.ArrayList;

/**
 * Classe DAO che implementa la rispettiva interfaccia ArticoloScientificoDAO, gestisce
 * la connessione al database e le interrogazioni, inserimenti e modifiche per
 * quanto riguarda la classe ArticoloScientifico.
 */
public class ArticoloScientificoImplementazionePostgresDAO implements ArticoloScientificoDAO {

    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public ArticoloScientificoImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Inserisce nel database un articolo con attributi uguali a quelli passati come parametro al metodo.
     *
     * @param titolo            Il titolo dell'articolo da inserire
     * @param tema              Il tema dell'articolo da inserire
     * @param argomento         L'argomento dell'articolo da inserire
     * @param annoPubblicazione L'anno di pubblicazione dell'articolo da inserire
     * @param editore           L'editore dell'articolo da inserire
     * @param cartaceo          Boolean per la presenza del formato cartaceo dell'articolo da inserire
     * @param digitale          Boolean per la presenza del formato digitale dell'articolo da inserire
     * @param audiolibro        Boolean per la presenza del formato audiolibro dell'articolo da inserire
     * @param issnRivista       Issn della rivista attribuita all'articolo, può essere null
     * @param numeroRivista     Numero della rivista attribuita all'articolo, può essere null
     * @param idConferenza      Id della conferenza attribuita all'articolo, può essere null
     */
    @Override
    public void aggiungiArticoloScientificoDB(String titolo, String tema, String argomento, int annoPubblicazione, String editore, Boolean cartaceo, Boolean digitale, Boolean audiolibro, String issnRivista, Integer numeroRivista, Integer idConferenza) throws SQLException {
        //preparazione del comando d'inserimento
        PreparedStatement inserimentoArticolo = connection.prepareStatement("INSERT INTO articoloscientifico VALUES (default, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        //impostazione dei parametri del comando d'inserimento
        inserimentoArticolo.setString(1, titolo);
        inserimentoArticolo.setString(2, tema);
        inserimentoArticolo.setString(3, argomento);
        inserimentoArticolo.setInt(4, annoPubblicazione);
        inserimentoArticolo.setString(5, editore);
        inserimentoArticolo.setBoolean(6, cartaceo);
        inserimentoArticolo.setBoolean(7, digitale);
        inserimentoArticolo.setBoolean(8, audiolibro);
        //se non si vuole attribuire una rivista all'articolo, i relativi parametri vengono impostati a null
        if (issnRivista == null) {
            inserimentoArticolo.setString(9, null);
            inserimentoArticolo.setNull(10, Types.INTEGER);
        } else {
            inserimentoArticolo.setString(9, issnRivista);
            inserimentoArticolo.setInt(10, numeroRivista);
        }
        //se non si vuole attribuire una conferenza all'articolo, il relativo parametro viene impostato a null
        if (idConferenza == null) {
            inserimentoArticolo.setNull(11, Types.INTEGER);
        } else {
            inserimentoArticolo.setInt(11, idConferenza);
        }
        try {
            //esecuzione dell'inserimento
            inserimentoArticolo.executeUpdate();
        } finally {
            inserimentoArticolo.close(); //chiusura del PreparedStatement
        }
    }

    /**
     * Modifica l'articolo nel database con id uguale all'articolo da modificare.
     *
     * @param idArticolo Id dell'articolo da modificare.
     */
    @Override
    public void modificaArticoloScientificoDB(int idArticolo, String titolo, String tema, String argomento, int annoPubblicazione, String editore, Boolean cartaceo, Boolean digitale, Boolean audiolibro, @Nullable Integer idConferenza, @Nullable String issnRivista, @Nullable Integer numeroRivista) throws SQLException {
        //preparazione del comando
        PreparedStatement modificaArticolo = connection.prepareStatement("UPDATE articoloscientifico SET titolo = ?, tema = ?, argomento = ?, annopubblicazione = ?, editore = ?, cartaceo = ?, digitale = ?, audiolibro = ?, idconferenza = ?, issn_rivista = ?, numero_rivista = ? WHERE idarticolo = ?;");
        //impostazione dei parametri del comando d'inserimento
        modificaArticolo.setString(1, titolo);
        modificaArticolo.setString(2, tema);
        modificaArticolo.setString(3, argomento);
        modificaArticolo.setInt(4, annoPubblicazione);
        modificaArticolo.setString(5, editore);
        modificaArticolo.setBoolean(6, cartaceo);
        modificaArticolo.setBoolean(7, digitale);
        modificaArticolo.setBoolean(8, audiolibro);
        modificaArticolo.setObject(9, idConferenza);
        modificaArticolo.setString(10, issnRivista);
        modificaArticolo.setObject(11, numeroRivista);
        modificaArticolo.setInt(12, idArticolo);
        try {
            modificaArticolo.executeUpdate(); //esecuzione del comando
        } finally {
            modificaArticolo.close();
        }
    }

    /**
     * Elimina l'articolo con id uguale a quello passato come parametro
     * dal database.
     *
     * @param idarticolo Id dell'articolo da eliminare.
     */
    @Override
    public void eliminaArticoloScientificoDB(int idarticolo) throws SQLException {
        //preparazione del comando
        PreparedStatement eliminaArticolo = connection.prepareStatement("DELETE FROM articoloscientifico WHERE idarticolo = ?");
        eliminaArticolo.setInt(1, idarticolo); //impostazione del parametro
        try {
            eliminaArticolo.executeUpdate(); //esecuzione del comando
        } finally {
            eliminaArticolo.close();
        }
    }

    /**
     * Cerca nel database tutti gli articoli che contengono nel loro titolo,
     * argomento, tema o editore la stringa di ricerca passata come parametro.
     *
     * @param ricerca           La stringa scritta dall'utente nella barra di ricerca della homepage.
     * @param idArticoli        ArrayList che conterrà gli id degli articoli trovati
     * @param titoli            ArrayList che conterrà i titoli degli articoli trovati
     * @param tema              ArrayList che conterrà i temi degli articoli trovati
     * @param argomenti         ArrayList che conterrà gli argomenti degli articoli trovati
     * @param annoPubblicazione ArrayList che conterrà l'anno di pubblicazione degli articoli trovati
     * @param editori           ArrayList che conterrà gli editori degli articoli trovati
     * @param cartaceo          ArrayList che conterrà un boolean per la presenza del formato cartaceo degli articoli trovati
     * @param digitale          ArrayList che conterrà un boolean per la presenza del formato digitale degli articoli trovati
     * @param audiolibro        ArrayList che conterrà un boolean per la presenza del formato audiolibro degli articoli trovati
     */
    @Override
    public void cercaArticoloDB(String ricerca, ArrayList<Integer> idArticoli, ArrayList<String> titoli, ArrayList<String> tema, ArrayList<String> argomenti, ArrayList<Integer> annoPubblicazione, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException {
        //prepara la query
        PreparedStatement cercaArticoli = connection.prepareStatement("SELECT * FROM articoloscientifico as a WHERE a.titolo like '%" + ricerca + "%' OR a.tema like '%" + ricerca + "%' OR a.argomento like ' %" + ricerca + "%' OR a.editore like '%" + ricerca + "%';");
        try {
            //esegue la query
            ResultSet articolitrovati = cercaArticoli.executeQuery();
            while (articolitrovati.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                idArticoli.add(articolitrovati.getInt(1));
                titoli.add(articolitrovati.getString(2));
                tema.add(articolitrovati.getString(3));
                argomenti.add(articolitrovati.getString(4));
                annoPubblicazione.add(articolitrovati.getInt(5));
                editori.add(articolitrovati.getString(6));
                cartaceo.add(articolitrovati.getBoolean(7));
                digitale.add(articolitrovati.getBoolean(8));
                audiolibro.add(articolitrovati.getBoolean(9));
            }
            articolitrovati.close(); //chiusura del resultset
        } finally {
            cercaArticoli.close(); //chiusure del PreparedStatement
        }
    }

    /**
     * Cerca gli articoli dell'autore con id passato come parametro.
     */
    @Override
    public void cercaArticoloPerAutore(int idautore, ArrayList<Integer> idArticoli, ArrayList<String> titoli, ArrayList<String> tema, ArrayList<String> argomenti, ArrayList<Integer> annoPubblicazione, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException {
        //preparazione della query
        PreparedStatement cercaArticoli = connection.prepareStatement("SELECT * FROM articoloscientifico as a JOIN rel_autore_articolo as r ON a.idarticolo = r.idarticolo WHERE r.idautore = ?");
        cercaArticoli.setInt(1, idautore); //impostazione del parametro
        try {
            ResultSet risultatiArticoli = cercaArticoli.executeQuery(); //esecuzione della query
            while (risultatiArticoli.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                idArticoli.add(risultatiArticoli.getInt(1));
                titoli.add(risultatiArticoli.getString(2));
                tema.add(risultatiArticoli.getString(3));
                argomenti.add(risultatiArticoli.getString(4));
                annoPubblicazione.add(risultatiArticoli.getInt(5));
                editori.add(risultatiArticoli.getString(6));
                cartaceo.add(risultatiArticoli.getBoolean(7));
                digitale.add(risultatiArticoli.getBoolean(8));
                audiolibro.add(risultatiArticoli.getBoolean(9));
            }
            risultatiArticoli.close(); //chiusura del resultset
        } finally {
            cercaArticoli.close();
        }
    }

    /**
     * Cerca gli articoli della rivista con issn e numero passati come parametri.
     */
    @Override
    public void cercaArticoloPerRivista(String issnRivista, int numeroRivista, ArrayList<Integer> idArticoli, ArrayList<String> titoli, ArrayList<String> tema, ArrayList<String> argomenti, ArrayList<Integer> annoPubblicazione, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException {
        //preparazione della query
        PreparedStatement cercaArticoli = connection.prepareStatement("SELECT * FROM articoloscientifico as a WHERE a.issn_rivista = ? AND a.numero_rivista = ?");
        //impostazione dei parametri
        cercaArticoli.setString(1, issnRivista);
        cercaArticoli.setInt(2, numeroRivista);
        try {
            ResultSet risultatiArticoli = cercaArticoli.executeQuery(); //esecuzione della query
            while (risultatiArticoli.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                idArticoli.add(risultatiArticoli.getInt(1));
                titoli.add(risultatiArticoli.getString(2));
                tema.add(risultatiArticoli.getString(3));
                argomenti.add(risultatiArticoli.getString(4));
                annoPubblicazione.add(risultatiArticoli.getInt(5));
                editori.add(risultatiArticoli.getString(6));
                cartaceo.add(risultatiArticoli.getBoolean(7));
                digitale.add(risultatiArticoli.getBoolean(8));
                audiolibro.add(risultatiArticoli.getBoolean(9));
            }
            risultatiArticoli.close(); //chiusura del resultset
        } finally {
            cercaArticoli.close();
        }
    }

    /**
     * Cerca gli articoli della conferenza con id passato come parametro.
     */
    @Override
    public void cercaArticoloPerConferenza(int idConferenza, ArrayList<Integer> idArticoli, ArrayList<String> titoli, ArrayList<String> tema, ArrayList<String> argomenti, ArrayList<Integer> annoPubblicazione, ArrayList<String> editori, ArrayList<Boolean> cartaceo, ArrayList<Boolean> digitale, ArrayList<Boolean> audiolibro) throws SQLException {
        //preparazione della query
        PreparedStatement cercaArticoli = connection.prepareStatement("SELECT * FROM articoloscientifico as a WHERE a.idconferenza = ?");
        //impostazione dei parametri
        cercaArticoli.setInt(1, idConferenza);
        try {
            ResultSet risultatiArticoli = cercaArticoli.executeQuery(); //esecuzione della query
            while (risultatiArticoli.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                idArticoli.add(risultatiArticoli.getInt(1));
                titoli.add(risultatiArticoli.getString(2));
                tema.add(risultatiArticoli.getString(3));
                argomenti.add(risultatiArticoli.getString(4));
                annoPubblicazione.add(risultatiArticoli.getInt(5));
                editori.add(risultatiArticoli.getString(6));
                cartaceo.add(risultatiArticoli.getBoolean(7));
                digitale.add(risultatiArticoli.getBoolean(8));
                audiolibro.add(risultatiArticoli.getBoolean(9));
            }
            risultatiArticoli.close(); //chiusura del resultset
        } finally {
            cercaArticoli.close();
        }
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
