package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.UtenteDAO;
import com.biblioteca.database.ConnectionUtil;

import java.sql.*;
import java.util.ArrayList;

/**
 * Classe DAO che implementa la rispettiva interfaccia UtenteDAO, gestisce
 * la connessione al database e le interrogazioni, inserimenti e modifiche per
 * quanto riguarda la classe Utente.
 */
public class UtenteImplementazionePostgresDAO implements UtenteDAO {

    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public UtenteImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Prova a inserire nel database un utente con username e password
     * uguali a quelli passati come parametro.
     *
     * @param username L'username dell'utente da registrare
     * @param password La password dell'utente da registrare
     */
    @Override
    public void registraUtenteDB(String username, String password) throws SQLException {
        //preparazione del comando d'inserimento
        PreparedStatement inserisciUtente = connection.prepareStatement("INSERT INTO utente VALUES (?, ?, 'Utente')");
        //impostazione dei parametri del comando d'inserimento
        inserisciUtente.setString(1, username);
        inserisciUtente.setString(2, password);
        try {
            //esegue l'inserimento
            inserisciUtente.executeUpdate();
        } finally {
            inserisciUtente.close(); //chiusura del PreparedStatement
        }
    }

    /**
     * Modifica l'username dell'utente con username uguale all'username passato come parametro
     * con la stringa "nuovoUsername" presa come parametro.
     *
     * @param nuovoUsername   Nuovo username da inserire nel database.
     * @param vecchioUsername L'username dell'utente di cui si vuole modificare l'username.
     * @throws SQLException Eccezione lanciata nel caso in cui l'username inserito è già in uso.
     */
    @Override
    public void modificaUsernameUtenteDB(String nuovoUsername, String vecchioUsername) throws SQLException {
        //prepara il comando di modifica
        PreparedStatement modificaUsername = connection.prepareStatement("UPDATE utente SET username = ? WHERE username = ?;");
        //imposta i parametri del comando
        modificaUsername.setString(1, nuovoUsername);
        modificaUsername.setString(2, vecchioUsername);
        try {
            modificaUsername.executeUpdate(); //esegue la modifica
        } finally {
            modificaUsername.close(); //chiude il PreparedStatement
        }
    }

    /**
     * Esegue un operazione sul database per eliminare l'utente con username uguale
     * a quello passato come parametro.
     *
     * @param username Username dell'utente che si vuole eliminare.
     */
    @Override
    public void eliminaUtenteDB(String username) throws SQLException {
        //prepara il comando di eliminazione
        PreparedStatement eliminaUtente = connection.prepareStatement("DELETE FROM utente WHERE username = ?");
        //imposta il parametro del comando
        eliminaUtente.setString(1, username);
        try {
            eliminaUtente.executeUpdate(); //esegue l'eliminazione
        } finally {
            eliminaUtente.close(); //chiude il PreparedStatement
        }
    }

    /**
     * @param username L'username dell'utente a cui aggiungere la preferenza.
     * @param idSerie  L'id della serie da aggiungere come preferenza.
     */
    @Override
    public boolean aggiungiPreferenzaSerieDB(String username, int idSerie) throws SQLException {
        //preparazione del comando
        PreparedStatement aggiungiPreferenza = connection.prepareStatement("INSERT INTO rel_serie_utente VALUES (?, ?)");
        //impostazione dei parametri
        aggiungiPreferenza.setString(1, username);
        aggiungiPreferenza.setInt(2, idSerie);
        //controllo nel database tramite la funzione "negozi_serie_completa" per controllare la serie appena aggiunta come preferenza, è disponibile in almeno un negozio
        CallableStatement controllaDisponibilita = connection.prepareCall("{call negozi_serie_completa(?)}");
        try {
            aggiungiPreferenza.executeUpdate(); //esecuzione del comando
            controllaDisponibilita.setInt(1, idSerie); //impostazione del parametro per la funzione
            ResultSet disponibilita = controllaDisponibilita.executeQuery(); //esecuzione della funzione
            //se esiste un risultato ritorna true, altrimenti false
            return disponibilita.next();
        } finally {
            aggiungiPreferenza.close();
            controllaDisponibilita.close();
        }
    }

    /**
     * Rimuove la preferenza della serie con id come parametro all'utente con username
     * come parametro.
     *
     * @param username L'username dell'utente a cui rimuovere la serie.
     * @param idSerie  L'id della serie della preferenza da rimuovere.
     */
    @Override
    public void eliminaPreferenzaSerieDB(String username, int idSerie) throws SQLException {
        //prepara il comando di eliminazione
        PreparedStatement eliminaPreferenza = connection.prepareStatement("DELETE FROM rel_serie_utente as r WHERE r.idserie = ? AND r.username = ?");
        //imposta i parametri del comando
        eliminaPreferenza.setInt(1, idSerie);
        eliminaPreferenza.setString(2, username);
        try {
            //esegue il comando
            eliminaPreferenza.executeUpdate();
        } finally {
            eliminaPreferenza.close(); //chiude il PreparedStatement
        }
    }

    /**
     * Cerca nel database l'utente che ha come username e password
     * quelli passati come parametri.
     *
     * @param username          Username dell'utente che si sta cercando.
     * @param password          Password dell'username che si sta cercando.
     * @param usernameTrovato   ArrayList che conterrà l'eventuale username trovato
     * @param passwordTrovata   ArrayList che conterrà l'eventuale password trovata
     * @param tipoUtenteTrovato ArrayList che conterrà l'eventuale tipo di utente trovato
     */
    @Override
    public void cercaUtenteDB(String username, String password, ArrayList<String> usernameTrovato, ArrayList<String> passwordTrovata, ArrayList<String> tipoUtenteTrovato) throws SQLException {
        //preparazione della query di ricerca dell'utente
        PreparedStatement cercaUtente = connection.prepareStatement("SELECT * FROM utente as u WHERE u.username = ? AND u.password = ?;");
        //impostazione dei parametri della query
        cercaUtente.setString(1, username);
        cercaUtente.setString(2, password);
        try {
            //esecuzione della query
            ResultSet utentetrovato = cercaUtente.executeQuery();
            if (utentetrovato.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                usernameTrovato.add(utentetrovato.getString(1));
                passwordTrovata.add(utentetrovato.getString(2));
                tipoUtenteTrovato.add(utentetrovato.getString(3));
            }
            utentetrovato.close(); //chiusura del resultset
        } finally {
            cercaUtente.close(); //chiusura del prepared statement
        }
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


