package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.SalaDAO;
import com.biblioteca.database.ConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Classe DAO che implementa la rispettiva interfaccia SalaDAO, gestisce
 * la connessione al database e le interrogazioni, inserimenti e modifiche per
 * quanto riguarda la classe Sala.
 */
public class SalaImplementazionePostgresDAO implements SalaDAO {

    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public SalaImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Inserisce nel database una sala con attributi uguali ai valori
     * passati come parametro.
     *
     * @param nome      Il nome della sala da inserire
     * @param indirizzo L'indirizzo della sala da inserire
     * @param capienza  La capienza della sala da inserire
     */
    @Override
    public void aggiungiSalaDB(String nome, String indirizzo, int capienza) throws SQLException {
        //prepara il comando d'inserimento
        PreparedStatement aggiungiSala = connection.prepareStatement("INSERT INTO sala VALUES (default, ?, ?, ?)");
        //imposta i parametri del comando
        aggiungiSala.setString(1, nome);
        aggiungiSala.setString(2, indirizzo);
        aggiungiSala.setInt(3, capienza);
        try {
            aggiungiSala.executeUpdate(); //esegue l'inserimento
        } finally {
            aggiungiSala.close();
        }


    }

    /**
     * Modifica la sala con l'id sala uguale a quello passato come parametro.
     *
     * @param idSala L'id della sala da modificare.
     */
    @Override
    public void modificaSalaDB(int idSala, String nome, String indirizzo, int capienza) throws SQLException {
        //prepara il comando
        PreparedStatement modificaSala = connection.prepareStatement("UPDATE sala SET nome = ?, indirizzo = ?, capienza = ? WHERE idsala = ?");
        //imposta i parametri
        modificaSala.setString(1, nome);
        modificaSala.setString(2, indirizzo);
        modificaSala.setInt(3, capienza);
        modificaSala.setInt(4, idSala);
        try {
            modificaSala.executeUpdate(); //esegue il comando
        } finally {
            modificaSala.close();
        }
    }

    /**
     * Elimina la sala con id uguale a quello passato come parametro.
     *
     * @param idsala Id della sala da eliminare.
     */
    @Override
    public void eliminaSalaDB(int idsala) throws SQLException {
        //prepara il comando
        PreparedStatement eliminaSala = connection.prepareStatement("DELETE FROM sala WHERE idsala = ?");
        eliminaSala.setInt(1, idsala); //imposta il parametro
        try {
            eliminaSala.executeUpdate(); //esegue il comando
        } finally {
            eliminaSala.close();
        }


    }

    /**
     * Cerca le informazioni della sala con id uguale a quello passato
     * come parametro.
     *
     * @param idSala        L'id della sala che si vuole cercare.
     * @param nomeSale      ArrayList che conterrà i nomi delle sale trovate
     * @param indirizziSale ArrayList che conterrà gli indirizzi delle sale trovate
     * @param capienzaSale  ArrayList che conterrà il numero dei posti delle sale trovate
     */
    @Override
    public void cercaSalaPerIdDB(int idSala, ArrayList<String> nomeSale, ArrayList<String> indirizziSale, ArrayList<Integer> capienzaSale) throws SQLException {
        //preparazione della query
        PreparedStatement cercaSala = connection.prepareStatement("SELECT * FROM sala as s WHERE s.idsala = ?");
        //impostazione del parametro della query
        cercaSala.setInt(1, idSala);
        try {
            ResultSet salaTrovata = cercaSala.executeQuery(); //esecuzione della query
            while (salaTrovata.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                nomeSale.add(salaTrovata.getString(2));
                indirizziSale.add(salaTrovata.getString(3));
                capienzaSale.add(salaTrovata.getInt(4));
            }
            salaTrovata.close(); //chiusura del resultset
        } finally {
            cercaSala.close();
        }
    }

    /**
     * Cerca tutte le sale nel database.
     */
    @Override
    public void getAllSale(ArrayList<Integer> idSale, ArrayList<String> nomeSale, ArrayList<String> indirizziSale, ArrayList<Integer> capienzaSale) throws SQLException {
        //preparazione della query
        PreparedStatement cercaSale = connection.prepareStatement("SELECT * FROM sala");
        try {
            ResultSet saleTrovate = cercaSale.executeQuery(); //esecuzione della query
            while (saleTrovate.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                idSale.add(saleTrovate.getInt(1));
                nomeSale.add(saleTrovate.getString(2));
                indirizziSale.add(saleTrovate.getString(3));
                capienzaSale.add(saleTrovate.getInt(4));
            }
            saleTrovate.close(); //chiusura del resultset
        } finally {
            cercaSale.close();
        }
    }


}
