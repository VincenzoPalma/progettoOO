package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.EsposizioneDAO;
import com.biblioteca.database.ConnectionUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Classe DAO che implementa la rispettiva interfaccia EsposizioneDAO, gestisce
 * la connessione al database e le interrogazioni, inserimenti e modifiche per
 * quanto riguarda la classe Esposizione.
 */
public class EsposizioneImplementazionePostgresDAO implements EsposizioneDAO {

    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public EsposizioneImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Aggiunge un esposizione di un libro in una sala nel database.
     *
     * @param isbn            L'isbn del libro di cui si vuole inserire l'esposizione.
     * @param idSala          L'id della sala di cui si vuole inserire l'esposizione.
     * @param dataEsposizione Data dell'esposizione.
     */
    @Override
    public void aggiungiEsposizioneDB(int idSala, String isbn, LocalDate dataEsposizione) throws SQLException {
        //preparazione del comando
        PreparedStatement aggiungiEsposizione = connection.prepareStatement("INSERT INTO rel_libro_sala VALUES (?, ?, ?);");
        //impostazione dei parametri
        aggiungiEsposizione.setString(1, isbn);
        aggiungiEsposizione.setInt(2, idSala);
        aggiungiEsposizione.setDate(3, Date.valueOf(dataEsposizione));
        try {
            aggiungiEsposizione.executeUpdate(); //esecuzione del comando
        } finally {
            aggiungiEsposizione.close();
        }
    }

    /**
     * Elimina l'esposizione di un libro da una sala nel database.
     *
     * @param isbn   L'isbn del libro di cui si vuole eliminare l'esposizione.
     * @param idsala L'id della sala di cui si vuole eliminare l'esposizione.
     */
    @Override
    public void eliminaEsposizioneDB(String isbn, int idsala) throws SQLException {
        //prepara il comando
        PreparedStatement eliminaEsposizione = connection.prepareStatement("DELETE FROM rel_libro_sala WHERE isbn = ? AND idsala = ?;");
        //imposta i parametri
        eliminaEsposizione.setString(1, isbn);
        eliminaEsposizione.setInt(2, idsala);
        try {
            eliminaEsposizione.executeUpdate(); //esegue il comando
        } finally {
            eliminaEsposizione.close();
        }
    }

    /**
     * Cerca nel database le esposizioni relative al libro passato come parametro.
     *
     * @param isbn            Isbn del libro di cui si vogliono cercare le sale in cui è stato esposto.
     * @param idSale          Id delle sale relative alle esposizioni trovate.
     * @param dateEsposizioni Date delle esposizioni trovate.
     */
    @Override
    public void cercaEsposizioniPerIsbnDB(String isbn, ArrayList<Integer> idSale, ArrayList<LocalDate> dateEsposizioni) throws SQLException {
        //prepara la query
        PreparedStatement cercaEsposizioni = connection.prepareStatement("SELECT * FROM rel_libro_sala as r WHERE r.isbn = ?");
        //impostazione del parametro della query
        cercaEsposizioni.setString(1, isbn);
        try {
            //esecuzione della query
            ResultSet risultatiEsposizioni = cercaEsposizioni.executeQuery();
            while (risultatiEsposizioni.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                idSale.add(risultatiEsposizioni.getInt(2));
                dateEsposizioni.add(risultatiEsposizioni.getDate(3).toLocalDate());
            }
            risultatiEsposizioni.close(); //chiusura del resultset
        } finally {
            cercaEsposizioni.close();
        }
    }

    /**
     * Cerca i libri esposti nella sala con id uguale a quello passato come parametro.
     *
     * @param idSala L'id della sala di cui si vogliono ottenere i libri esposti.
     */
    @Override
    public void cercaEsposizioniPerIdSala(int idSala, ArrayList<String> isbnLibriEsposti, ArrayList<LocalDate> dateEsposizioni) throws SQLException {
        //preparazione della query
        PreparedStatement cercaEsposizioni = connection.prepareStatement("SELECT * FROM rel_libro_sala as r WHERE r.idsala = ?");
        cercaEsposizioni.setInt(1, idSala); //impostazione del parametro
        try {
            ResultSet risultatiEsposizioni = cercaEsposizioni.executeQuery();
            while (risultatiEsposizioni.next()) {
                isbnLibriEsposti.add(risultatiEsposizioni.getString(1));
                dateEsposizioni.add(risultatiEsposizioni.getDate(3).toLocalDate());
            }
            risultatiEsposizioni.close(); //chiusura del resultset
        } finally {
            cercaEsposizioni.close();
        }
    }

}
