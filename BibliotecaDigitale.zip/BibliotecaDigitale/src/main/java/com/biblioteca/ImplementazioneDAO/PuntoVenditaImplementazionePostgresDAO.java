package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.PuntoVenditaDAO;
import com.biblioteca.database.ConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Classe DAO che implementa la rispettiva interfaccia PuntoVenditaDAO, gestisce
 * la connessione al database e le interrogazioni, inserimenti e modifiche per
 * quanto riguarda la classe PuntoVendita.
 */
public class PuntoVenditaImplementazionePostgresDAO implements PuntoVenditaDAO {


    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public PuntoVenditaImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Inserisce nel database il punto vendita con i dati passati come parametro e associato
     * al negozio con id passato come parametro.
     *
     * @param citta     La città del punto vendita da inserire
     * @param nome      Il nome del punto vendita da inserire
     * @param idnegozio L'id del negozio a cui verrà associato il punto vendita inserito.
     */
    @Override
    public void aggiungiPuntoVenditaDB(String citta, String nome, int idnegozio) throws SQLException {
        //preparazione del comando d'inserimento
        PreparedStatement aggiungiPuntoVendita = connection.prepareStatement("INSERT INTO puntovendita values (default,?,?,?)");
        //impostazione dei parametri del comando
        aggiungiPuntoVendita.setString(1, nome);
        aggiungiPuntoVendita.setString(2, citta);
        aggiungiPuntoVendita.setInt(3, idnegozio);
        try {
            aggiungiPuntoVendita.executeUpdate(); //esecuzione dell'inserimento
        } finally {
            aggiungiPuntoVendita.close();
        }

    }

    /**
     * Cerca nel database i punti vendita del negozio passato come
     * parametro.
     *
     * @param idNegozio L'id del negozio di cui si vogliono ottenere i punti vendita.
     */
    @Override
    public void cercaPuntoVenditaPerIdNegozio(int idNegozio, ArrayList<Integer> idPuntiVendita, ArrayList<String> nomiPuntoVendita, ArrayList<String> cittaPuntoVendita) throws SQLException {
        //prepara la query
        PreparedStatement cercaPuntiVendita = connection.prepareStatement("SELECT * FROM puntovendita as p WHERE p.idnegozio = ?");
        cercaPuntiVendita.setInt(1, idNegozio); //imposta il parametro
        try {
            ResultSet puntiVenditaTrovati = cercaPuntiVendita.executeQuery(); //esegue la query
            while (puntiVenditaTrovati.next()) {
                idPuntiVendita.add(puntiVenditaTrovati.getInt(1));
                nomiPuntoVendita.add(puntiVenditaTrovati.getString(2));
                cittaPuntoVendita.add(puntiVenditaTrovati.getString(3));
            }
            puntiVenditaTrovati.close(); //chiusura del resultset
        } finally {
            cercaPuntiVendita.close();
        }
    }
}
