package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.AutoreDAO;
import com.biblioteca.database.ConnectionUtil;
import org.jetbrains.annotations.Nullable;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Classe DAO che implementa la rispettiva interfaccia AutoreDAO, gestisce
 * la connessione al database e le interrogazioni, inserimenti e modifiche per
 * quanto riguarda la classe Autore.
 */
public class AutoreImplementazionePostgresDAO implements AutoreDAO {
    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public AutoreImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Inserisce nel database un autore con attributi uguali ai valori
     * passati come parametro.
     *
     * @param nominativo  Il nominativo dell'autore da inserire
     * @param istituto    L'istituto dell'autore da inserire, può essere null
     * @param dataNascita La data di nascita dell'autore da inserire, può essere null
     */
    @Override
    public void aggiungiAutoreDB(String nominativo, @Nullable String istituto, @Nullable LocalDate dataNascita) throws SQLException {
        //prepara il comando d'inserimento
        PreparedStatement aggiungiAutore = connection.prepareStatement("INSERT INTO autore VALUES (default, ?, ?, ?)");
        //imposta i parametri del comando
        aggiungiAutore.setString(1, nominativo);
        aggiungiAutore.setString(3, istituto);
        //se la data di nascita non è stata inserita, la imposta a null
        if (dataNascita == null) {
            aggiungiAutore.setDate(2, null);
        } else {
            aggiungiAutore.setDate(2, Date.valueOf(dataNascita));
        }
        try {
            aggiungiAutore.executeUpdate(); //esegue l'inserimento
        } finally {
            aggiungiAutore.close(); //chiude il PreparedStatement
        }
    }

    /**
     * Elimina dal database l'autore con id uguale a quello passato come parametro.
     *
     * @param idautore Id dell'autore da eliminare.
     */
    @Override
    public void eliminaAutoreDB(int idautore) throws SQLException {
        //preparazione del comando
        PreparedStatement eliminaAutore = connection.prepareStatement("DELETE FROM autore WHERE idautore = ?");
        eliminaAutore.setInt(1, idautore); //impostazione del parametro
        try {
            eliminaAutore.executeUpdate(); //esegue il comando
        } finally {
            eliminaAutore.close();
        }
    }


    @Override
    public void modificaAutoreDB(int idAutore, String nominativo, @Nullable String istituto, @Nullable LocalDate datanascita) throws SQLException {
        //prepara il comando
        PreparedStatement modificaAutore = connection.prepareStatement("UPDATE autore SET istituto = ?, datanascita = ?, nominativo = ? WHERE idautore = ?");
        //imposta i parametri del comando
        modificaAutore.setString(1, istituto);
        if (datanascita == null) {
            modificaAutore.setDate(2, null);
        } else {
            modificaAutore.setDate(2, Date.valueOf(datanascita));
        }
        modificaAutore.setString(3, nominativo);
        modificaAutore.setInt(4, idAutore);
        try {
            modificaAutore.executeUpdate(); //esegue il comando
        } finally {
            modificaAutore.close();
        }
    }

    /**
     * Cerca nel database gli autori che hanno scritto il libro con
     * isbn uguale a quello passato come parametro.
     *
     * @param isbn              Isbn del libro di cui si vogliono cercare gli autori.
     * @param nominativoAutori  ArrayList contenente i nominativi degli autori trovati
     * @param dataNascitaAutori ArrayList contenente le date di nascita degli autori trovati
     * @param istitutoAutori    ArrayList contenente il nome degli istituti degli autori trovati
     */
    @Override
    public void cercaAutorePerLibroDB(String isbn, ArrayList<Integer> idAutori, ArrayList<String> nominativoAutori, ArrayList<LocalDate> dataNascitaAutori, ArrayList<String> istitutoAutori) throws SQLException {
        //preparazione della query
        PreparedStatement cercaAutori = connection.prepareStatement("SELECT * FROM autore as a JOIN rel_autore_libro as r ON a.idautore = r.idautore WHERE r.isbn = ?");
        //impostazione dei parametri della query
        cercaAutori.setString(1, isbn);
        try {
            ResultSet risultatiAutore = cercaAutori.executeQuery(); //esecuzione della query
            while (risultatiAutore.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                idAutori.add(risultatiAutore.getInt(1));
                nominativoAutori.add(risultatiAutore.getString(2));
                istitutoAutori.add(risultatiAutore.getString(4));
                if (risultatiAutore.getDate(3) == null) { //se l'autore non ha data di nascita, viene inserito null
                    dataNascitaAutori.add(null);
                } else {
                    dataNascitaAutori.add(risultatiAutore.getDate(3).toLocalDate());
                }
            }
        } finally {
            cercaAutori.close();
        }
    }

    /**
     * Cerca nel database gli autori che hanno scritto l'articolo con
     * id uguale a quello passato come parametro.
     *
     * @param idArticolo        Id dell'articolo di cui si vogliono cercare gli autori.
     * @param nominativoAutori  ArrayList contenente i nominativi degli autori trovati
     * @param dataNascitaAutori ArrayList contenente le date di nascita degli autori trovati
     * @param istitutoAutori    ArrayList contenente il nome degli istituti degli autori trovati
     */
    @Override
    public void cercaAutorePerArticoloDB(int idArticolo, ArrayList<Integer> idAutori, ArrayList<String> nominativoAutori, ArrayList<LocalDate> dataNascitaAutori, ArrayList<String> istitutoAutori) throws SQLException {
        //preparazione della query
        PreparedStatement cercaAutori = connection.prepareStatement("SELECT * FROM autore as a JOIN rel_autore_articolo as r ON a.idautore = r.idautore WHERE r.idarticolo = ?");
        //impostazione dei parametri della query
        cercaAutori.setInt(1, idArticolo);
        try {
            ResultSet risultatiAutore = cercaAutori.executeQuery(); //esecuzione della query
            while (risultatiAutore.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                idAutori.add(risultatiAutore.getInt(1));
                nominativoAutori.add(risultatiAutore.getString(2));
                istitutoAutori.add(risultatiAutore.getString(4));
                if (risultatiAutore.getDate(3) == null) { //se l'autore non ha data di nascita, viene inserito null
                    dataNascitaAutori.add(null);
                } else {
                    dataNascitaAutori.add(risultatiAutore.getDate(3).toLocalDate());
                }
            }
        } finally {
            cercaAutori.close();
        }
    }

    /**
     * Ottiene tutti gli autori nel database.
     */
    @Override
    public void getAllAutori(ArrayList<Integer> idAutori, ArrayList<String> nominativoAutori, ArrayList<String> istitutoAutori, ArrayList<LocalDate> dataDiNascitaAutori) throws SQLException {
        //preparazione della query
        PreparedStatement cercaAutori = connection.prepareStatement("SELECT * FROM autore");
        try {
            ResultSet autoriTrovati = cercaAutori.executeQuery(); //esecuzione della query
            while (autoriTrovati.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                idAutori.add(autoriTrovati.getInt(1));
                nominativoAutori.add(autoriTrovati.getString(2));
                istitutoAutori.add(autoriTrovati.getString(4));
                if (autoriTrovati.getDate(3) == null) { //se l'autore non ha data di nascita, viene inserito null
                    dataDiNascitaAutori.add(null);
                } else {
                    dataDiNascitaAutori.add(autoriTrovati.getDate(3).toLocalDate());
                }
            }
            autoriTrovati.close(); //chiusura del resultset
        } finally {
            cercaAutori.close();
        }
    }

    /**
     * Elimina la relazione tra il libro e l'autore con isbn e id passati come parametro.
     *
     * @param idautore Id dell'autore da cui si vuole rimuovere il libro.
     * @param isbn     Isbn del libro da rimuovere.
     */
    @Override
    public void rimuoviAutoreDaLibro(int idautore, String isbn) throws SQLException {
        //preparazione del comando
        PreparedStatement rimuoviAutoreLibro = connection.prepareStatement("DELETE FROM rel_autore_libro WHERE idautore = ? AND isbn = ?");
        //impostazione dei parametri
        rimuoviAutoreLibro.setInt(1, idautore);
        rimuoviAutoreLibro.setString(2, isbn);
        try {
            rimuoviAutoreLibro.executeUpdate(); //esegue il comando
        } finally {
            rimuoviAutoreLibro.close();
        }
    }

    /**
     * Elimina la relazione tra l'articolo e l'autore con isbn e id passati come parametro.
     *
     * @param idautore   Id dell'autore da cui si vuole rimuovere l'articolo.
     * @param idarticolo Id dell'articolo da rimuovere.
     */
    @Override
    public void rimuoviAutoreDaArticolo(int idautore, int idarticolo) throws SQLException {
        //preparazione del comando
        PreparedStatement rimuoviAutoreArticolo = connection.prepareStatement("DELETE FROM rel_autore_articolo WHERE idautore = ? AND idarticolo = ?");
        //impostazione dei parametri
        rimuoviAutoreArticolo.setInt(1, idautore);
        rimuoviAutoreArticolo.setInt(2, idarticolo);
        try {
            rimuoviAutoreArticolo.executeUpdate(); //esegue il comando
        } finally {
            rimuoviAutoreArticolo.close();
        }
    }

    /**
     * Aggiunge una relazione tra il libro e l'autore con isbn e id passati come parametro.
     *
     * @param idautore Id dell'autore a cui si vuole aggiungere il libro.
     * @param isbn     Isbn del libro da aggiungere.
     */
    @Override
    public void aggiungiAutoreALibro(int idautore, String isbn) throws SQLException {
        //preparazione del comando
        PreparedStatement aggiungiAutoreLibro = connection.prepareStatement("INSERT INTO rel_autore_libro VALUES (?, ?)");
        //impostazione dei parametri
        aggiungiAutoreLibro.setInt(1, idautore);
        aggiungiAutoreLibro.setString(2, isbn);
        try {
            aggiungiAutoreLibro.executeUpdate(); //esegue il comando
        } finally {
            aggiungiAutoreLibro.close();
        }
    }

    /**
     * Aggiunge una relazione tra l'articolo e l'autore con isbn e id passati come parametro.
     *
     * @param idautore   Id dell'autore a cui si vuole aggiungere l'articolo.
     * @param idarticolo Id dell'articolo da aggiungere.
     */
    @Override
    public void aggiungiAutoreAdArticolo(int idautore, int idarticolo) throws SQLException {
        //preparazione del comando
        PreparedStatement aggiungiAutoreArticolo = connection.prepareStatement("INSERT INTO rel_autore_articolo VALUES (?, ?)");
        //impostazione dei parametri
        aggiungiAutoreArticolo.setInt(1, idautore);
        aggiungiAutoreArticolo.setInt(2, idarticolo);
        try {
            aggiungiAutoreArticolo.executeUpdate(); //esegue il comando
        } finally {
            aggiungiAutoreArticolo.close();
        }
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
