package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.NotificaDAO;
import com.biblioteca.database.ConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

/**
 * Classe DAO che implementa la rispettiva interfaccia NotificaDAO, gestisce
 * la connessione al database e le interrogazioni, inserimenti e modifiche per
 * quanto riguarda la classe Notifica.
 */
public class NotificaImplementazionePostgresDAO implements NotificaDAO {

    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public NotificaImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Cerca nel database tutte le notifiche relative all'utente con username
     * uguale a quello dell'utente passato come parametro.
     *
     * @param username        L'username dell'utente di cui si vogliono ottenere le notifiche.
     * @param serieNotifica   ArrayList che conterrà gli id delle serie relative alle notifiche
     * @param dataNotifiche   ArrayList che conterrà le date delle notifiche trovate
     * @param orarioNotifiche ArrayList che conterrà gli orari delle notifiche trovate
     */
    @Override
    public void cercaNotificheUtente(String username, ArrayList<Integer> serieNotifica, ArrayList<LocalDate> dataNotifiche, ArrayList<LocalTime> orarioNotifiche) throws SQLException {
        //preparazione della query di ricerca dell'utente
        PreparedStatement cercaNotifiche = connection.prepareStatement("SELECT * FROM notifica as n WHERE n.username = ?");
        //impostazione del parametro della query
        cercaNotifiche.setString(1, username);
        try {
            //esecuzione della query
            ResultSet notificheTrovate = cercaNotifiche.executeQuery();
            while (notificheTrovate.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                serieNotifica.add(notificheTrovate.getInt(2));
                dataNotifiche.add(notificheTrovate.getDate(3).toLocalDate());
                orarioNotifiche.add(notificheTrovate.getTime(4).toLocalTime().truncatedTo(ChronoUnit.SECONDS));
            }
            notificheTrovate.close(); //chiusura del resultset
        } finally {
            cercaNotifiche.close(); //chiusura del prepared statement
        }
    }

    /**
     * Cerca la specifica notifica per una certa preferenza di un utente.
     *
     * @param username L'username dell'utente di cui si cerca la notifica.
     * @param idSerie  L'id della serie di cui si cerca la notifica.
     */
    @Override
    public void cercaNotificaPreferenzaUtente(String username, int idSerie, ArrayList<LocalDate> dataNotifiche, ArrayList<LocalTime> orarioNotifiche) throws SQLException {
        //preparazione della query di ricerca dell'utente
        PreparedStatement cercaNotifiche = connection.prepareStatement("SELECT * FROM notifica as n WHERE n.username = ? AND n.idserie = ?");
        //impostazione dei parametri della query
        cercaNotifiche.setString(1, username);
        cercaNotifiche.setInt(2, idSerie);
        try {
            //esecuzione della query
            ResultSet notificheTrovate = cercaNotifiche.executeQuery();
            while (notificheTrovate.next()) {
                //aggiunge i valori del risultato di ogni colonna al rispettivo arraylist
                dataNotifiche.add(notificheTrovate.getDate(3).toLocalDate());
                orarioNotifiche.add(notificheTrovate.getTime(4).toLocalTime().truncatedTo(ChronoUnit.SECONDS));
            }
            notificheTrovate.close(); //chiusura del resultset
        } finally {
            cercaNotifiche.close(); //chiusura del prepared statement
        }
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
