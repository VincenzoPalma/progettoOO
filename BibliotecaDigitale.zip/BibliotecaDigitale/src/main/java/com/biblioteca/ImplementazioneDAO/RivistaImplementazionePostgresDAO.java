package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.RivistaDAO;
import com.biblioteca.database.ConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Classe DAO che implementa la rispettiva interfaccia RivistaDAO, gestisce
 * la connessione al database e le interrogazioni, inserimenti e modifiche per
 * quanto riguarda la classe Rivista.
 */
public class RivistaImplementazionePostgresDAO implements RivistaDAO {

    private final Connection connection;

    /**
     * Crea l'oggetto e apre la connessione col database.
     */
    public RivistaImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();
    }

    /**
     * Chiude la connessione con il database.
     */
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Inserisce nel database una rivista con attributi uguali ai valori
     * passati come parametro.
     *
     * @param issn              Issn della rivista che si vuole inserire
     * @param numero            Numero della rivista che si vuole inserire
     * @param nome              Nome della rivista che si vuole inserire
     * @param tema              Tema della rivista che si vuole inserire
     * @param responsabile      Nome del responsabile della rivista che si vuole inserire
     * @param annoPubblicazione Anno di pubblicazione della rivista che si vuole inserire
     */
    @Override
    public void aggiungiRivistaDB(String issn, int numero, String nome, String tema, String responsabile, int annoPubblicazione) throws SQLException {
        //prepara il comando di inserimento
        PreparedStatement aggiungiRivista = connection.prepareStatement("INSERT INTO rivista values (?,?,?,?,?,?)");
        //imposta i parametri del comando
        aggiungiRivista.setString(1, issn);
        aggiungiRivista.setString(2, nome);
        aggiungiRivista.setInt(3, numero);
        aggiungiRivista.setString(4, tema);
        aggiungiRivista.setInt(5, annoPubblicazione);
        aggiungiRivista.setString(6, responsabile);
        try {
            aggiungiRivista.executeUpdate(); //esegue l'inserimento
        } finally {
            aggiungiRivista.close();
        }
    }

    /**
     * Modifica la rivista con issn e numero come parametro.
     *
     * @param issn   Issn della rivista da modificare.
     * @param numero Numero della rivista da modificare.
     */
    @Override
    public void modificaRivista(String issn, int numero, String nome, String tema, String responsabile, int annopubblicazione, String nuovoIssn, int nuovoNumero) throws SQLException {
        //preparazione del comando
        PreparedStatement modificaRivista = connection.prepareStatement("UPDATE rivista SET issn = ?, numero = ?, nome = ?, tema = ?, responsabile = ?, annopubblicazione = ? WHERE issn = ? AND numero = ?");
        //impostazione dei parametri
        modificaRivista.setString(1, nuovoIssn);
        modificaRivista.setInt(2, nuovoNumero);
        modificaRivista.setString(3, nome);
        modificaRivista.setString(4, tema);
        modificaRivista.setString(5, responsabile);
        modificaRivista.setInt(6, annopubblicazione);
        modificaRivista.setString(7, issn);
        modificaRivista.setInt(8, numero);
        try {
            modificaRivista.executeUpdate(); //esegue il comando
        } finally {
            modificaRivista.close();
        }
    }

    /**
     * Modifica l'issn delle riviste con un certo issn.
     */
    @Override
    public void modificaIssnRiviste(String nuovoIssn, String vecchioIssn) throws SQLException {
        //preprazione del comando
        PreparedStatement modificaIssn = connection.prepareStatement("UPDATE rivista SET issn = ? WHERE issn = ?");
        //impostazione dei parametri
        modificaIssn.setString(1, nuovoIssn);
        modificaIssn.setString(2, vecchioIssn);
        try {
            modificaIssn.executeUpdate(); //esecuzione del comando
        } finally {
            modificaIssn.close();
        }
    }

    /**
     * Elimina dal database la rivista con issn e numero come quelli passati come parametro.
     *
     * @param issn   L'issn della rivista da eliminare.
     * @param numero Il numero della rivista da eliminare.
     */
    @Override
    public void eliminaRivista(String issn, int numero) throws SQLException {
        //preparazione del comando
        PreparedStatement eliminaRivista = connection.prepareStatement("DELETE FROM rivista WHERE issn = ? AND numero = ?");
        //impostazione dei parametri
        eliminaRivista.setString(1, issn);
        eliminaRivista.setInt(2, numero);
        try {
            eliminaRivista.executeUpdate(); //esecuzione del comando
        } finally {
            eliminaRivista.close();
        }
    }

    /**
     * Cerca nel database tutti le riviste.
     *
     * @param issn              ArrayList che conterrà gli issn degli articoli trovati
     * @param titoli            ArrayList che conterrà i titoli degli articoli trovati
     * @param numeri            ArrayList che conterrà il numero degli articoli trovati
     * @param temi              ArrayList che conterrà i temi degli articoli trovati
     * @param anniPubblicazione ArrayList che conterrà l'anno di pubblicazione degli articoli trovati
     * @param responsabili      ArrayList che conterrà il responsabile degli articoli trovati
     */
    @Override
    public void getAllRivisteDB(ArrayList<String> issn, ArrayList<String> titoli, ArrayList<Integer> numeri, ArrayList<String> temi, ArrayList<Integer> anniPubblicazione, ArrayList<String> responsabili) throws SQLException {
        //preparazione della query
        PreparedStatement cercaRiviste = connection.prepareStatement("SELECT * FROM rivista");
        try {
            //esecuzione della query
            ResultSet rivisteTrovate = cercaRiviste.executeQuery();
            while (rivisteTrovate.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                issn.add(rivisteTrovate.getString(1));
                titoli.add(rivisteTrovate.getString(2));
                numeri.add(rivisteTrovate.getInt(3));
                temi.add(rivisteTrovate.getString(4));
                anniPubblicazione.add(rivisteTrovate.getInt(5));
                responsabili.add(rivisteTrovate.getString(6));
            }
            rivisteTrovate.close(); //chiude il resultset
        } finally {
            cercaRiviste.close(); //chiude il PreparedStatement
        }
    }

    /**
     * Cerca nel database, tutte le riviste che hanno l'issn uguale a quello passato come parametro.
     *
     * @param issn                     Issn delle riviste che si vogliono cercare
     * @param titoliRiviste            ArrayList che conterrà il titolo delle riviste trovate
     * @param numeriRiviste            ArrayList che conterrà i numeri delle riviste trovate
     * @param temaRiviste              ArrayList che conterrà il tema delle riviste trovate
     * @param anniPubblicazioneRiviste ArrayList che conterrà l'anno di pubblicazione delle riviste trovate
     * @param responsabiliRiviste      ArrayList che conterrà il nome dei responsabili delle riviste trovate
     */
    @Override
    public void cercaRivistaPerIssn(String issn, ArrayList<String> titoliRiviste, ArrayList<Integer> numeriRiviste, ArrayList<String> temaRiviste, ArrayList<Integer> anniPubblicazioneRiviste, ArrayList<String> responsabiliRiviste) throws SQLException {
        //prepara la query
        PreparedStatement cercaRiviste = connection.prepareStatement("SELECT * FROM rivista WHERE  issn = ?");
        //imposta il parametro della query
        cercaRiviste.setString(1, issn);
        try {
            ResultSet rivisteTrovate = cercaRiviste.executeQuery(); //esegue la query
            while (rivisteTrovate.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                titoliRiviste.add(rivisteTrovate.getString(2));
                numeriRiviste.add(rivisteTrovate.getInt(3));
                temaRiviste.add(rivisteTrovate.getString(4));
                anniPubblicazioneRiviste.add(rivisteTrovate.getInt(5));
                responsabiliRiviste.add(rivisteTrovate.getString(6));
            }
            rivisteTrovate.close(); //chiusura del resultset
        } finally {
            cercaRiviste.close();
        }
    }

    /**
     * Cerca nel database, la rivista che contiene l'articolo con id uguale a
     * quello passato come parametro.
     *
     * @param idArticolo               Id dell'articolo di cui si cerca la rivista.
     * @param issnRivista              ArrayList che conterrà l'issn della rivista trovata.
     * @param titoliRiviste            ArrayList che conterrà il titolo delle riviste trovate
     * @param numeriRiviste            ArrayList che conterrà i numeri delle riviste trovate
     * @param temaRiviste              ArrayList che conterrà il tema delle riviste trovate
     * @param anniPubblicazioneRiviste ArrayList che conterrà l'anno di pubblicazione delle riviste trovate
     * @param responsabiliRiviste      ArrayList che conterrà il nome dei responsabili delle riviste trovate
     */
    @Override
    public void cercaRivistaPerArticolo(int idArticolo, ArrayList<String> issnRivista, ArrayList<String> titoliRiviste, ArrayList<Integer> numeriRiviste, ArrayList<String> temaRiviste, ArrayList<Integer> anniPubblicazioneRiviste, ArrayList<String> responsabiliRiviste) throws SQLException {
        //prepara la query
        PreparedStatement cercaRiviste = connection.prepareStatement("SELECT * FROM rivista as r JOIN articoloscientifico as a ON a.issn_rivista = r.issn AND a.numero_rivista = r.numero WHERE a.idarticolo = ?");
        //imposta il parametro della query
        cercaRiviste.setInt(1, idArticolo);
        try {
            ResultSet rivisteTrovate = cercaRiviste.executeQuery(); //esegue la query
            while (rivisteTrovate.next()) {
                //per ogni risultato, aggiunge i valori di ogni colonna al rispettivo arraylist
                issnRivista.add(rivisteTrovate.getString(1));
                titoliRiviste.add(rivisteTrovate.getString(2));
                numeriRiviste.add(rivisteTrovate.getInt(3));
                temaRiviste.add(rivisteTrovate.getString(4));
                anniPubblicazioneRiviste.add(rivisteTrovate.getInt(5));
                responsabiliRiviste.add(rivisteTrovate.getString(6));
            }
            rivisteTrovate.close(); //chiusura del resultset
        } finally {
            cercaRiviste.close();
        }
    }
}
