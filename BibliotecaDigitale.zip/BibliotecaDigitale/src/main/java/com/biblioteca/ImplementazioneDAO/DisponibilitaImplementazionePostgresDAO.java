package com.biblioteca.ImplementazioneDAO;

import com.biblioteca.DAO.DisponibilitaDAO;
import com.biblioteca.database.ConnectionUtil;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DisponibilitaImplementazionePostgresDAO implements DisponibilitaDAO {


    private final Connection connection;

    public DisponibilitaImplementazionePostgresDAO() {
        connection = ConnectionUtil.getInstance().GetConnection();

    }

    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * Aggiunge la disponibilità di un libro da un negozio.
     *
     * @param isbn      Il libro di cui si vuole aggiungere la disponibilità.
     * @param idnegozio Id del negozio a cui si vuole aggiungere il libro.
     */
    @Override
    public void aggiungiDisponibilitaDB(String isbn, int idnegozio, BigDecimal prezzo) throws SQLException {
        //preparazione del comando
        PreparedStatement aggiungiDisponibilita = connection.prepareStatement("INSERT INTO rel_libro_negozio VALUES (?, ?, ?)");
        //impostazione dei parametri
        aggiungiDisponibilita.setString(1, isbn);
        aggiungiDisponibilita.setBigDecimal(2, prezzo);
        aggiungiDisponibilita.setInt(3, idnegozio);
        try {
            aggiungiDisponibilita.executeUpdate(); //esecuzione del comando
        } finally {
            aggiungiDisponibilita.close();
        }
    }

    /**
     * Elimina la disponibilità di un libro da un negozio.
     *
     * @param isbn      Il libro di cui si vuole rimuovere la disponibilità.
     * @param idnegozio Id del negozio da cui si vuole rimuovere il libro.
     */
    @Override
    public void eliminaDisponibilitaDB(String isbn, int idnegozio) throws SQLException {
        //preparazione del comando
        PreparedStatement eliminaDisponibilita = connection.prepareStatement("DELETE FROM rel_libro_negozio WHERE isbn = ? AND idnegozio = ?");
        //impostazione dei parametri
        eliminaDisponibilita.setString(1, isbn);
        eliminaDisponibilita.setInt(2, idnegozio);
        try {
            eliminaDisponibilita.executeUpdate(); //esecuzione del comando
        } finally {
            eliminaDisponibilita.close();
        }
    }

    /**
     * Cerca le disponibilità del libro con isbn uguale a quello passato come parametro.
     *
     * @param isbn        Isbn del libro di cui si vuole cercare la disponibilità nei negozi
     * @param idNegozi    ArrayList che contiene l'id dei negozi relativi alle disponibilità trovate
     * @param prezziLibro ArrayList che contiene il prezzo del libro nei negozi relativi alle disponibilità trovate
     */
    @Override
    public void cercaDisponibilitaPerIsbnDB(String isbn, ArrayList<Integer> idNegozi, ArrayList<BigDecimal> prezziLibro) throws SQLException {
        //preparazione della query
        PreparedStatement cercaDisponibilita = connection.prepareStatement("SELECT * FROM rel_libro_negozio as r WHERE r.isbn = ?");
        //impostazione del parametro della query
        cercaDisponibilita.setString(1, isbn);
        try {
            ResultSet risultatiDisponibilita = cercaDisponibilita.executeQuery(); //esegue la query
            while (risultatiDisponibilita.next()) {
                idNegozi.add(risultatiDisponibilita.getInt(3));
                prezziLibro.add(risultatiDisponibilita.getBigDecimal(2));
            }
            risultatiDisponibilita.close(); //chiusura del resultset
        } finally {
            cercaDisponibilita.close();
        }

    }

    /**
     * Cerca i libri disponibili nel negozio con id uguale a quello passato come parametro.
     */
    @Override
    public void cercaDisponibilitaPerIdNegozioDB(int idNegozio, ArrayList<String> isbnLibri, ArrayList<BigDecimal> prezziLibri) throws SQLException {
        //prepara la query
        PreparedStatement cercaDisponibilita = connection.prepareStatement("SELECT * FROM rel_libro_negozio as r WHERE r.idnegozio = ?");
        cercaDisponibilita.setInt(1, idNegozio); //imposta il parametro
        try {
            ResultSet risultatiDisponibilita = cercaDisponibilita.executeQuery();
            while (risultatiDisponibilita.next()) {
                isbnLibri.add(risultatiDisponibilita.getString(1));
                prezziLibri.add(risultatiDisponibilita.getBigDecimal(2));
            }
            risultatiDisponibilita.close(); //chiusura del resultset
        } finally {
            cercaDisponibilita.close();
        }
    }
}
